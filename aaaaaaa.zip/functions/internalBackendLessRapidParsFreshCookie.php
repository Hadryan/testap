<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(144);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Credentials: TRUE");
header("Content-type: application/json; charset=utf-8");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 19 Jul 1999 09:09:09 GMT");

include dirname(__FILE__) . '/internalBackendLess_functions.php';

	$result = 'Error';
	$boolean = (bool) false;
	
	@$header_can_set = $_SERVER['HTTP_X_CAN_SET'];

	if ( isset($header_can_set) && !empty($header_can_set) )
	{
		$data_cookie_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/System_Parameters';
		$data_cookie_headers = array(
			"Content-Type: application/json",
			"Accept: application/json"
		);
		
		@$fresh_cookie = get_backendless_cookie_login('https://rapidpars.com/api/?cmd=login&timestamp=' . time());
		//@$fresh_cookie =  base64_decode('SFRUUC8xLjEgMjAwIE9LDQpEYXRlOiBNb24sIDEwIEp1bCAyMDE3IDEzOjA3OjIzIEdNVA0KQ29udGVudC1UeXBlOiBhcHBsaWNhdGlvbi9qYXZhc2NyaXB0O2NoYXJzZXQ9dXRmLTgNClRyYW5zZmVyLUVuY29kaW5nOiBjaHVua2VkDQpDb25uZWN0aW9uOiBjbG9zZQ0KU2V0LUNvb2tpZTogX19jZmR1aWQ9ZGEwNmRjOWM4OGI1MGZjMDRlMTA3NzlkNDc5MjIwYTRkMTQ5OTY5MjA0MzsgZXhwaXJlcz1UdWUsIDEwLUp1bC0xOCAxMzowNzoyMyBHTVQ7IHBhdGg9LzsgZG9tYWluPS5yYXBpZHBhcnMuY29tOyBIdHRwT25seQ0KWC1Qb3dlcmVkLUJ5OiBQSFAvNS42LjMwDQpWYXJ5OiBBY2NlcHQtRW5jb2RpbmcsVXNlci1BZ2VudA0KWC1XZWJLaXQtQ1NQOiBzY3JpcHQtc3JjIHd3dy5nb29nbGUtYW5hbHl0aWNzLmNvbSBnb29nbGUuY29tIHd3dy5nb29nbGUuY29tIGh0dHBzOi8vd3d3Lmdvb2dsZS5jb20gaHR0cHM6Ly93d3cuZ3N0YXRpYy5jb20gZ29vZ2xlLWFuYWx5dGljcy5jb20gJ3NlbGYnICd1bnNhZmUtaW5saW5lJyAndW5zYWZlLWV2YWwnOw0KWC1Db250ZW50LVR5cGUtT3B0aW9uczogbm9zbmlmZg0KU2VydmVyOiBjbG91ZGZsYXJlLW5naW54DQpDRi1SQVk6IDM3YzNiZWU3NDIzNTIzZWEtSUFEDQoNCmIyDQp7ImFwaSI6NzAsInN0YXR1cyI6Im9rIiwic2MiOiI5ZjJhZjhkOTk0MjY5MWUwZDRlMmFhM2E4ODMwNDhkZGZlMDdmM2M0NWRjYjNkNWY3NDMxY2ZkNjY0OTM0ZWYyMTdmYzcyNjM2MDlkMmNlNGJlMDg1YTg4OGY4ZGRjODgzZWUxZWZhMjgzMjM0NzIxMmM1YzEwZmQiLCJzaWQiOjQxNTE5NiwidWlkIjoiNDU3NzQiDQoxDQp9DQowDQoNCg==');
		preg_match_all("/\"status\":\"(.*?)\"/", @$fresh_cookie, $fresh_cookie_status_array);
		
		if ( !empty($fresh_cookie_status_array) )
		{
			if ( $fresh_cookie_status_array[1][0] == 'ok' )
			{
				preg_match_all("/\"sc\":\"(.*?)\"/", @$fresh_cookie, $fresh_cookie_sc_array);
				preg_match_all("/\"sid\":(|\")(.*?)(|\"),/", @$fresh_cookie, $fresh_cookie_sid_array);
				preg_match_all("/\"uid\":\"(.*?)\"/", @$fresh_cookie, $fresh_cookie_uid_array);
				
				$cookie_userid = $fresh_cookie_uid_array[1][0];
				$cookie_secretid = $fresh_cookie_sid_array[2][0];
				$cookie_secret = $fresh_cookie_sc_array[1][0];
				
				$data_cookie_data = array(
					'json_response' => json_encode(array("status"=>"ok", "sc"=>$cookie_secret, "sid"=>$cookie_secretid, "uid"=>$cookie_userid)),
					'service_type' => 'rapid_pars',
				);
				
				// Update the System_Parameters
				try {
					@$data_cookie_results = sendBackendlessRequest( $data_cookie_url, $data_cookie_headers, json_encode($data_cookie_data) );
					@$data_cookie_results_array = json_decode($data_cookie_results, true);
					
				} catch (Exception $ex){
					sendError('internalBackendLessRapidParsFreshCookie', 'error', (string)$ex->getCode(), $ex->getMessage(), 'time: ' . time());
				}
				
				if ( !empty($data_cookie_results_array) )
				{
					$result = 'Splendid'; // the backendless response is not json !
					$boolean = (bool) true;
				}
				
			} else
			{
				sendError('fresh_cookie', 'error', 'urgent', @$fresh_cookie_body['error'], 'time: ' . time());
			}
			
		} else // We still use the previous cookie, but we need to send the error log
		{
			sendError( 'System_Parameters', 'error', 'urgent', 'cookie generation had error', 'time: ' . time() );
		}
		
	}
	
	echo customResponse($boolean, $result);

?>