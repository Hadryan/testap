<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';
// Asynchronous request
require dirname(__FILE__) . '/library/vendor/autoload.php';
use mpyw\Co\Co;
use mpyw\Co\CURLException;

//
function curl_async_put($url, array $options = [], $user_token = ''){
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	}

	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "PUT",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_post($url, array $headers = [], array $data = [], array $options = []){
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => json_encode($data),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_get($url, array $options = [], $user_token = ''){
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	};
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
	function get_full_audio( $id, $album_id, $title, $duration, $format, $request_ts, $request_sig, $app_id, $user_token, $session_id ){

		if ( defined('AllowToAccessGetAudioFunctions') )
		{
			@$user_objectId = decrypt($user_token);
			@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
			@$constructed_session_id = explode(':', $session_response);
			@$provided_user_id = $constructed_session_id[0];
			@$session_id_decrypted = $constructed_session_id[1];
		
			if ( $user_objectId == $provided_user_id )
			{
				$id_original = $id;
				$decrypted_id = remove_non_utf8(md5_decrypt($id, MD5_ID_MASTERKEY));
				$constructed_id = explode(':', $decrypted_id);
				$id = $constructed_id[1];
			
				$current_time = $time_now = time();
				if ( $format == 6 || $format == 7 || $format == 27 )
				{
					$media_ext = 'flac';
				}
				else {
					$media_ext = 'mp3';
				}
				
				$spent_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $user_objectId;
				$spent_headers = array(
					"Content-Type: application/json",
				);
				$spent_where = '?where=ownerId' . urlencode("='" . $user_objectId . "'");
				
				
				$get_counters = Co::wait([
					
					"0" => function () use ($user_objectId, $spent_url, $spent_headers, $spent_where) {
						$content = (yield getBackendlessResponse( $spent_url, $spent_headers, $spent_where ));
						//yield Co::RETURN_WITH =>$content; // PHP 5.6
						return $content; // PHP 7+
					},
					
					"1" => function () use ($user_objectId, $session_id_decrypted) {
						$content = (yield curl_async_get('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY_PER_USER . '/counters/' . $user_objectId . '__' . 'user_total_purchases', [], $session_id_decrypted));
						//yield Co::RETURN_WITH =>$content; // PHP 5.6
						return $content; // PHP 7+
					},
					
				]);
				
				$database_headers = array(
					"Content-Type: application/json",
					"user-token: " . $session_id_decrypted,
				);
			
				@$user_total_purchases = $get_counters[1];
				@$user_total_spent_json = $get_counters[0];
				@$user_total_spent_array = json_decode($user_total_spent_json, true);
				@$user_total_spent = $user_total_spent_array["user_total_spent"];
				@$user_subscription = $user_total_spent_array["user_subscription"];

				@$previous_time = substr($user_total_purchases, 0, 6);
				@$previous_control_digit = substr($user_total_purchases, 6, 1);
				@$previous_subscription_value = substr($user_total_purchases, 7, 3);
				@$previous_normal_value = substr($user_total_purchases, 10, 4);
			
				$genorous_time = time() + 86400; // until tomorrow
				$current_time = substr($genorous_time, 0, 6);
			
				if ( empty(json_decode($user_total_purchases, true)['code']) )
				{
					if ( $previous_control_digit == 1 ) // Time-based package
					{
						if ( substr($genorous_time, 0, 6) >= $previous_time ) // The previous package time is already expired! && [We are also generous here!, could be time() instead of $genorous_time]
						{
							if ( $previous_normal_value >= 1 )
							{
								$construction_control_digit = 0;
								$construction_subscription_value = 0;
								$construction_normal_value = non_negative($previous_normal_value - 1);
								$construction_time = $previous_time;
							}
						
						} else // We still have time from previous package
						{
							if ( $previous_subscription_value > 1 ) // We have timed-based package, so we use it first
							{
								$construction_control_digit = 1;
								$construction_subscription_value = non_negative($previous_subscription_value - 1);
								$construction_normal_value = $previous_normal_value;
								$construction_time = $previous_time;
							
							} elseif ( $previous_subscription_value == 1)
							{
								$construction_control_digit = 0;
								$construction_subscription_value = non_negative($previous_subscription_value - 1);
								$construction_normal_value = $previous_normal_value;
								$construction_time = $previous_time;
							} else
							{
								$construction_control_digit = 0;
								$construction_subscription_value = 0;
								$construction_normal_value = non_negative($previous_normal_value - 1);
								$construction_time = $previous_time;
							}
						
						}
					
					} else // Normal package
					{
						$construction_control_digit = 0;
						$construction_subscription_value = 0;
						$construction_normal_value = non_negative($previous_normal_value - 1);
						$construction_time = $previous_time;
					}
				
				
					if ( $construction_normal_value > 0 || ($construction_subscription_value > 0 && $construction_time >= $current_time) || ($previous_normal_value == 1 && $construction_control_digit == 0 ) )
					{
						$user_total_spent++; // The user has used one of this quotas
                        
                        if ( (int)substr($user_total_purchases, 6, 8) - (int)($construction_control_digit . prepareLength($construction_subscription_value, 3, 0) . prepareLength($construction_normal_value, 4, 0)) < 0) { // Calculation bug control
                            echo status_code(422);
                            exit;
                        }
						$construction_count = $construction_time . $construction_control_digit . prepareLength($construction_subscription_value, 3, 0) . prepareLength($construction_normal_value, 4, 0);
						
						// Check if we previously uploaded this file on s3
						@$already_uploaded_url = 'https://' . BUCKET_FULLAUDIO . '.' . AMAZON_S3_SERVICE . '/' . DOWNLOAD_LOCATION . '/' . construct_the_id(QOBUZSERVICE . 'FullLengthMP3', $id) . '.' . $media_ext;
						@$check_already_uploaded_url = checkRemoteFileExists($already_uploaded_url);
						
						if ( $check_already_uploaded_url == true ) // We check if this track previously uploaded or not
						{
							$full_audio_id = construct_the_id(QOBUZSERVICE . 'FullLengthMP3', $id);
							$op_duration = $track_duration = $duration;
						
						} else { // We need to grab full audio in real-time
							
							$data_service_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/System_Parameters';
							$data_service_headers = array(
								"Content-Type: application/json",
							);
							$data_service_where = '?pageSize=1' . '&where=service_type' . urlencode("='" . 'qobuz' . "'") . '&sortBy=created%20desc';
							
							$get_services = Co::wait([
								
								"0" => function () use ($data_service_url, $data_service_where) {
									$content = (yield curl_async_get( $data_service_url . $data_service_where ));
									//yield Co::RETURN_WITH =>$content; // PHP 5.6
									return $content; // PHP 7+
								},
						
							]);
							
							@$data_service_results_array = json_decode($get_services[0], true);
							
							@$cookie_music_service = $data_service_results_array[0]['json_response'];
							@$music_service_created = round($data_service_results_array[0]['created'] / 1000);
							@$music_service_objectId = $data_service_results_array[0]['objectId'];
							
							// We process the user_auth_token required for downloading
							if ( @$cookie_music_service )
							{
								$cookie_music_service_array = json_decode($cookie_music_service, true);
					
								if ( $current_time < ($music_service_created + (5 * 24 * 60 * 60)) ) // less than 5 days old!
								{
									if ( isset($cookie_music_service_array['user']['id']) && $cookie_music_service_array['user_auth_token'] != '' )
									{
										$user_auth_token = $cookie_music_service_array['user_auth_token'];
									}
									
								} else // We need to grab fresh login
								{							
									@$fresh_cookie = get_qobuz_cookie_login('https://www.qobuz.com/api.json/0.2/user/login');
									@$fresh_cookie_results_array = json_decode($fresh_cookie, true);
									
									if ( !empty($fresh_cookie_results_array) && empty($fresh_cookie_results_array['status']) )
									{
										if ( !empty($fresh_cookie_results_array['user']['id']) )
										{
                                            $data_cookie_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/System_Parameters';
                                            $data_cookie_headers = array(
                                                "Content-Type: application/json",
                                                "Accept: application/json"
                                            );
											$data_fresh_cookie_data = array(
												'json_response' => json_encode($fresh_cookie_results_array),
												'service_type' => 'qobuz',
											);
											
											// Update the System_Parameters
											try {
												@$data_fresh_cookie_results = sendBackendlessRequest( $data_cookie_url, $data_cookie_headers, json_encode($data_fresh_cookie_data) );
												@$data_fresh_cookie_results_array = json_decode($data_fresh_cookie_results, true);
									
												$user_auth_token = $fresh_cookie_results_array['user_auth_token'];
												
											} catch (Exception $ex){
												sendError('getAudioFreshCookie', 'error', (string)$ex->getCode(), $ex->getMessage(), 'time: ' . time());
											}
											
										} else
										{
											sendError('getAudioFreshCookieAccount', 'error', 'urgent', 'something happened with the account!', 'time: ' . time());
										}
								
									} else // We still use the previous cookie, but we need to send the error log
									{
										sendError( 'System_ParametersFreshCookie', 'error', 'urgent', 'cookie generation had error', 'time: ' . time() );
									}
								}
								
							} else { // We couldn't find the cookie in database OR we don't have it !
								
								@$fresh_cookie = get_qobuz_cookie_login('https://www.qobuz.com/api.json/0.2/user/login');
								@$fresh_cookie_results_array = json_decode($fresh_cookie, true);
								
								if ( !empty($fresh_cookie_results_array) && empty($fresh_cookie_results_array['status']) )
								{
									if ( !empty($fresh_cookie_results_array['user']['id']) )
									{
                                        $data_cookie_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/System_Parameters';
                                        $data_cookie_headers = array(
                                            "Content-Type: application/json",
                                            "Accept: application/json"
                                        );
										$data_fresh_cookie_data = array(
											'json_response' => json_encode($fresh_cookie_results_array),
											'service_type' => 'qobuz',
										);
										
										// Update the System_Parameters
										try {
											@$data_fresh_cookie_results = sendBackendlessRequest( $data_cookie_url, $data_cookie_headers, json_encode($data_fresh_cookie_data) );
											@$data_fresh_cookie_results_array = json_decode($data_fresh_cookie_results, true);
											
											$user_auth_token = $fresh_cookie_results_array['user_auth_token'];
											
										} catch (Exception $ex){
											sendError('getAudioFreshCookieNew', 'error', (string)$ex->getCode(), $ex->getMessage(), 'time: ' . time());
										}
										
									} else
									{
										sendError('getAudioFreshCookieAccountNew', 'error', 'urgent', 'something happened with the account!', 'time: ' . time());
									}
									
								} else // We still use the previous cookie, but we need to send the error log
								{
									sendError( 'System_ParametersFreshCookieNew', 'error', 'urgent', 'cookie generation had error', 'time: ' . time() );
								}
								
							}
							
							$query = 'http://i-serp.com/SYS__fetchAudio.php?id=' . $id . '&app_id=' . QOBUZAPPID . '&app_secret=' . QOBUZAPPSECRET . '&user_token=' . $user_auth_token;
							@$raw_data = stream_open($query, 'http://i-serp.com/', 'i-serp.com');
							@$data = json_decode($raw_data, true);
				
							if ( @$data["status"] == "error" || empty($data) ) 
							{
								$query = 'http://muism.com/v1/SYS__fetchAudio.php?id=' . $id . '&app_id=' . QOBUZAPPID . '&app_secret=' . QOBUZAPPSECRET . '&user_token=' . $user_auth_token;
								@$raw_data = stream_open($query, 'http://muism.com/', 'muism.com');
								@$data = json_decode($raw_data, true);
							
								if ( @$data["status"] == "error" || empty($data) ) 
								{
									@$raw_data = FullLengthTrack($id, $format, QOBUZAPPID, QOBUZAPPSECRET, $user_auth_token); // Qobuz directly
									@$data = json_decode($raw_data, true);
								}
							}
				
				
							if ( !empty($data) && empty($data['status']) )
							{
								if ( isset($data['restrictions']) && (empty($data["url"]) || is_null($data["url"])) || isset($data['status']) || strpos($data['url'], 'sample.qobuz') !== false )
								{
									echo status_code(404);
									exit;
								}
								
								// Uploading full length audio Track
								$full_audio_id = construct_the_id(QOBUZSERVICE . 'FullLengthMP3', $id);
								$full_audio_endpoint = 'getFullAudio';
								$full_audio_key_string = $full_audio_endpoint . $full_audio_id . $time_now . FULLAUDIO_ACCESS_NODE;
								$op_duration = $track_duration = $data['duration'];
//								$track_sampling_rate = $data['sampling_rate'];
//								$track_bit_depth = $data['bit_depth'];
								$full_audio_url = ASSETSSERVER_SSL . $full_audio_endpoint . '.php?request_ts=' . $time_now . '&request_sig=' . generate_hmac_signature($full_audio_key_string, FULLAUDIO_ACCESS_NODE);
								$full_audio_headers = array(
									"Content-Type: application/x-www-form-urlencoded",
								);	
								$full_audio_params = array(
									'track_id' => $full_audio_id,
									'track_url' => urlencode($data['url']),
									'track_format' => $media_ext,
									'track_origin' => QOBUZSERVICE,
								);
								
								try {
									@$full_audio_results = sendBackendlessRequest( $full_audio_url, $full_audio_headers, http_build_query($full_audio_params) );
									@$full_audio_results_array = json_decode($full_audio_results, true);
									
								} catch (Exception $ex){
									sendError( 'getAudio_S3Upload', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' , track_original_id: ' . @$id . ' and time: ' . time() );
								}
								
							} else { // Nothing returned from the server
								echo status_code(404);
								exit;
							}
							
						}
						
					if ( ($check_already_uploaded_url == true) || (!empty($full_audio_results_array) && $full_audio_results_array['message'] == $full_audio_id) )
					{	
						$op_id = $id_original;
						$op_title = $title;
						$op_time = $time_now;
						$op_quota = $construction_count;
						$op_format = $format;
						
						// We calculate secure link for download that is valid until 14 days
						$future_time = $time_now + (DAY_TO_LIVE_AUDIO_DOWNLOAD * 24 * 60 * 60);
						$final_media = AUDIOSERVER_SSL . DOWNLOAD_LOCATION . '/' . $full_audio_id . '.' . $media_ext . '?expires=' . $future_time . '&signature=' . generate_fullaudio_link($full_audio_id, $media_ext, $future_time);
						
						if ( empty($final_media) )
						{
							// $final_media = $data_url;  // If the process was unsuccessful, we return back the original_url !
							$final_media = APIENDPOINT . URLVERSION . '/' . 'Error.wav';
				
							$op_format = 10; // Our assumption for .wav audio files
							$op_duration = $track_duration = 1;
						}
						
						$op_url = $final_media;
						
						$decrypted_album_id = remove_non_utf8(md5_decrypt($album_id, MD5_ID_MASTERKEY));
						$constructed_album_id = explode(':', $decrypted_album_id);
						$album_id = $constructed_album_id[1];
						$album_id_original = $album_id;
						
						$album_id = checkSafeValue( construct_the_id(QOBUZSERVICE . 'Album', $album_id), null );
						@$album_image = array(
							"50"   => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 50 . ':' . $album_id_original) . '.jpg',
							"230"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 230 . ':' . $album_id_original) . '.jpg',
							"600"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 600 . ':' . $album_id_original) . '.jpg',
						);
						
						$export = response_json($user_objectId, $user_subscription, $op_url, $op_quota, $op_id, $op_title, $op_time, $op_format, $album_image, $op_duration);
						$export_database = response_json_database($op_url, $op_id, $op_title, $op_time, $op_format, $album_id, $op_duration);
						
						$data_spend_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users_Quotas';
						$data_spend_headers = array(
							"Content-Type: application/json",
						);
						$data_spend_data = array(
//							'user_media' 	 			=> $export_database,
							'user_track_id' 	 		=> $id,
							'user_track_title' 	 		=> $title,
//							'user_track_sampling_rate' 	=> $track_sampling_rate,
//							'user_track_bit_depth' 	 	=> $track_bit_depth,
							'user_track_duration'		=> (int)$track_duration,
							'user_track_format'			=> (int)$format,
							'user_album_id'				=> $album_id_original,
							'ownerId'					=> $user_objectId,
						);
						
						$data_counter_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $user_objectId;
						$data_counter_data = array(
							'user_total_purchases'		=> (double)checkSafeValue($construction_count, 0),
							'user_total_spent'			=> (double)checkSafeValue($user_total_spent, 0),
						);
						$data_counter_headers = array(
							"Content-Type: application/json",
						);
						
						$set_counters = Co::wait([
							
							"0" => function () use ($user_objectId, $session_id_decrypted, $user_total_purchases, $construction_count) {
								$content = (yield curl_async_put('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/counters/' . $user_objectId . '__' . 'user_total_purchases' . '/get/compareandset?expected=' . $user_total_purchases . '&updatedvalue=' . $construction_count, [], $session_id_decrypted ));
								//yield Co::RETURN_WITH =>$content; // PHP 5.6
								return $content; // PHP 7+
							},
							
							"1" => function () use ($data_spend_url, $data_spend_headers, $data_spend_data) {
								$content = (yield curl_async_post( $data_spend_url, $data_spend_headers, $data_spend_data ));
								//yield Co::RETURN_WITH =>$content; // PHP 5.6
								return $content; // PHP 7+
							},
							
							"2" => function () use ($user_objectId, $data_counter_url, $data_counter_headers, $data_counter_data) {
								$content = (yield updateBackendlessRequest( $data_counter_url, $data_counter_headers, json_encode($data_counter_data) ));
								//yield Co::RETURN_WITH =>$content; // PHP 5.6
								return $content; // PHP 7+
							},
							
						]);
			
						@$spent_array = json_decode($set_counters[1], true);
						
						if ( !empty($spent_array) && empty($spent_array['code']) )
						{
							$created_object_id = $spent_array['objectId'];
				
							$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $user_objectId . '/user_quotas';
							$relation_data = array(
								'objectId' 	 => $created_object_id
							);
							
							try {
								updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
								
							} catch (Exception $ex){
								sendError( 'Users_Quotas_relationUpdate', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , favorite_objectId: ' . @$created_object_id . ' , app_id: ' . @$app_id . ' and time: ' . time() );
							}
							
						}
						
						return $export;
						
					} else { // Something happened with remote S3 server
						echo status_code(424);
						exit;
					}
					
				} else {
					echo status_code(422);
					exit;
				}
				
			} else { // Expired session_id
				echo status_code(401);
				exit;
			}
			
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json_database($op_url, $op_id, $op_title, $op_time, $op_format = '5', $album_id, $op_duration){
	$output = '';
	$output .= '{';
	//$output .= '"timestamp":' . $op_time . ',';
	$output .= '"track_id":' . json_encode($op_id) . ',';
	$output .= '"track_title":' . json_encode($op_title) . ',';
	$output .= '"duration":' . json_encode($op_duration) . ',';
	$output .= '"album_id":' . json_encode($album_id) . ',';
	$output .= '"audio_url":' . json_encode($op_url) . ',';
	if ( $op_format == '5' )
	{
		$output .= '"mime_type":' . json_encode('audio/mpeg');
	} elseif ( $op_format == '6' || $op_format == '7' || $op_format == '27' ) 
	{
		$output .= '"mime_type":' . json_encode('audio/flac');
	} else 
	{
		$output .= '"mime_type":' . json_encode('application/octet-stream');
	}
	$output .= '}';

	return $output;
}

//
function response_json($user_objectId, $user_subscription, $op_url, $op_quota, $op_id, $op_title, $op_time, $op_format = '5', $album_image, $op_duration){
	$output = '';
	$output .= '{';
	//$output .= '"timestamp":' . $op_time . ',';
	$output .= '"track_id":' . json_encode($op_id) . ',';
	$output .= '"track_title":' . json_encode($op_title) . ',';
	$output .= '"duration":' . json_encode($op_duration) . ',';
	$output .= '"image":' . json_encode($album_image) . ',';
	$output .= '"audio_url":' . json_encode($op_url) . ',';
	$output .= '"user_download_quota":' . json_encode(counter_to_packages($op_quota, encrypt($user_objectId), $user_subscription)) . ',';
	if ( $op_format == '5' )
	{
		$output .= '"mime_type":' . json_encode('audio/mpeg');
	} elseif ( $op_format == '6' || $op_format == '7' || $op_format == '27' ) 
	{
		$output .= '"mime_type":' . json_encode('audio/flac');
	} else 
	{
		$output .= '"mime_type":' . json_encode('application/octet-stream');
	}
	$output .= '}';

	return $output;
}

?>