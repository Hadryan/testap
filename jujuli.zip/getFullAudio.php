<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(233);


include dirname(__FILE__) . '/' . basename(__FILE__, '.php') . '_functions.php';

	@$track_id = $_POST['track_id'];
	@$track_url = urldecode($_POST['track_url']);
	@$track_format = $_POST['track_format'];
	@$track_origin = $_POST['track_origin'];
	@$request_ts = $_GET['request_ts'];
	@$request_sig = $_GET['request_sig'];

	$now = time();
	@$endpoint = 'getFullAudio';
	$fetch_secret = 'nE4NHQJUb/JYipJMLi2YG0D#*%mspVSHKF;5z0S6fDjV1Y3CjN3CJmnFUWwOr5';

	if ( $track_id && $track_url && $request_ts && $request_sig && ($request_ts > $now - 1800 /*30 min*/) && ($request_ts < $now + 900 /*15 min*/) )
	{
		@$string = $endpoint . $track_id . $request_ts . $fetch_secret;
		
		if ( verify_hmac_signature($string, $fetch_secret, $request_sig) === TRUE )
		{
			define('AllowToAccessGetFullAudioFunctions', TRUE);
			$export = get_full_audio( $track_id, $track_url, $track_format, $track_origin, $now );
			echo $export;
			
		} else {
			echo status_code(401);
			exit;
		}
		
	} else // parameter are not provided
	{
		echo status_code(417);
	}

?>
