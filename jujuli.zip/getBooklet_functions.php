<?php
require dirname(__FILE__) . '/library/vendor/autoload.php';

define("APPLICATION_ID", 			"2D4AB967-891A-3618-FF46-7FE166657400");
define("SECRET_KEY", 				"1A841EFB-3429-1E45-FF9D-B6C6D5247A00");

define("APIVERSION", 				"2.0");
define("USERAGENT",					user_aget());
define("MD5_EXTERNAL_RESOURCE",		'BV!;nnYL_xM]hNAf=ie8[;%ASw/d=' . base64_decode('JA==') . '7.qja.fK;:#e&RjFFZ?pd}AhXV7m,XV:[;');
define("QOBUZSERVICE",				"Qobuz");

define("MEDIAURI",					"tempDirectory");
define("BUCKET_ASSETS",				"assets.diginava.com");

define("NGINX_SECURITY_VALUE",		"wCSmFPymGKqPa9kb9znMJnSf8KAMAd4E3VKSydvaNyLN9MGuBVJnceXUNQ3dWYDm");

date_default_timezone_set("UTC");


//
function id_encrypt($id) {
	return preg_replace("/_/", "", encrypt($id, '17acbece5763563d'));
}
	
//
function id_decrypt($id) {
	return decrypt($id, '17acbece5763563d');
}

//
function encrypt($str, $key = "F2avHrF62o8jLZFREEEEN65zs7otsXV"){
  $result = '';
  for($i=0; $i<strlen($str); $i++) {
     $char = substr($str, $i, 1);
     $keychar = substr($key, ($i % strlen($key))-1, 1);
     $char = chr(ord($char)+ord($keychar));
     $result.=$char;
  }
  return safe_b64encode($result);
}

//
function decrypt($str, $key = "F2avHrF62o8jLZFREEEEN65zs7otsXV"){
  $str = safe_b64decode($str);
  $result = '';
  for($i=0; $i<strlen($str); $i++) {
    $char = substr($str, $i, 1);
    $keychar = substr($key, ($i % strlen($key))-1, 1);
    $char = chr(ord($char)-ord($keychar));
    $result.=$char;
  }
return $result;
}

//
function safe_b64encode($string) {
	$data = base64_encode($string);
	$data = str_replace(array('+','/','='),array('-','~','_'),$data);
	return $data;
}

//
function safe_b64decode($string) {
	$data = str_replace(array('-','~','_'),array('+','/','='),$string);
	$mod4 = strlen($data) % 4;
	if ($mod4) {
			$data .= substr('====', $mod4);
	}
	return base64_decode($data);
}

//
function md5_encrypt($plainText, $key) {
	// Based on Nanhe Kumar answer : https://stackoverflow.com/a/52253745/4013321
	$secretKey = hextobin(md5($key));
	$initVector = pack("C*", 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f);
	$openMode = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', 'cbc', '');
	$blockSize = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, 'cbc');
	$plainPad = pkcs5_pad($plainText, $blockSize);
	if (mcrypt_generic_init($openMode, $secretKey, $initVector) != -1) {
		$encryptedText = mcrypt_generic($openMode, $plainPad);
		mcrypt_generic_deinit($openMode);
	}
	return bin2hex($encryptedText);
}

//
function md5_decrypt($encryptedText, $key) {
		$secretKey = hextobin(md5($key));
		$initVector = pack("C*", 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f);
		$encryptedText = hextobin($encryptedText);
		$openMode = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', 'cbc', '');
		mcrypt_generic_init($openMode, $secretKey, $initVector);
		$decryptedText = mdecrypt_generic($openMode, $encryptedText);
		$decryptedText = rtrim($decryptedText, "\0");
		mcrypt_generic_deinit($openMode);
	return $decryptedText;
}

//
function pkcs5_pad($plainText, $blockSize) {
	//*********** Padding Function *********************
	$pad = $blockSize - (strlen($plainText) % $blockSize);
	return $plainText . str_repeat(chr($pad), $pad);
}

//
function hextobin($hexString) {
	//********** Hexadecimal to Binary function for php 4.0 version ********
	$length = strlen($hexString);
	$binString = "";
	$count = 0;
	while ($count < $length) {
		$subString = substr($hexString, $count, 2);
		$packedString = pack("H*", $subString);
		if ($count == 0) {
			$binString = $packedString;
		} else {
			$binString .= $packedString;
		}

		$count += 2;
	}
	return $binString;
}

//
function remove_non_utf8($string){
	// https://stackoverflow.com/a/1176923/4013321
	return preg_replace('/[\x00-\x1F\x7F\xA0]/u', '', $string);
}

//
function octal_2_encrypt($string, $base = 9){

	return base_convert($string, 10, $base);
}

//
function encrypt_2_octal($string, $base = 9){

	return base_convert($string, $base, 10);
}

//
function prepareLength($string, $length = 14, $placeholder = '_', $placement = 'left'){
	if ( $placement == 'right' )
	{
		while ( strlen($string) < $length ) {
			$string = $string . $placeholder;
		}
		
	} else {
		while ( strlen($string) < $length ) {
			$string = $placeholder . $string;
		}
	}

	return $string;
}

//
function stream_open($url, $refer = 'http://www.google.com/', $host = 'google.com', $accept = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', $agent = USERAGENT, $https = false ){
	
	$options = array(
		
		CURLOPT_CUSTOMREQUEST  =>"GET",        //set request type post or get
		CURLOPT_POST           =>false,        //set to GET
		
		CURLOPT_RETURNTRANSFER => true,     // return web page
		CURLOPT_HEADER         => false,    // don't return headers
		CURLOPT_FOLLOWLOCATION => true,     // follow redirects
		CURLOPT_ENCODING       => "",       // handle all encodings
		CURLOPT_AUTOREFERER    => true,     // set referer on redirect
		CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
		CURLOPT_TIMEOUT        => 120,      // timeout on response
		CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
	);
		
		$ch      = curl_init( $url );
		
		$cookie_string = "";
		$cookie_string .= "i18next=fr-FR; ";
		
		
		$headers = array();
		$headers[] = 'User-Agent: ' . $agent;
		$headers[] = 'Accept-Encoding: gzip, deflate';
		$headers[] = 'Accept-Language: fr-FR,fr;q=0.8,en-US;q=0.6,en;q=0.4';
		$headers[] = 'Host: ' . $host;
		$headers[] = 'Referer: '  . $refer;
		$headers[] = 'Connection : keep-alive';
		$headers[] = $accept;
	
		
		curl_setopt($ch, CURLOPT_URL, $url);  
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			if ( $https == 1 )
			{
				curl_setopt ($ch, CURLOPT_CAINFO, dirname(__FILE__)."/cacert.pem");
			}
			
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_ENCODING, '');
		curl_setopt($ch, CURLOPT_TIMEOUT, 55);
		curl_setopt($ch, CURLOPT_COOKIE, $cookie_string);
		
		curl_setopt_array( $ch, $options );
		$content = curl_exec( $ch );
		$err     = curl_errno( $ch );
		$errmsg  = curl_error( $ch );
		$header  = curl_getinfo( $ch );
		curl_close( $ch );
		
		$header['errno']   = $err;
		$header['errmsg']  = $errmsg;
		$header['content'] = $content;
	return $header['content'];
}

//
function user_aget() {
	
		$random = array(
			1 => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
			2 => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36',
			3 => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
			4 => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2226.0 Safari/537.36',
			5 => 'Mozilla/5.0 (Windows NT 6.4; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36',
			6 => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36',
			7 => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36',
			8 => 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36',
			9 => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.67 Safari/537.36',
			
			10 => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) ChromePlus/4.0.222.3 Chrome/4.0.222.3 Safari/532.2',
			11 => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.28.3 (KHTML, like Gecko) Version/3.2.3 ChromePlus/4.0.222.3 Chrome/4.0.222.3 Safari/525.28.3',
			
			12 => 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1',
			13 => 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0',
			
			14 => 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko',
			15 => 'Mozilla/5.0 (compatible, MSIE 11, Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko',
			16 => 'Mozilla/5.0 (compatible; MSIE 10.6; Windows NT 6.1; Trident/5.0; InfoPath.2; SLCC1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 2.0.50727) 3gpp-gba UNTRUSTED/1.0',
			
			17 => 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
			18 => 'Mozilla/5.0 (Linux; U; Android 4.0.3; de-ch; HTC Sensation Build/IML74K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
			19 => 'Mozilla/5.0 (Linux; U; Android 2.3.5; zh-cn; HTC_IncredibleS_S710e Build/GRJ90) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			20 => 'Mozilla/5.0 (Linux; U; Android 2.3.4; fr-fr; HTC Desire Build/GRJ22) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			21 => 'Mozilla/5.0 (Linux; U; Android 2.3.3; zh-tw; HTC_Pyramid Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari',
			22 => 'Mozilla/5.0 (Linux; U; Android 2.3.3; de-de; HTC Desire Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			23 => 'Mozilla/5.0 (Linux; U; Android 2.2.1; en-gb; HTC_DesireZ_A7272 Build/FRG83D) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			24 => 'Mozilla/5.0 (Linux; U; Android 2.2.1; en-ca; LG-P505R Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			25 => 'Mozilla/5.0 (Linux; U; Android 2.3.4; en-us; T-Mobile myTouch 3G Slide Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			26 => 'Mozilla/5.0 (Linux; U; Android 4.0.3; en-us; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
			27 => 'Mozilla/5.0 (Linux; U; Android 2.3.3; en-us; LG-LU3000 Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			
			28 => 'Mozilla/5.0 (compatible; MSIE 9.0; Windows Phone OS 7.5; Trident/5.0; IEMobile/9.0)',
			
			29 => 'Opera/12.02 (Android 4.1; Linux; Opera Mobi/ADR-1111101157; U; en-US) Presto/2.9.201 Version/12.02',
			30 => 'Opera/9.80 (S60; SymbOS; Opera Mobi/SYB-1107071606; U; en) Presto/2.8.149 Version/11.10',
			31 => 'Opera/9.80 (Android 2.3.3; Linux; Opera Mobi/ADR-1111101157; U; en-US) Presto/2.9.201 Version/11.50',
			
			// Repeating the chrome browser ! (favorite browser)
			32 => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
			33 => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36',
			34 => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
			
		);
	
		$selected = strtr(rand(1,sizeof($random)), $random);
	
	return $selected;
}

//
function make_directory($dirpath, $mode=0777) {
	return is_dir($dirpath) || mkdir($dirpath, $mode, true);
}

//
function createPath($path) {
	if (is_dir($path)) return true;
	$prev_path = substr($path, 0, strrpos($path, '/', -2) + 1 );
	$return = createPath($prev_path);
	
	return ($return && is_writable($prev_path)) ? mkdir($path) : false;
}

//
function aquired_services() {
	
	return array(
		QOBUZSERVICE,
		// Add new external services here	
	);
	
}

//
function available_services($service_id) {
	
	$services_array = array(
		'1'			  =>		QOBUZSERVICE,
		'2'			  =>		QOBUZSERVICE,
		'3'			  =>		QOBUZSERVICE,
		'4'			  =>		QOBUZSERVICE,
		'5'			  =>		QOBUZSERVICE,
		'6'			  =>		QOBUZSERVICE,
		'7'			  =>		QOBUZSERVICE,
		'8'			  =>		QOBUZSERVICE,
		'9'			  =>		QOBUZSERVICE,
		
		
		// ''			  =>		some_other_service,
	);
	
	return strtr($service_id, $services_array);
}

//
function map_service_to_endpoint($service_id) {
	
	$services_array = array(
		'1'			  =>		QOBUZSERVICE . 'Album',
		'2'			  =>		QOBUZSERVICE . 'Artist',
		'3'			  =>		QOBUZSERVICE . 'Label',
		'4'			  =>		QOBUZSERVICE . 'Genre',
		'5'			  =>		QOBUZSERVICE . 'Track',
		'6'			  =>		QOBUZSERVICE . 'Award',
		'7'			  =>		QOBUZSERVICE . 'ArtistsImage',
		'8'			  =>		QOBUZSERVICE . 'Cover',
		'9'			  =>		QOBUZSERVICE . 'Booklet',
		
		
		// ''			  =>		some_other_service . 'Album',
	);
	
	return strtr($service_id, $services_array);
}

//
function map_endpoint_to_service($endpoint) {
	
	$endpoints_array = array(
		QOBUZSERVICE . 'Album'				=>		'1',
		QOBUZSERVICE . 'Artist'				=>		'2',
		QOBUZSERVICE . 'Label'				=>		'3',
		QOBUZSERVICE . 'Genre'				=>		'4',
		QOBUZSERVICE . 'Track'				=>		'5',
		QOBUZSERVICE . 'Award'				=>		'6',
		QOBUZSERVICE . 'ArtistsImage'		=>		'7',
		QOBUZSERVICE . 'Cover'				=>		'8',
		QOBUZSERVICE . 'Booklet'			=>		'9',
		
		
		// some_other_service . 'Album'			  =>		'',
	);
	
	return strtr($endpoint, $endpoints_array);
}

//
function construct_the_id($service_id, $extrenal_id) {
	
	$pattern_one_array = array(
		QOBUZSERVICE . 'Album',
		QOBUZSERVICE . 'Artist',
		QOBUZSERVICE . 'Label',
		QOBUZSERVICE . 'Genre',
		QOBUZSERVICE . 'Track',
		QOBUZSERVICE . 'Award',
	);
	
	$pattern_two_array = array(
		QOBUZSERVICE . 'ArtistsImage',
		QOBUZSERVICE . 'Cover',
		QOBUZSERVICE . 'Booklet',
	);

	if ( in_array($service_id, $pattern_one_array) )
	{
		$id = md5_encrypt(map_endpoint_to_service($service_id) . ':' . $extrenal_id, MD5_ID_MASTERKEY);
		
	} elseif ( in_array($service_id, $pattern_two_array) )
	{
		$id = md5_encrypt(map_endpoint_to_service($service_id) . ':' . $extrenal_id, MD5_EXTERNAL_RESOURCE);
		
	} elseif ( $service_id == QOBUZSERVICE . 'service_three_???' )
	{
		$id = md5_encrypt(map_endpoint_to_service($service_id) . ':' . $extrenal_id, MD5_ID_MASTERKEY);
		
	}
		
	return $id;
}

//
function replace_string($find, $replace, $string) {

	return str_replace($find, $replace, $string);
}

//
function status_code($status = 200, $message = ''){
	if ( $status == '200' )
	{
		http_response_code(200);
		header("Status: 200 OK");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"ok","code":200,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the api works perfectly.')) . ',"data":{}}}';
	} elseif ( $status == '201' )
	{
		http_response_code(201);
		header("Status: 201 Created");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"created","code":201,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the request has been fulfilled successfully.')) . ',"data":{}}}';
	} elseif ( $status == '202' )
	{
		http_response_code(202);
		header("Status: 202 Accepted");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"accepted","code":202,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the request has been accepted.')) . ',"data":{}}}';
	} elseif ( $status == '400' )
	{
		http_response_code(400);
		header("Status: 400 Bad Request");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"bad request","code":400,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('there was a problem with your request.')) . ',"data":{}}}';
	} elseif ( $status == '401' )
	{
		http_response_code(401);
		header("Status: 401 Unauthorized");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"unauthorized","code":401,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('access is denied due to invalid credentials.')) . ',"data":{}}}';
	} elseif ( $status == '402' )
	{
		http_response_code(402);
		header("Status: 402 Request Failed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"request failed","code":402,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('parameters were valid but request failed.')) . ',"data":{}}}';
	} elseif ( $status == '403' )
	{
		http_response_code(403);
		header("Status: 403 Forbidden");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"forbidden","code":403,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('no permission to access the resource.')) . ',"data":{}}}';
	} elseif ( $status == '404' )
	{
		http_response_code(404);
		header("Status: 404 Not Found");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"not found","code":404,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('no result is matched for given arguments.')) . ',"data":{}}}';
	} elseif ( $status == '412' )
	{
		http_response_code(412);
		header("Status: 412 Precondition Failed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"precondition failed","code":412,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server does not meet one of the preconditions.')) . ',"data":{}}}';
	} elseif ( $status == '417' )
	{
		http_response_code(417);
		header("Status: 417 Expectation Failed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"expectation failed","code":417,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server cannot meet the requirements.')) . ',"data":{}}}';
	} elseif ( $status == '422' )
	{
		http_response_code(422);
		header("Status: 422 Unprocessable Entity");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"unprocessable entity","code":422,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the request was well-formed but was unable to be followed')) . ',"data":{}}}';
	} elseif ( $status == '428' )
	{
		http_response_code(428);
		header("Status: 428 Precondition Required");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"precondition required","code":428,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server requires preconditions.')) . ',"data":{}}}';
	}
}

?>