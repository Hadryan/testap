<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';
// Asynchronous request
require dirname(__FILE__) . '/library/vendor/autoload.php';
use mpyw\Co\Co;
use mpyw\Co\CURLException;

//
function curl_async_put($url, array $options = [])
{
	$headers = array(
		"Content-Type: application/json",
	);
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "PUT",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_get($url, array $options = [])
{
	$headers = array(
		"Content-Type: application/json",
	);
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function process_purchase( $data_signature, $purchase_data, $app_id, $user_token, $session_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		$purchase_original = $purchase_data;
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			@$purchase_data = base64_decode($purchase_data);
			@$purchase_array = json_decode($purchase_data, true);
			
			@$purchase_order_id = $purchase_array['orderId'];
			@$purchase_product_id = $purchase_array['productId'];
			@$purchase_package_name = $purchase_array['packageName'];
			@$purchase_current_time = $purchase_array['purchaseTime'];
			@$purchase_payload = $purchase_array['developerPayload'];

			@$payload_data = base64_decode($purchase_payload);
			@$payload_array = json_decode($payload_data, true);
			
			@$payload_user_objectId = decrypt($payload_array['user_token']);
			@$payload_session_response = json_decode(decrypt($payload_array['session_id']), true);
			@$payload_provided_user_id = $payload_session_response[0];
			@$payload_product_id = $payload_array['product_id'];
			@$payload_package_name = $payload_array['package_name'];
			@$payload_current_time = $payload_array['current_time'];
			@$payload_app_id = $payload_array['app_id'];
			
			if ( ($payload_user_objectId != $payload_provided_user_id) || ($payload_product_id != $purchase_product_id) || ($payload_package_name != $purchase_package_name) || ( ($purchase_current_time - $payload_current_time) > 300 * 1000 /*5 min difference tolerance*/ ) )
			{
				echo status_code(403); // Faking the payload !
				exit;
			}
			
			$key =	"-----BEGIN PUBLIC KEY-----\n" . chunk_split(MYKET_PUBLIC_KEY_BASE64, 64,"\n") . '-----END PUBLIC KEY-----';
			// using PHP to create an RSA key
			$key = openssl_get_publickey($key);
			
			// $data_signature should be in binary format, but it comes as BASE64. So, I'll convert it.
			$data_signature = base64_decode($data_signature);
			
			// using PHP native support to verify the signature
			$result = openssl_verify(
						$purchase_data,
						$data_signature,
						$key,
			OPENSSL_ALGO_SHA1);
		
			if ( $result === 1 )
			{
				$package_to_value_array = package_to_value($purchase_product_id);
				$package_to_value_json = json_decode($package_to_value_array, true);
				$package_value = $package_to_value_json[0];
				$package_time_to_live = $package_to_value_json[1]; // TODO: define packages by time_to_live [EX: one week package]
				
				$get_counters = Co::wait([
				   
					"0" => function () use ($user_objectId, $package_value) {
						$content = (yield curl_async_put('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/counters/' . $user_objectId . '__' . 'user_total_purchases' . '/incrementby/get?value=' . $package_value));
						//yield Co::RETURN_WITH =>$content; // PHP 5.6
						return $content; // PHP 7+
					},
					
					"1" => function () use ($user_objectId) {
						$content = (yield curl_async_get('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/counters/' . $user_objectId . '__' . 'user_total_spent'));
						//yield Co::RETURN_WITH =>$content; // PHP 5.6
						return $content; // PHP 7+
					},
					
				]);
				
				$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $user_objectId;
				$relation_data = array(
					'user_total_purchases'		=> (int)checkSafeValue($get_counters[0], 0),
					'user_total_spent'			=> (int)checkSafeValue($get_counters[1], 0),
				);
				$database_headers = array(
					"Content-Type: application/json",
				);
				
				try {
					updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
				
				} catch (Exception $ex){
					sendError( 'processPurchase', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , purchase_data: ' . @$purchase_data . ' , app_id: ' . @$app_id . ' and time: ' . time() );
				}
				
				return status_code(201);
				
			} else { // Problem in validating
				echo status_code(403);
				exit;
			}
			
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_user, $op_time, $op_right){
	$output = '';
	$output .= '{';
	$output .= '"response":{';
	$output .= '"version":"' . APIVERSION . '",';
	$output .= '"status":"ok",';
	$output .= '"code":200,';
	$output .= '"message":"successful",';
	$output .= '"data":{';
	$output .= '"endpoint":"' . basename(__FILE__, '_functions.php') . '",';
	$output .= '"timestamp":' . $op_time . ',';
	$output .= '"results":' . json_encode($op_user) . ',';
	$output .= '"copyright":' . $op_right;
	$output .= '}';
	$output .= '}';
	$output .= '}';
		
	return $output;
}

?>