require('dotenv').config()
const express = require('express')
const cors = require('cors')
const morgan = require('morgan')
const port = process.env.PORT || 5001
const rabbitMQ = require('./rabbit-mq/producer')
const rabbitMQ2 = require('./rabbit-mq/worker')

const app = express()
app.use(cors())
app.use(morgan('tiny'))


app.get('/upsert/:version/album/:id', (request, response) => {
    rabbitMQ.sendToProcessQueue(request.params)
    return response.json({ message: 'Thanks!' })
})

app.use((request, response, next) => {
    const error = new Error('not found')
    response.status(404)
    next(error)
})

app.use((error, request, response, next) => {
    response.status(response.statusCode || 500)
    response.json({
        message: error.message
    })
})

app.listen(port)
