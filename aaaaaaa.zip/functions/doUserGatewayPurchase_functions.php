<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';
// Asynchronous request
require dirname(__FILE__) . '/library/vendor/autoload.php';
use mpyw\Co\Co;
use mpyw\Co\CURLException;

//
function curl_async_put($url, array $options = [], $user_token = '') {
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	}

	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "PUT",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_get($url, array $options = [], $user_token = '') {
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	};
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function verify_zibal_gateway_purchase( $status, $transaction_id, $purchase_id, $gateway, $app_id, $user_token, $session_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$zibal_gateway_parameters = array(
				"merchant"		=> ZIBAL_MERCHANT_KEY,
				"trackId"		=> $transaction_id,
			);
			
			$zibal_response = post_to_zibal('verify', $zibal_gateway_parameters);
			
			if ($zibal_response->result == 100)
			{
				$purchase_payload = json_decode(base64_decode($zibal_response->description), true);
				$purchase_ref_number = $zibal_response->refNumber;
				$purchase_order_id = $zibal_response->orderId;
				$purchase_card_number = $zibal_response->cardNumber;
				$purchase_amount = $zibal_response->amount;
				$timezone = 'Asia/Tehran';
				$purchase_current_time = strtotime($zibal_response->paidAt . ' ' . $timezone);
				
				$purchase_product_id = $purchase_payload['p'];
				$package_to_value_array = package_to_value($purchase_product_id);
				$package_to_value_json = json_decode($package_to_value_array, true);
				$package_value = $package_to_value_json[0];
				$package_time_to_live = $package_to_value_json[1];
				/*
				14-digit number 
					timestamp : 1506369011 --> 150636 + controlIfTimePackage[0,1] + package value + packageValueNormalPoints
					150636 + 1 + 003 + 0005 = 15063610030005
				*/
				
				$previous_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY_PER_USER . '/counters/' . $user_objectId . '__' . 'user_total_purchases';
				$previous_headers = array(
					"Content-Type: application/json",
					"user-token: " . $session_id_decrypted,
				);
				
				try {
					@$previous_results = getBackendlessResponse( $previous_url, $previous_headers, '' );
					
				} catch (Exception $ex){
					sendError( 'doUserPurchase_countersGet', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
				}
				
				if ( empty(json_decode($previous_results, true)['code']) )
				{
					if ( $previous_results == 0 ) // Previous results was empty, means new user
					{
						$genorous_time = time() + 86400; // until tomorrow
						$construction_time = substr($genorous_time + $package_time_to_live, 0, 6);
						
						if ( !is_null($package_time_to_live) ) // Time-based Packages
						{
							$construction_control_digit = 1;
							$construction_subscription_value = $package_value;
							$construction_normal_value = 0;
							
						} else // Normal Packages
						{
							$construction_control_digit = 0;
							$construction_subscription_value = 0;
							$construction_normal_value = $package_value;
						}
						
						$construction_count = $construction_time . $construction_control_digit . prepareLength($construction_subscription_value, 3, 0) . prepareLength($construction_normal_value, 4, 0);
						
					} else // We had purchases before
					{
						$previous_time = substr($previous_results, 0, 6);
						$previous_control_digit = substr($previous_results, 6, 1);
						$previous_subscription_value = substr($previous_results, 7, 3);
						$previous_normal_value = substr($previous_results, 10, 4);
						
						$genorous_time = time() + 86400; // until tomorrow
						$construction_time = substr($genorous_time + $package_time_to_live, 0, 6);
						
						if ( !is_null($package_time_to_live) ) // Time-based Packages [new package also time-based]
						{
							$construction_control_digit = 1;
							$construction_subscription_value = $package_value + $previous_subscription_value;
							$construction_normal_value = $previous_normal_value;
							$construction_time = max($previous_time, $construction_time);
							
						} else // Normal Packages
						{
							$construction_control_digit = 0;
							$construction_subscription_value = 0;
							$construction_normal_value = $package_value;
							
							if ( ($construction_control_digit == 1) || ($previous_control_digit == 1) ) // We check to see if the Previous buy is time-based or not [if it was time-based, we'll keep that information again]
							{							
								if ( substr($genorous_time, 0, 6) >= $previous_time ) // The previous package time is already expired! && [We are also generous here!, could be time() instead of $genorous_time]
								{
									$construction_control_digit = 0;
									$construction_subscription_value = 0;
									$construction_normal_value = $package_value + $previous_normal_value;
									$construction_time = $construction_time;
									
								} else // We still have time from previous package
								{
									$construction_control_digit = 1;
									$construction_subscription_value = $previous_subscription_value;
									$construction_normal_value = $package_value + $previous_normal_value;
									$construction_time = max($previous_time, $construction_time);
								}
								
							} else // The previous buy, wasn't time-based
							{
								$construction_control_digit = 0;
								$construction_subscription_value = 0;
								$construction_normal_value = $package_value + $previous_normal_value;
								$construction_time = $construction_time;
							}
							
						}
						
						$construction_count = $construction_time . $construction_control_digit . prepareLength($construction_subscription_value, 3, 0) . prepareLength($construction_normal_value, 4, 0);
						
					}
					
					$difference_value = $construction_count - $previous_results;
					
					$purchase_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users_Purchases';
					$set_purchase = array(
						'purchase_id'			  => $user_objectId . '__' . $purchase_product_id . '-' . $purchase_current_time,
						'purchase_package_name'	  => $purchase_product_id,
						'purchase_order_id'		  => $purchase_order_id,
						'purchase_ref_number'	  => $purchase_ref_number,
						'purchase_gateway'		  => $gateway,
						'purchase_card_number'	  => $purchase_card_number,
						'purchase_amount'		  => (double)$purchase_amount,
					);
					$database_headers = array(
						"Content-Type: application/json",
					);
					$purchase_headers = array(
						"Content-Type: application/json",
						"user-token: " . $session_id_decrypted,
					);
						
					try {
						@$purchase_results = updateBackendlessRequest( $purchase_url, $purchase_headers, json_encode($set_purchase) );
						@$purchase_results_array = json_decode($purchase_results, true);
						
					} catch (Exception $ex){
						sendError( 'setGatewayPurchase', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , transaction_id: ' . @$transaction_id . ' , purchase_id: ' . @$purchase_id . ' , status: ' . @$status . ' , app_id: ' . @$app_id . ' and time: ' . time() );
					}
					
					if ( !empty($purchase_results_array) )
					{
						if ( empty($purchase_results_array['code']) )
						{
							$purchase_owner_id = $purchase_results_array['ownerId'];
							$purchase_object_id = $purchase_results_array['objectId'];
							
							$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $purchase_owner_id . '/user_purchases';
							$relation_data = array(
								'objectId' 	 => $purchase_object_id
							);
							
							try {
								updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
								
							} catch (Exception $ex){
								sendError( 'setPurchase_relationUpdate', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , purchase_objectId: ' . @$purchase_object_id . ' , app_id: ' . @$app_id . ' and time: ' . time() );
							}
							
							$get_counters = Co::wait([
							
								"0" => function () use ($user_objectId, $package_value, $difference_value) {
									$content = (yield curl_async_put('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/counters/' . $user_objectId . '__' . 'user_total_purchases' . '/incrementby/get?value=' . $difference_value ));
									//yield Co::RETURN_WITH =>$content; // PHP 5.6
									return $content; // PHP 7+
								},
								
								"1" => function () use ($user_objectId) {
									$content = (yield curl_async_get('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $user_objectId . '?where=ownerId' . urlencode("='" . $user_objectId . "'")));
									//yield Co::RETURN_WITH =>$content; // PHP 5.6
									return $content; // PHP 7+
								},
								
							]);
							
							@$user_properties = json_decode($get_counters[1], true);
							@$user_properties_mobile = $user_properties["user_mobile"];
							
							$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $user_objectId;
							$relation_data = array(
								'user_total_purchases'		=> (double)checkSafeValue($get_counters[0], 0),
								'user_total_spent'			=> (double)checkSafeValue($user_properties["user_total_spent"], 0),
							);
							
							try {
								updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
								
							} catch (Exception $ex){
								sendError( 'doUserGatewayPurchase', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , transaction_id: ' . @$transaction_id . ' , purchase_id: ' . @$purchase_id . ' , status: ' . @$status . ' , app_id: ' . @$app_id . ' and time: ' . time() );
							}
							
							
							if ( !empty($user_properties_mobile) )
							{
								// Sending confirmation SMS
								$new_purchase_sms_text = sms_package_payments_confirmation($purchase_amount, $purchase_ref_number); // Purchase confirmation
								$new_purchase_sms_message = urlencode($new_purchase_sms_text);
								
								$process_sms = Co::wait([
									
									"0" => function () use ($user_properties_mobile, $new_purchase_sms_message) {
										$content = (yield send_sms_with_rayganSMS($user_properties_mobile, $new_purchase_sms_message ));
										//yield Co::RETURN_WITH =>$content; // PHP 5.6
										return $content; // PHP 7+
									},
									
								]);
							}
							
							$info_array = array(
								'user_download_quota'	=>	counter_to_packages((double)checkSafeValue($get_counters[0], 0), encrypt($user_objectId), $user_properties['user_subscription']),
							);
							$info_link = DEEPLINK_HOMEPAGE . '/' . base64_encode(json_encode($info_array));
							$info_button = DEEPLINK_BTTN_SUCCESS;
							$info_message = DEEPLINK_MSG_SUCCESS;
							// Sending the proper header type
							header("Content-type: text/html; charset=utf-8");
							return template_successful_gateway_payment($info_link, $info_button, $info_message);
							
						} else {
							//$reason = $database_results_array['message'];
							//echo status_code(401, $reason);
							//exit;
							// Sending the proper header type
							header("Content-type: text/html; charset=utf-8");
							$info_link = DEEPLINK_HOMEPAGE . '/';
							$info_button = DEEPLINK_BTTN_ERROR;
							$info_message = DEEPLINK_MSG_ERROR;
							return template_error_gateway_payment($info_link, $info_button, $info_message);
							
						}
					
					} else { // Nothing returned from the server
						//echo status_code(412, 'error adding to database!');
						//exit;
						// Sending the proper header type
						header("Content-type: text/html; charset=utf-8");
						$info_link = DEEPLINK_HOMEPAGE . '/';
						$info_button = DEEPLINK_BTTN_ERROR;
						$info_message = DEEPLINK_MSG_ERROR;
						return template_error_gateway_payment($info_link, $info_button, $info_message);
						
					}
				
				} else { // Expired session_id
					// Sending the proper header type
					header("Content-type: application/json; charset=utf-8");
					echo status_code(401);
					exit;
				}
				
			} else { // Zibal gateway wasn't successful! Maybe a faking request!
				sendError( 'doUserGatewayPurchase_zibalVerify', 'error', $zibal_response->result, $zibal_response->message, 'user_objectId: ' . @$user_objectId . ' , transaction_id: ' . @$transaction_id . ' , purchase_id: ' . @$purchase_id . ' , status: ' . @$status . ' , app_id: ' . @$app_id . ' and time: ' . time() );
				// Sending the proper header type
				header("Content-type: application/json; charset=utf-8");
				echo status_code(403);
				exit;
			}
			
		} else { // Invalid login
			// Sending the proper header type
			header("Content-type: application/json; charset=utf-8");
			echo status_code(403);
			exit;
		}
		
	} else {
		// Sending the proper header type
		header("Content-type: application/json; charset=utf-8");
		die(status_code(401));
		
	}
}

//
function verify_sep_gateway_purchase( $status, $transaction_id, $purchase_id, $gateway, $purchase_card_number, $purchase_amount, $purchase_ref_number, $purchase_product_id, $app_id, $user_token, $session_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$verify_url = "https://verify.sep.ir/Payments/ReferencePayment.asmx";
			
			$xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
			<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenc="http://www.w3.org/2003/05/soap-encoding" xmlns:tns="urn:Foo" xmlns:types="urn:Foo/encodedTypes" xmlns:rpc="http://www.w3.org/2003/05/soap-rpc" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
			  <soap12:Body soap12:encodingStyle="http://www.w3.org/2003/05/soap-encoding">
				<tns:verifyTransaction>
					<String_1 xsi:type="xsd:string">' . $transaction_id . '</String_1>
					<String_2 xsi:type="xsd:string">' . SEP_MERCHANT_KEY . '</String_2>
				</tns:verifyTransaction>
			</soap12:Body></soap12:Envelope>';
			
			$verify_headers = array(
				"POST /Payments/ReferencePayment.asmx HTTP/1.1",
				"Host: verify.sep.ir",
				"Content-Type: application/soap+xml; charset=utf-8",
				"Content-Length: ".strlen($xml_post_string)
			); 
			
			
			@$response = post_to_sep($verify_url, $xml_post_string, $verify_headers);
			
			@$xml = new SimpleXMLElement($response);
			@$result = $xml->xpath('/soap:Envelope/soap:Body/types:verifyTransactionResponse/result[1]');
			
			if ( isset($result) && ($result[0][0] == $purchase_amount) )
			{
				$purchase_current_time = $current_time;
				
				$package_to_value_array = package_to_value($purchase_product_id);
				$package_to_value_json = json_decode($package_to_value_array, true);
				$package_value = $package_to_value_json[0];
				$package_time_to_live = $package_to_value_json[1];
				/*
				14-digit number 
					timestamp : 1506369011 --> 150636 + controlIfTimePackage[0,1] + package value + packageValueNormalPoints
					150636 + 1 + 003 + 0005 = 15063610030005
				*/
				
				$previous_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY_PER_USER . '/counters/' . $user_objectId . '__' . 'user_total_purchases';
				$previous_headers = array(
					"Content-Type: application/json",
					"user-token: " . $session_id_decrypted,
				);
				
				try {
					@$previous_results = getBackendlessResponse( $previous_url, $previous_headers, '' );
					
				} catch (Exception $ex){
					sendError( 'doUserPurchase_countersGet', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
				}
				
				if ( empty(json_decode($previous_results, true)['code']) )
				{
					if ( $previous_results == 0 ) // Previous results was empty, means new user
					{
						$genorous_time = time() + 86400; // until tomorrow
						$construction_time = substr($genorous_time + $package_time_to_live, 0, 6);
						
						if ( !is_null($package_time_to_live) ) // Time-based Packages
						{
							$construction_control_digit = 1;
							$construction_subscription_value = $package_value;
							$construction_normal_value = 0;
							
						} else // Normal Packages
						{
							$construction_control_digit = 0;
							$construction_subscription_value = 0;
							$construction_normal_value = $package_value;
						}
						
						$construction_count = $construction_time . $construction_control_digit . prepareLength($construction_subscription_value, 3, 0) . prepareLength($construction_normal_value, 4, 0);
						
					} else // We had purchases before
					{
						$previous_time = substr($previous_results, 0, 6);
						$previous_control_digit = substr($previous_results, 6, 1);
						$previous_subscription_value = substr($previous_results, 7, 3);
						$previous_normal_value = substr($previous_results, 10, 4);
						
						$genorous_time = time() + 86400; // until tomorrow
						$construction_time = substr($genorous_time + $package_time_to_live, 0, 6);
						
						if ( !is_null($package_time_to_live) ) // Time-based Packages [new package also time-based]
						{
							$construction_control_digit = 1;
							$construction_subscription_value = $package_value + $previous_subscription_value;
							$construction_normal_value = $previous_normal_value;
							$construction_time = max($previous_time, $construction_time);
							
						} else // Normal Packages
						{
							$construction_control_digit = 0;
							$construction_subscription_value = 0;
							$construction_normal_value = $package_value;
							
							if ( ($construction_control_digit == 1) || ($previous_control_digit == 1) ) // We check to see if the Previous buy is time-based or not [if it was time-based, we'll keep that information again]
							{							
								if ( substr($genorous_time, 0, 6) >= $previous_time ) // The previous package time is already expired! && [We are also generous here!, could be time() instead of $genorous_time]
								{
									$construction_control_digit = 0;
									$construction_subscription_value = 0;
									$construction_normal_value = $package_value + $previous_normal_value;
									$construction_time = $construction_time;
									
								} else // We still have time from previous package
								{
									$construction_control_digit = 1;
									$construction_subscription_value = $previous_subscription_value;
									$construction_normal_value = $package_value + $previous_normal_value;
									$construction_time = max($previous_time, $construction_time);
								}
								
							} else // The previous buy, wasn't time-based
							{
								$construction_control_digit = 0;
								$construction_subscription_value = 0;
								$construction_normal_value = $package_value + $previous_normal_value;
								$construction_time = $construction_time;
							}
							
						}
						
						$construction_count = $construction_time . $construction_control_digit . prepareLength($construction_subscription_value, 3, 0) . prepareLength($construction_normal_value, 4, 0);
						
					}
					
					$difference_value = $construction_count - $previous_results;
					
					$purchase_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users_Purchases';
					$purchase_order_id = $purchase_id;
					$set_purchase = array(
						'purchase_id'			  => $user_objectId . '__' . $purchase_product_id . '-' . $purchase_current_time,
						'purchase_package_name'	  => $purchase_product_id,
						'purchase_order_id'		  => $purchase_order_id,
						'purchase_ref_number'	  => $purchase_ref_number,
						'purchase_gateway'		  => $gateway,
						'purchase_card_number'	  => $purchase_card_number,
						'purchase_amount'		  => (double)$purchase_amount,
					);
					$database_headers = array(
						"Content-Type: application/json",
					);
					$purchase_headers = array(
						"Content-Type: application/json",
						"user-token: " . $session_id_decrypted,
					);
						
					try {
						@$purchase_results = updateBackendlessRequest( $purchase_url, $purchase_headers, json_encode($set_purchase) );
						@$purchase_results_array = json_decode($purchase_results, true);
						
					} catch (Exception $ex){
						sendError( 'setGatewayPurchase', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , transaction_id: ' . @$transaction_id . ' , purchase_id: ' . @$purchase_id . ' , status: ' . @$status . ' , app_id: ' . @$app_id . ' and time: ' . time() );
					}
					
					if ( !empty($purchase_results_array) )
					{
						if ( empty($purchase_results_array['code']) )
						{
							$purchase_owner_id = $purchase_results_array['ownerId'];
							$purchase_object_id = $purchase_results_array['objectId'];
							
							$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $purchase_owner_id . '/user_purchases';
							$relation_data = array(
								'objectId' 	 => $purchase_object_id
							);
							
							try {
								updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
								
							} catch (Exception $ex){
								sendError( 'setPurchase_relationUpdate', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , purchase_objectId: ' . @$purchase_object_id . ' , app_id: ' . @$app_id . ' and time: ' . time() );
							}
							
							$get_counters = Co::wait([
							
								"0" => function () use ($user_objectId, $package_value, $difference_value) {
									$content = (yield curl_async_put('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/counters/' . $user_objectId . '__' . 'user_total_purchases' . '/incrementby/get?value=' . $difference_value ));
									//yield Co::RETURN_WITH =>$content; // PHP 5.6
									return $content; // PHP 7+
								},
								
								"1" => function () use ($user_objectId) {
									$content = (yield curl_async_get('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $user_objectId . '?where=ownerId' . urlencode("='" . $user_objectId . "'")));
									//yield Co::RETURN_WITH =>$content; // PHP 5.6
									return $content; // PHP 7+
								},
								
							]);
							
							@$user_properties = json_decode($get_counters[1], true);
							@$user_properties_mobile = $user_properties["user_mobile"];
							
							$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $user_objectId;
							$relation_data = array(
								'user_total_purchases'		=> (double)checkSafeValue($get_counters[0], 0),
								'user_total_spent'			=> (double)checkSafeValue($user_properties["user_total_spent"], 0),
							);
							
							try {
								updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
								
							} catch (Exception $ex){
								sendError( 'doUserGatewayPurchase', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , transaction_id: ' . @$transaction_id . ' , purchase_id: ' . @$purchase_id . ' , status: ' . @$status . ' , app_id: ' . @$app_id . ' and time: ' . time() );
							}
							
							
							if ( !empty($user_properties_mobile) )
							{
								// Sending confirmation SMS
								$new_purchase_sms_text = sms_package_payments_confirmation($purchase_amount, $purchase_ref_number); // Purchase confirmation
								$new_purchase_sms_message = urlencode($new_purchase_sms_text);
								
								$process_sms = Co::wait([
									
									"0" => function () use ($user_properties_mobile, $new_purchase_sms_message) {
										$content = (yield send_sms_with_rayganSMS($user_properties_mobile, $new_purchase_sms_message ));
										//yield Co::RETURN_WITH =>$content; // PHP 5.6
										return $content; // PHP 7+
									},
									
								]);
							}
							
							$info_array = array(
                                'user_download_quota'	=>	counter_to_packages((double)checkSafeValue($get_counters[0], 0), encrypt($user_objectId), $user_properties['user_subscription']),

                            );
							$info_link = DEEPLINK_HOMEPAGE . '/' . base64_encode(json_encode($info_array));
							$info_button = DEEPLINK_BTTN_SUCCESS;
							$info_message = DEEPLINK_MSG_SUCCESS;
							// Sending the proper header type
							header("Content-type: text/html; charset=utf-8");
							return template_successful_gateway_payment($info_link, $info_button, $info_message);
							
						} else {
							//$reason = $database_results_array['message'];
							//echo status_code(401, $reason);
							//exit;
							// Sending the proper header type
							header("Content-type: text/html; charset=utf-8");
							$info_link = DEEPLINK_HOMEPAGE . '/';
							$info_button = DEEPLINK_BTTN_ERROR;
							$info_message = DEEPLINK_MSG_ERROR;
							return template_error_gateway_payment($info_link, $info_button, $info_message);
							
						}
					
					} else { // Nothing returned from the server
						//echo status_code(412, 'error adding to database!');
						//exit;
						// Sending the proper header type
						header("Content-type: text/html; charset=utf-8");
						$info_link = DEEPLINK_HOMEPAGE . '/';
						$info_button = DEEPLINK_BTTN_ERROR;
						$info_message = DEEPLINK_MSG_ERROR;
						return template_error_gateway_payment($info_link, $info_button, $info_message);
						
					}
				
				} else { // Expired session_id
					// Sending the proper header type
					header("Content-type: application/json; charset=utf-8");
					echo status_code(401);
					exit;
				}
				
			} else { // Zibal gateway wasn't successful! Maybe a faking request!
				sendError( 'doUserGatewayPurchase_sepVerify', 'error', @$zibal_response->result, @$zibal_response->message, 'user_objectId: ' . @$user_objectId . ' , transaction_id: ' . @$transaction_id . ' , purchase_id: ' . @$purchase_id . ' , status: ' . @$status . ' , app_id: ' . @$app_id . ' and time: ' . time() );
				// Sending the proper header type
				header("Content-type: application/json; charset=utf-8");
				echo status_code(403);
				exit;
			}
			
		} else { // Invalid login
			// Sending the proper header type
			header("Content-type: application/json; charset=utf-8");
			echo status_code(403);
			exit;
		}
		
	} else {
		// Sending the proper header type
		header("Content-type: application/json; charset=utf-8");
		die(status_code(401));
		
	}
}
?>