<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';


//
function get_affiliations( $limit, $offset, $app_id, $user_token, $session_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY_PER_USER . '/data/Users_Affiliations';
			$database_headers = array(
				"Content-Type: application/json",
				"user-token: " . $session_id_decrypted,
			);
			$database_where = '?where=ownerId' . urlencode("='" . $user_objectId . "'") . '&pageSize=' . $limit . '&offset=' . $offset . '&sortBy=created%20desc';
		
			try {
				@$database_results = getBackendlessResponse( $database_url, $database_headers, $database_where );
				@$database_results_array = json_decode($database_results, true);
		
			} catch (Exception $ex){
				sendError( 'getUserAffiliations', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}
		
		
			if ( !empty($database_results_array) )
			{
				if ( empty($database_results_array['code']) )
				{
					$database_results_array = isset($database_results_array[0]) ? $database_results_array : array($database_results_array);
					foreach($database_results_array as $num => $data) {
						$items[] = array(
							'affiliation_can_use'		   => $data['affiliation_can_use'],
							'affiliation_code'			   => $data['affiliation_code'],
							'affiliation_target_name'	   => $data['affiliation_target_name'],
							'affiliation_target_gender'	   => $data['affiliation_target_gender'],
							'object_id'					   => encrypt($data['objectId']),
							'created'					   => round($data['created'] / 1000),
						);
					}
					
					
					@$op_time = $current_time;
					@$op_user_token = $user_token;
					@$op_limit = (int)$limit;
					@$op_offset = (int)$offset;
					@$op_results = $items;
					@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
					
					$export = response_json($op_time, $op_user_token, $op_limit, $op_offset, $op_results, $op_right);
					return $export;
					
				} else {
					//$reason = $database_results_array['code']; // TODO: Change in production
					//echo status_code(400, $reason);
					$reason = $database_results_array['message'];
					echo status_code(400, $reason);
					exit;
				}
				
			} else { // Nothing returned from the server [@MINWANG: Changed the status code from 404 to 200, even if the result is empty 12.07.17 04:11 AM ]
				echo status_code(200, 'successfully processed');
				exit;
			}
		
		} else {
			echo status_code(412);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_time, $op_user_token, $op_limit, $op_offset, $op_results, $op_right){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'user_token'	=> $op_user_token,
				'offset'		=> $op_offset,
				'limit'			=> $op_limit,
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}

?>