<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';


//
function set_points( $points_type, $app_id, $user_token, $session_id ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		// TODO:	In Production	
		//$construct_time = date("YmdH") . (round(scale_normalize_number(date("i"), 1, 10)) + 1); // In one hour [=59 min], we allow only 7 times update [60 / 6 = 10]
		$construct_time = date("YmdHs");
		
		if ( $user_objectId == $provided_user_id )
		{
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users_Points';
			$database_headers = array(
				"Content-Type: application/json",
				"user-token: " . $session_id_decrypted,
			);
			////$database_where = '?where=ownerId' . urlencode("='" . $user_objectId . "'") . urlencode(" AND last_interaction_type='" . $points_type . "'") . '&pageSize=1' . '&sortBy=created%20desc';
			$database_where = '?where=ownerId' . urlencode("='" . $user_objectId . "'") . '&pageSize=1' . '&sortBy=created%20desc';
			
			try {
				@$database_results = getBackendlessResponse( $database_url, $database_headers, $database_where );
				@$database_results_array = json_decode($database_results, true);
			
			} catch (Exception $ex){
				sendError( 'setUserPoints', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , points_type: ' . @$points_type . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}
			
			if ( empty($database_results_array['code']) )
			{
				$database_results_array = isset($database_results_array[0]) ? $database_results_array : array($database_results_array);
				
				switch ($points_type) 
				{
					case "preview_tracks":
						$node = "points_preview_tracks";
						@$node_value = (int)$database_results_array[0]['points_preview_tracks'] + POINTS_PREVIEW_TRACKS;
						$correction = 1;
						break;
					case "buy_tracks":
						$node = "points_buy_tracks";
						@$node_value = (int)$database_results_array[0]['points_buy_tracks'] + POINTS_BUY_TRACKS;
						$correction = 2;
						break;
					case "buy_albums":
						$node = "points_buy_albums";
						@$node_value = (int)$database_results_array[0]['points_buy_albums'] + POINTS_BUY_ALBUMS;
						$correction = 3;
						break;
					case "intract_app":
						$node = "points_intract_app";
						@$node_value = (int)$database_results_array[0]['points_intract_app'] + POINTS_INTRACT_APP;
						$correction = 4;
						break;
					case "enqueue_tracks":
						$node = "points_enqueue_tracks";
						@$node_value = (int)$database_results_array[0]['points_enqueue_tracks'] + POINTS_ENQUEUE_TRACKS;
						$correction = 5;
						break;
					case "replay_tracks":
						$node = "points_replay_tracks";
						@$node_value = (int)$database_results_array[0]['points_replay_tracks'] + POINTS_REPLAY_TRACKS;
						$correction = 6;
						break;
					case "set_favorites":
						$node = "points_set_favorites";
						@$node_value = (int)$database_results_array[0]['points_set_favorites'] + POINTS_SET_FAVORITES;
						$correction = 7;
						break;
					case "unset_favorites":
						$node = "points_unset_favorites";
						@$node_value = (int)$database_results_array[0]['points_unset_favorites'] + POINTS_UNSET_FAVORITES;
						$correction = 8;
						break;
				}
				
				if ( ($user_objectId . '_' . $correction . '-' . $construct_time) != @$database_results_array[0]['last_interaction_time'] )
				{					
					@$data_set_points = array(
						'last_interaction_time'		   => $user_objectId . '_' . $correction . '-' . $construct_time,
						'last_interaction_type'		   => $points_type,
						'points_preview_tracks'		   => (int)$database_results_array[0]['points_preview_tracks'],
						'points_buy_tracks'			   => (int)$database_results_array[0]['points_buy_tracks'],
						'points_replay_tracks'		   => (int)$database_results_array[0]['points_replay_tracks'],
						'points_enqueue_tracks'		   => (int)$database_results_array[0]['points_enqueue_tracks'],
						'points_buy_albums'			   => (int)$database_results_array[0]['points_buy_albums'],
						'points_intract_app'		   => (int)$database_results_array[0]['points_intract_app'],
						'points_set_favorites'		   => (int)$database_results_array[0]['points_set_favorites'],
						'points_unset_favorites'	   => (int)$database_results_array[0]['points_unset_favorites'],
						$node	  					   => $node_value,
					);
						
					try {
						@$database_results = updateBackendlessRequest( $database_url, $database_headers, json_encode($data_set_points) );
						@$database_results_array = json_decode($database_results, true);
						
					} catch (Exception $ex){
						sendError( 'setUserPoints', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , points: ' . @$node . '=' . @$node_value . ' , app_id: ' . @$app_id . ' and time: ' . time() );
					}
					
					if ( !empty($database_results_array) )
					{
						if ( empty($database_results_array['code']) )
						{
							$created_owner_id = $database_results_array['ownerId'];
							$created_object_id = $database_results_array['objectId'];
							
							$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $created_owner_id . '/user_points';
							$relation_data = array(
								'objectId' 	 => $created_object_id
							);
							
							try {
								updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
							
							} catch (Exception $ex){
								sendError( 'setUserPoints_relationUpdate', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , points_objectId: ' . @$created_object_id . ' , app_id: ' . @$app_id . ' and time: ' . time() );
							}
							
							return status_code(201);
							
						} else {
							//$reason = $database_results_array['code']; // TODO: Change in production
							//echo status_code(401, $reason);
							$reason = $database_results_array['message'];
							echo status_code(401, $reason);
							exit;
						}
					
					} else { // Nothing returned from the server [@MINWANG: Changed the status code from 404 to 200, even if the result is empty 12.07.17 04:11 AM ]
						echo status_code(200, 'successfully processed');
						exit;
					}
					
				} else {
					echo status_code(402);
					exit;
				}
				
			} else {
				echo status_code(412);
				exit;
			}
		
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json(){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'success',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> json_decode('{}')
		)
	);
	
	return json_encode($output);
}

?>