<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';


//
function do_password_reset( $user_login, $app_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/users/restorepassword' . '/' . urlencode($user_login);
		$database_headers = array(
			"Content-Type: application/json",
		);
			
		try {
			@$database_results = getBackendlessResponse( $database_url, $database_headers, '' );
			@$database_results_array = json_decode($database_results, true);
			
		} catch (Exception $ex){
			sendError( 'doUserPasswordReset', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_login: ' . @$user_login . ' , app_id: ' . @$app_id . ' and time: ' . time() );
		}
		
		if ( empty($database_results_array['code']) )
		{
			return status_code(200, 'done! check your email.');
			
		} else {
			$reason = $database_results_array['code'];
			echo status_code(400, $reason);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json(){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'success',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> json_decode('{}')
		)
	);
	
	return json_encode($output);
}

?>