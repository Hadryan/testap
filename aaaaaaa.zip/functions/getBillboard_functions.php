<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';

function temp_md5_decrypt($id){
	$decrypted_id = remove_non_utf8(md5_decrypt($id, MD5_ID_MASTERKEY));
	$constructed_id = explode(':', $decrypted_id);
	return $constructed_id[1];
}

//
function get_billboard( $type, $limit, $offset, $genre_ids = '') {

	$genre_ids_original = $genre_ids;	
	if ( !empty($genre_ids) )
	{
		$genre_ids = implode(",", array_map('temp_md5_decrypt', explode(',', $genre_ids )));
	}
		
	$query = 'http://i-serp.com/fetchFeatured.php?q=' . $type . '&l=' . $limit . '&o=' . $offset . ( $genre_ids ? '&g=' . $genre_ids : '');
	@$raw_data = stream_open($query, 'http://i-serp.com/', 'i-serp.com');
	@$data = json_decode($raw_data, true);
	
	if ( @$data["status"] == "error" || empty($data) ) 
	{
		$query = 'http://muism.com/v1/fetchFeatured.php?q=' . $type . '&l=' . $limit . '&o=' . $offset . ( $genre_ids ? '&g=' . $genre_ids : '');
		@$raw_data = stream_open($query, 'http://muism.com/', 'muism.com');
		@$data = json_decode($raw_data, true);
			
			if ( @$data["status"] == "error" || empty($data) ) 
			{
				$query = ORIGINALAPI . 'album/getFeatured?app_id=' . ORIGINALAPPID . '&type=' . $type . '&limit=' . $limit . '&offset=' . $offset . ( $genre_ids ? '&genre_ids=' . $genre_ids : '');
				@$raw_data = stream_open($query, 'http://www.qobuz.com/', 'www.qobuz.com');
				@$data = json_decode($raw_data, true);
			}
	}
	
	@$parent_response_offset = $data['albums']['offset'];
	@$parent_response_limit = $data['albums']['limit'];
	@$parent_response_total = $data['albums']['total'];
	@$parent_response_items = $data['albums']['items'];
	$current_time = time();
	$reduced_from_total = 0;
	
	// Foreach correction ! http://stackoverflow.com/a/15150384
	$response_array = isset($parent_response_items[0]) ? $parent_response_items : array($parent_response_items);
	foreach($response_array as $itme_num => $data) {
		if ( !empty($data) && empty($data['status']) )
		{
			if ( filter_unwanted_albums($data["id"]) == 1 )
			{
				$reduced_from_total++;
				continue;
				
			} else {
				
				@$data_id = $data["id"];
				@$data_title = $data["title"];
				@$data_composer = $data["composer"]["name"];
				@$data_artist = $data["artist"]["name"];
				@$data_label = $data["label"]["name"];
			
				@$data_genre_id_1 = $data["genre"]["path"][0];
				@$data_genre_id_2 = $data["genre"]["path"][1];
				@$data_genre_id_3 = $data["genre"]["path"][2];
				@$data_genre_id_4 = $data["genre"]["path"][3];
			
				@$data_released = $data["released_at"];	
				@$data_duration = $data["duration"];
				@$data_media = $data["media_count"];
				@$data_tracks = $data["tracks_count"];
				@$data_hires = $data["hires"];
			
				@$data_popularity = $data["popularity"];
				@$data_product_sales_weekly = $data["product_sales_factors_weekly"];
				@$data_product_sales_monthly = $data["product_sales_factors_monthly"];
				@$data_product_sales_yearly = $data["product_sales_factors_yearly"];
			
			
				@$album_id = checkSafeValue( construct_the_id(QOBUZSERVICE . 'Album', $data_id), null );
				@$album_title = hdryn_change_france($data_title);
				@$album_genre = construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_1);
				@$album_artist = hdryn_change_france($data_artist);
				@$album_label = $data_label;
				@$album_released_at = $data_released;
				@$album_duration = $data_duration;
				@$album_media_count = $data_media;
				@$album_tracks_count = $data_tracks;
				@$album_hires = $data_hires;
				
				$query_string_data = array(
					"id"		   	 			   => $album_id,
					"title"						   => $album_title,
					"artist"					   => (!empty($album_artist) ? $album_artist : null),
					"label"						   => (!empty($album_label) ? $album_label : null),
					"genre"						   => $album_genre,
					"media_count"				   => $album_media_count,
					"tracks_count"				   => $album_tracks_count,
					"duration"					   => $album_duration,
					"released_at"				   => $album_released_at,
					"hires"						   => $album_hires
				);
				$query_string_data = encrypt(json_encode($query_string_data));
			
				@$album_image = array(
						"1080"  => ASSETSSERVER . 'getBillboardCover.php?size=1080' . '&data=' . $query_string_data . '&id=' . $album_id . '.jpg',
						"750"  => ASSETSSERVER . 'getBillboardCover.php?size=750' . '&data=' . $query_string_data . '&id=' . $album_id . '.jpg',
						"21"  => ASSETSSERVER . 'getBillboardCover.php?size=21' . '&data=' . $query_string_data . '&id=' . $album_id . '.jpg',
					);
				
				$items[] = array(
					"id"		   	 			   => $album_id,
					"title"						   => $album_title,
					"artist"					   => (!empty($album_artist) ? $album_artist : null),
					"label"						   => (!empty($album_label) ? $album_label : null),
					"image"						   => $album_image,
					"genre"						   => $album_genre,
					"media_count"				   => $album_media_count,
					"tracks_count"				   => $album_tracks_count,
					"duration"					   => $album_duration,
					"released_at"				   => $album_released_at,
					"hires"						   => $album_hires
				);
			
				unset($album_image);
			}
			
		} else { // Nothing returned from the server
			echo status_code(404);
			exit;
		}
	}
	

	@$op_time = $current_time;
	@$op_offset = $parent_response_offset;
	@$op_limit = $parent_response_limit;
	@$op_total = $parent_response_total - $reduced_from_total;
	@$op_more_results = has_more_results($op_offset, $op_limit, $parent_response_total);
	@$op_results = $items;
	@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
	@$op_url = '';
	
	$export = response_json($op_time, $op_offset, $op_limit, $op_total, $op_results, $op_right, $op_url, $op_more_results);
	// Creating temporary cache file
	temp_creator_on_server( basename(__FILE__, '_functions.php'), 'billboard' . back_category_type($type) . $limit . $offset . $genre_ids_original, $export );
	
	return $export;

}

//
function response_json($op_time, $op_offset, $op_limit, $op_total, $op_results, $op_right, $op_url = '', $op_more_results){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'offset'		=> $op_offset,
				'limit'			=> $op_limit,
				'total'			=> $op_total,
				'more_results'	=> $op_more_results,
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}
?>