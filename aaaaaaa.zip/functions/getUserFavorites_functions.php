<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';


//
function get_favorites( $favorite_type, $limit, $offset, $app_id, $user_token, $session_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY_PER_USER . '/data/Users_Favorites';
			$database_headers = array(
				"Content-Type: application/json",
				"user-token: " . $session_id_decrypted,
			);
			if ( $favorite_type == 'all' )
			{
				$database_where = '?where=ownerId' . urlencode("='" . $user_objectId . "'") . '&pageSize=' . $limit . '&offset=' . $offset . '&sortBy=created%20desc';
			} else {
				$database_where = '?where=ownerId' . urlencode("='" . $user_objectId . "'") . urlencode(" AND favorite_type='" . $favorite_type . "'") . '&pageSize=' . $limit . '&offset=' . $offset . '&sortBy=created%20desc';
			}
		
			try {
				@$database_results = getBackendlessResponse( $database_url, $database_headers, $database_where );
				@$database_results_array = json_decode($database_results, true);
		
			} catch (Exception $ex){
				sendError( 'getUserFavorites', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}
		
		
			if ( !empty($database_results_array) )
			{
				if ( empty($database_results_array['code']) )
				{
					// Now, we count the number of result
					$count_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users_Favorites/count';
					$count_headers = array(
						"Content-Type: application/json",
					);
					
					if ( $favorite_type == 'all' )
					{
						$count_where = '?where=ownerId' . urlencode("='" . $user_objectId . "'");
					} else {
						$count_where = '?where=ownerId' . urlencode("='" . $user_objectId . "'") . urlencode(" AND favorite_type='" . $favorite_type . "'");
					}
					
					try {
						@$count_results = getBackendlessResponse( $count_url, $count_headers, $count_where );
						@$count_results_array = json_decode($count_results, true);
					
					} catch (Exception $ex){
						sendError( 'getUserFavorites_count', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
					}
					
					$database_results_array = isset($database_results_array[0]) ? $database_results_array : array($database_results_array);
					foreach($database_results_array as $num => $data) {
						
						if ( available_services($data['service_id']) == QOBUZSERVICE )
						{
							preg_match("/(.*)_(.*)/", $data['favorite_id'], $favorite_id_array);
							
							@$favorite_image = array(
									"50"   => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 50 . ':' . $data['image_id']) . '.jpg',
									"230"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 230 . ':' . $data['image_id']) . '.jpg',
									"600"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 600 . ':' . $data['image_id']) . '.jpg',
								);
								
							$_favorite_type = $data['favorite_type'];
							if ( $_favorite_type == 'albums' )
							{
								$favorite_id = construct_the_id(QOBUZSERVICE . 'Album', $favorite_id_array[2]);
								
							} elseif ( $_favorite_type == 'tracks' )
							{
								$favorite_id = construct_the_id(QOBUZSERVICE . 'Track', $favorite_id_array[2]);
								
							} elseif ( $_favorite_type == 'artists' )
							{
								$favorite_id = construct_the_id(QOBUZSERVICE . 'Artist', $favorite_id_array[2]);
								
							} elseif ( $_favorite_type == 'labels' )
							{
								$favorite_id = construct_the_id(QOBUZSERVICE . 'Label', $favorite_id_array[2]);
								
							}
	
							$items[] = array(						
								'favorite_id'		  => $favorite_id,
								'favorite_parent_id'  => construct_the_id(QOBUZSERVICE . 'Album', $data['image_id']),
								'favorite_type'		  => $data['favorite_type'],
								'favorite_name'		  => $data['favorite_name'],
								'favorite_more'		  => $data['favorite_more'],
								'favorite_image'	  => $favorite_image,
								'object_id'			  => encrypt($data['objectId']),
								'created'			  => round($data['created'] / 1000),
							);
							
						} // else : other services
						
					}
			
			
					@$op_time = $current_time;
					@$op_query = $favorite_type;
					@$op_user_token = $user_token;
					@$op_total = (int)$count_results_array;
					@$op_limit = (int)$limit;
					@$op_offset = (int)$offset;
					@$op_more_results = has_more_results($op_offset, $op_limit, $count_results_array);
					@$op_results = $items;
					@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
			
					$export = response_json($op_time, $op_query, $op_user_token, $op_total, $op_limit, $op_offset, $op_results, $op_right, $op_more_results);
					return $export;
					
				} else {
					//$reason = $database_results_array['code']; // TODO: Change in production
					//echo status_code(401, $reason);
					$reason = $database_results_array['message'];
					echo status_code(401, $reason);
					exit;
				}
				
			} else { // Nothing returned from the server [@MINWANG: Changed the status code from 404 to 200, even if the result is empty 12.07.17 04:11 AM ]
				echo status_code(200, 'successfully processed');
				exit;
			}
		
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_time, $op_query, $op_user_token, $op_total, $op_limit, $op_offset, $op_results, $op_right, $op_more_results){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'query'			=> $op_query,
				'user_token'	=> $op_user_token,
				'offset'		=> $op_offset,
				'limit'			=> $op_limit,
				'total'			=> $op_total,
				'more_results'	=> $op_more_results,
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}

?>