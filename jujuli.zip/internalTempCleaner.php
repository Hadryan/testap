<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(144);

header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 19 Jul 1999 09:09:09 GMT");

define("TEMPORARY",  	 "tempDirectory");

	if ( isset($_GET['p']) && $_GET['p'] == 'gsdfi764837t5g' ) // password to access
	{
		ob_start();
		if ( isset($_GET['r']) )
		{
			@$range = $_GET['r'];
			
		} elseif ( isset($_POST['r']) )
		{
			@$range = $_POST['r'];
			
		}
		
		if ( empty($range) )
		{
			$range = 'jHY_'; // 60 seconds ! 
		}
		
		$start_time = time(); // now !
		
		
		@$range = decrypt($range);
		
		$tmp_folder = $_SERVER['DOCUMENT_ROOT'] . '/' . TEMPORARY . '/';
		$number = '';
		
		$directory = new RecursiveDirectoryIterator($tmp_folder, FilesystemIterator::SKIP_DOTS);
		$files = new RecursiveIteratorIterator($directory, RecursiveIteratorIterator::CHILD_FIRST);
		
		
		foreach ($files as $num => $file) {
			if (!$file->isDir()) {
				if ( ($start_time - filemtime($file)) > $range  ) {
					unlink($file->getRealPath());
				}
			}
			$number = $num;
		}
		
		ob_end_clean();
		
		
		//=================================================================
			$dummy = '';
			$dummy .= '<table border="1" cellpadding="1" cellspacing="1" style="width: 500px;">';
			$dummy .= '<tbody>';
			$dummy .= '<tr>';
			$dummy .= '<td>' . basename(__FILE__, '.php') . ' - ' . $number . '</td>';
			$dummy .= '<td>' . date("d M Y H:i:s") . '</td>';
			$dummy .= '</tr>';
			$dummy .= '</tbody>';
			$dummy .= '</table>';
				
			echo $dummy;
			
		//=================================================================
		
	}
//
function encrypt($str){
  $key = "F2avHrF62o8jLZFREEEEN65zs7otsXV";
  $result = '';
  for($i=0; $i<strlen($str); $i++) {
     $char = substr($str, $i, 1);
     $keychar = substr($key, ($i % strlen($key))-1, 1);
     $char = chr(ord($char)+ord($keychar));
     $result.=$char;
  }
  return safe_b64encode($result);
}

//
function decrypt($str){
  $str = safe_b64decode($str);
  $result = '';
  $key = "F2avHrF62o8jLZFREEEEN65zs7otsXV";
  for($i=0; $i<strlen($str); $i++) {
    $char = substr($str, $i, 1);
    $keychar = substr($key, ($i % strlen($key))-1, 1);
    $char = chr(ord($char)-ord($keychar));
    $result.=$char;
  }
return $result;
}

//
function safe_b64encode($string) {
	$data = base64_encode($string);
	$data = str_replace(array('+','/','='),array('-','~','_'),$data);
	return $data;
}

//
function safe_b64decode($string) {
	$data = str_replace(array('-','~','_'),array('+','/','='),$string);
	$mod4 = strlen($data) % 4;
	if ($mod4) {
			$data .= substr('====', $mod4);
	}
	return base64_decode($data);
}

?>
