<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';
// Asynchronous request
require dirname(__FILE__) . '/library/vendor/autoload.php';
use mpyw\Co\Co;
use mpyw\Co\CURLException;

//
function curl_async_put($url, array $options = [], $user_token = ''){
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	}

	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "PUT",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_post($url, array $headers = [], array $data = [], array $options = []){
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => json_encode($data),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_get($url, array $options = [], $user_token = ''){
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	};
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}


//
function get_charts_list( $limit, $offset, $app_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Platform_Moods';
		$database_headers = array(
			"Content-Type: application/json",
		);
		$database_where = '?where=is_active' . urlencode("='" . true . "'") . '&pageSize=' . $limit . '&offset=' . $offset . '&sortBy=updated%20desc';
		
		$get_counters = Co::wait([
			
			"0" => function () use ( $database_url, $database_headers, $database_where ) {
				$content = (yield getBackendlessResponse( $database_url, $database_headers, $database_where ));
				//yield Co::RETURN_WITH =>$content; // PHP 5.6
				return $content; // PHP 7+
			},
			
			"1" => function () use ( $database_headers ) {
				$content = (yield curl_async_get('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Platform_Moods?where=' . rawurlencode('is_active=') . 1 . '&props=Count(objectId)'));
				//yield Co::RETURN_WITH =>$content; // PHP 5.6
				return $content; // PHP 7+
			},
			
		]);
		
		@$database_results_array = json_decode($get_counters[0], true);
		@$total_results_array = json_decode($get_counters[1], true);
		
		
		if ( !empty($database_results_array) )
		{
			if ( empty($database_results_array['code']) )
			{
				$database_results_array = isset($database_results_array[0]) ? $database_results_array : array($database_results_array);
				foreach($database_results_array as $num => $data) {
					$items[] = array(
						'endpoint'				   => $data['endpoint'],
						'id_type' 	   			   => $data['id_type'],
						'limit'    	   			   => $data['limit'],
						'offset'  		   		   => $data['offset'],
						'genre_query'   		   => $data['genre_query'],
						'is_paginatable'  		   => (bool)$data['is_paginatable'],
						'gradient_start' 	  	   => '#' . $data['gradient_start'],
						'gradient_end' 		  	   => '#' . $data['gradient_end'],
						'gradient_degree' 		   => (int)$data['gradient_degree'],
						'gradient_opacity' 		   => (int)$data['gradient_opacity'] / 100,
						'text_color' 			   => '#' . $data['text_color'],
						'name' 		  	 	   	   => $data['name'],
						'name_fa' 		  	 	   => $data['name_fa'],
						'description' 		  	   => $data['description'],
						'description_fa' 		   => $data['description_fa'],
						'small_image' 			   => $data['small_image'],
						'large_image' 			   => $data['large_image'],
						'layout_id' 			   => $data['layout_id'],
						'can_firstpage' 		   => (bool)$data['can_firstpage'],
					);
				}
			
				@$op_time = $current_time;
				@$op_limit = (int)$limit;
				@$op_offset = (int)$offset;
				@$op_total = (int)$total_results_array[0]['count'];
				@$op_more_results = has_more_results($op_offset, $op_limit, $op_total);
				@$op_results = ( !empty($items) ? $items : [] );
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
				@$op_url = '';
				
				
				$export = response_json($op_time, $op_offset, $op_limit, $op_total, $op_results, $op_right, $op_url, $op_more_results);
				// Creating temporary cache file
				temp_creator_on_server( basename(__FILE__, '_functions.php'), 'chartslist' . $limit . $offset, $export );
				
				return $export;
			
			} else {
				//$reason = $database_results_array['code']; // TODO: Change in production
				//echo status_code(400, $reason);
				$reason = $database_results_array['message'];
				echo status_code(400, $reason);
				exit;
			}
				
		} else { // Nothing returned from the server [@MINWANG: Changed the status code from 404 to 200, even if the result is empty 12.07.17 04:11 AM ]
			echo status_code(200, 'successfully processed');
			exit;
		}
	
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_time, $op_offset, $op_limit, $op_total, $op_results, $op_right, $op_url = '', $op_more_results){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'offset'		=> $op_offset,
				'limit'			=> $op_limit,
				'total'			=> $op_total,
				'more_results'	=> $op_more_results,
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}

?>