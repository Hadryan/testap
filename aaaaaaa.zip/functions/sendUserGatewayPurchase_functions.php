<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';

//
function send_zibal_gateway_purchase( $purchase_data, $mobile, $app_id, $user_token, $session_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/users/isvalidusertoken/' . $session_id_decrypted;
			$database_headers = array(
				"Content-Type: application/json",
			);
			
			try {
				@$database_results = getBackendlessResponse( $database_url, $database_headers, '' );
				
			} catch (Exception $ex){
				sendError( 'sendUserGatewayPurchase_zibal', 'error', (string)$ex->getCode(), $ex->getMessage(), 'object_id: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}
			
			if ( $database_results == 'true'  )
			{
				$original_purchase_data = $purchase_data;
				@$purchase_data = base64_decode($purchase_data);
				@$purchase_array = json_decode($purchase_data, true);
				
				@$payload_session_response = remove_non_utf8(md5_decrypt($purchase_array['s'], MD5_INTERNAL_RESOURCE)); // session_id changes to s because of 250 characters payload limitations
				@$payload_constructed_session_id = explode(':', $payload_session_response);
				@$payload_provided_user_id = $payload_constructed_session_id[0];
				@$payload_product_id = $purchase_array['p']; // product_id changes to p because of 250 characters payload limitations
				@$payload_current_time = $purchase_array['t']; // current_time changes to t because of 250 characters payload limitations
				
				if ( ($payload_provided_user_id != $user_objectId) || ( ($current_time - $payload_current_time) > (5 * 60) /*5 min difference tolerance*/ ) )
				{
					header("Content-type: application/json; charset=utf-8");
					echo status_code(403); // Faking the payload !
					exit;
					
				}
				
				
				$package_price = package_to_price($payload_product_id) * 10; // IRR
				$order_id = ZIBAL_PRODUCT_PREFIX . '-' . time() . '-' . mt_rand(10, 99);
				$gateway_parameters = array(
					"merchant"		=> ZIBAL_MERCHANT_KEY,
					"callbackUrl"	=> ZIBAL_CALLBACK_URL . '?app_id=' . $app_id . '&user_token=' . $user_token . '&session_id=' . $session_id . '&order_id=' . $order_id,
					"amount"		=> $package_price,
					"orderId"		=> $order_id,
					"mobile"		=> '0' . $mobile,
					"percentMode"	=> 0,
					"feeMode"		=> 0,
					"description"	=> $original_purchase_data,
					"multiplexingInfos"=> array(
						array("id"	=> "self" ,"amount"	=> $package_price),
					)
				);
			
			
				@$response = post_to_zibal('request', $gateway_parameters);
			
				if (@$response->result == 100)
				{
					$purchase_gateway_url = "https://gateway.zibal.ir/start/" . $response->trackId . "/direct";
					header("Content-type: text/html; charset=utf-8");
					header('location: ' . $purchase_gateway_url);
					return null;
				
				} else { // Zibal gateway wasn't successful!
					return null;
				}
				
			} else {
				$info_array = json_decode('{}');
				$response_array = array(
					'version'	=>	APIVERSION,
					'status'	=>	'ok',
					'code'		=>	ERROR_9000,
					'message'	=>	'Session Expired, please login again.',
					'data'		=>	base64_encode(json_encode($info_array)),
				);
				$info_link = DEEPLINK_HOMEPAGE . '/' . base64_encode(json_encode($response_array));
				$info_button = DEEPLINK_BTTN_ERROR_LOGIN;
				$info_message = DEEPLINK_MSG_ERROR;
				header("Content-type: text/html; charset=utf-8");
				return template_error_gateway_payment($info_link, $info_button, $info_message);
			}
			
		} else { // Invalid login
			header("Content-type: application/json; charset=utf-8");
			echo status_code(403);
			exit;
		}
		
	} else {
		header("Content-type: application/json; charset=utf-8");
		die(status_code(401));
		
	}
}

//
function send_sep_gateway_purchase( $purchase_data, $mobile, $app_id, $user_token, $session_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/users/isvalidusertoken/' . $session_id_decrypted;
			$database_headers = array(
				"Content-Type: application/json",
			);
			
			try {
				@$database_results = getBackendlessResponse( $database_url, $database_headers, '' );
				
			} catch (Exception $ex){
				sendError( 'sendUserGatewayPurchase_sep', 'error', (string)$ex->getCode(), $ex->getMessage(), 'object_id: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}
			
			if ( $database_results == 'true'  )
			{
				$original_purchase_data = $purchase_data;
				@$purchase_data = base64_decode($purchase_data);
				@$purchase_array = json_decode($purchase_data, true);
				
				@$payload_session_response = remove_non_utf8(md5_decrypt($purchase_array['s'], MD5_INTERNAL_RESOURCE)); // session_id changes to s because of 250 characters payload limitations
				@$payload_constructed_session_id = explode(':', $payload_session_response);
				@$payload_provided_user_id = $payload_constructed_session_id[0];
				@$payload_product_id = $purchase_array['p']; // product_id changes to p because of 250 characters payload limitations
				@$payload_current_time = $purchase_array['t']; // current_time changes to t because of 250 characters payload limitations
				
				if ( ($payload_provided_user_id != $user_objectId) || ( ($current_time - $payload_current_time) > (5 * 60) /*5 min difference tolerance*/ ) )
				{
					header("Content-type: application/json; charset=utf-8");
					echo status_code(403); // Faking the payload !
					exit;
					
				}
				
				
				$package_price = package_to_price($payload_product_id) * 10; // IRR
				$order_id = SEP_PRODUCT_PREFIX . '-' . time() . '-' . mt_rand(10, 99);
				$bank_url = 'https://sep.shaparak.ir/MobilePG/MobilePayment';
				$gateway_parameters = array(
					"Action"		=> "token",
					"Amount"		=> $package_price,
					"TerminalId"	=> SEP_MERCHANT_KEY,
					"ResNum"		=> $order_id,
					"RedirectURL"	=> SEP_CALLBACK_URL . '?app_id=' . $app_id . '&user_token=' . $user_token . '&session_id=' . $session_id . '&order_id=' . $order_id . '&package_id=' . $payload_product_id, // Later we will use $purchase_product_id
					"CellNumber"	=> checkSafeValue(prepareLength($mobile, 11, '0', 'left'), ''),
				);
				
				
				@$response = json_decode(post_to_sep($bank_url, http_build_query($gateway_parameters), array('Content-Type: application/x-www-form-urlencoded')));
				
				if (@$response->status == 1)
				{
					$purchase_gateway_url = BANK_REDIRECTOR_URL . '?app_id=' . $app_id . '&user_token=' . $user_token . '&session_id=' . $session_id . '&bank_token=' . encrypt($response->token, BANK_TOKEN_HASH);
					header("Content-type: text/html; charset=utf-8");
					header('location: ' . $purchase_gateway_url);
					return null;
				
				} else { // Sep gateway wasn't successful!
					return null;
				}
				
			} else {
				$info_array = json_decode('{}');
				$response_array = array(
					'version'	=>	APIVERSION,
					'status'	=>	'ok',
					'code'		=>	ERROR_9000,
					'message'	=>	'Session Expired, please login again.',
					'data'		=>	base64_encode(json_encode($info_array)),
				);
				$info_link = DEEPLINK_HOMEPAGE . '/' . base64_encode(json_encode($response_array));
				$info_button = DEEPLINK_BTTN_ERROR_LOGIN;
				$info_message = DEEPLINK_MSG_ERROR;
				header("Content-type: text/html; charset=utf-8");
				return template_error_gateway_payment($info_link, $info_button, $info_message);
			}
			
		} else { // Invalid login
			header("Content-type: application/json; charset=utf-8");
			echo status_code(403);
			exit;
		}
		
	} else {
		header("Content-type: application/json; charset=utf-8");
		die(status_code(401));
		
	}
}
?>