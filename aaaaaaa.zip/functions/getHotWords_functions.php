<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';

//
function get_hotwords($random) {
	
	$alphabet = array();
	for ($i = 'a'; $i !== 'zz'; $i++){
		$alphabet[] = $i;
	}
	// array_search('d', $alphabet); // returns 3
	
	@$edited_query = $alphabet[$random];
	
	@$query = 'http://i-serp.com/fetchAutocomplete.php?q=' . $edited_query;
	@$raw_data = stream_open($query, 'http://i-serp.com/', 'i-serp.com');
	@$data = json_decode($raw_data, true);
	
	if ( @$data["status"] == "error" || empty($data) ) 
	{
		$query = 'http://muism.com/v1/fetchAutocomplete.php?q=' . $edited_query;
		@$raw_data = stream_open($query, 'http://muism.com/', 'muism.com');
		@$data = json_decode($raw_data, true);
			
			if ( @$data["status"] == "error" || empty($data) ) 
			{
				$query = ORIGINALAPI . 'catalog/autocomplete?app_id=' . ORIGINALAPPID . '&query=' . $edited_query;
				@$raw_data = stream_open($query, 'http://www.qobuz.com/', 'www.qobuz.com');
				@$data = json_decode($raw_data, true);
			}
	}
	
	if ( !empty($data) && empty($data['status']) )
	{
		$response_array = isset($data[0]) ? $data : array($data);
		// https://codereview.stackexchange.com/a/29838
		$response_array = uniqueAssocArray( $response_array, 'label' );
		foreach($response_array as $search) {
			$items[] = array(
				"keyword"		=> $search['label'],
				// Random colors 
				// https://stackoverflow.com/a/11878014
				// "color_start"	=> '#' . substr(md5(rand()), 0, 6),
				// "color_end"		=> '#' . substr(md5(rand()), 0, 6),
			);
		}
		
	} else { // Nothing returned from the server
		echo status_code(404);
		exit;
	}


	@$op_time = time();
	@$op_results = $items;
	@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
	@$op_url = '';
	
	$export = response_json($op_time, $op_results, $op_right, $op_url);
	// Creating temporary cache file
	temp_creator_on_server( basename(__FILE__, '_functions.php'), 'hot' . $random, $export );
	
	return $export;

}

//
function response_json($op_time, $op_results, $op_right, $op_url = ''){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}

?>