<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';

//
function get_album( $id ) {
	
	$id_original = $id;
	$decrypted_id = remove_non_utf8(md5_decrypt($id, MD5_ID_MASTERKEY));
	$constructed_id = explode(':', $decrypted_id);
	$id = $constructed_id[1];
	
	// Check to see if the id has legitimate encrypted endpoint value
	$script_name = basename(__FILE__, '_functions.php');
	$endpoint_name = preg_replace('/(get|send|do|process|redirect|set|unset)/', '', $script_name);
	$process_request = false;
	foreach ( aquired_services() as $service ) {
		if ( ($process_request == 0) && (map_endpoint_to_service($service . $endpoint_name) == $constructed_id[0]) )
		{
			$process_request = true;
		}
	}
	if ( $process_request == 0 )
	{
		echo status_code(400, 'this is not a valid ' . strtolower($endpoint_name) . ' id.');
		exit;
	}
	
	$query = 'http://i-serp.com/fetchAlbum.php?id=' . $id;
	@$raw_data = stream_open($query, 'http://i-serp.com/', 'i-serp.com');
	@$data = json_decode($raw_data, true);
	
	if ( @$data["status"] == "error" || empty($data) ) 
	{
		$query = 'http://muism.com/v1/fetchAlbum.php?id=' . $id;
		@$raw_data = stream_open($query, 'http://muism.com/', 'muism.com');
		@$data = json_decode($raw_data, true);
			
			if ( @$data["status"] == "error" || empty($data) ) 
			{
				$query = ORIGINALAPI . 'album/get?album_id=' . $id . '&app_id=' . ORIGINALAPPID; // Old
				@$raw_data = stream_open($query, 'http://www.qobuz.com/', 'www.qobuz.com');
				@$data = json_decode($raw_data, true);
			}
	}
	
	if ( !empty($data["id"]) )
	{
		$graphql_url = base64_encode($query);
		$graphql_id = $id;
		// https://stackoverflow.com/a/9100340
		$graphql_command = 'curl -v -L -G -k -d "id=' . $graphql_id . '&url=' . $graphql_url . '" -X POST ' . APIENDPOINT_SSL . URLVERSION . '/' . 'insertAlbum.php';
		do_in_background($graphql_command);
		
		
		@$data_image = $data["image"]["large"];
		if ( empty($data_image) )
		{
			$data_image = APIENDPOINT . URLVERSION . '/' . 'dot.png'; // TODO: upload this image
		}
		@$data_image = image_corrector($data_image);
		@$data_id = $data["id"];
		@$data_title = $data["title"];
		@$data_subtitle = $data["subtitle"];
		//@$data_slug = $data["slug"]; // We don't want to use the original slug, provided !
		@$data_slug = make_slug(hdryn_change_france($data_title));
		@$data_description = $data["description"];
	
		@$data_composer = $data["composer"]["name"];
		@$data_comp_id = $data["composer"]["id"];
		@$data_comp_albums_count = $data["composer"]["albums_count"];
		//@$data_comp_slug = $data["composer"]["slug"];
		@$link_comp_slug = make_slug(hdryn_change_france($data_composer)); // Clean slug for composer
	
		@$data_artist = $data["artist"]["name"];
		@$data_artist_id = $data["artist"]["id"];
		@$data_artist_albums_count = $data["artist"]["albums_count"];
		//@$data_artist_slug = $data["artist"]["slug"];
		@$link_artist_slug = make_slug(hdryn_change_france($data_artist)); // Clean slug for artist
	
		@$data_label = $data["label"]["name"];
		@$data_label_id = $data["label"]["id"];
		@$data_label_albums_count = $data["label"]["albums_count"];
		//@$data_label_slug = $data["label"]["slug"];
		@$data_label_slug = make_slug($data_label); // Clean slug for label
		
		// Maybe use later
		@$data_period = $data["period"]["name"];
		@$data_period_id = $data["period"]["id"];
	
		@$data_instrument = $data["instrument"]["name"];
		@$data_instrument_id = $data["instrument"]["id"];
	
		@$data_area = $data["area"]["name"];
		@$data_area_id = $data["area"]["id"];
		//
	
		@$data_pdf = $data["goodies"][0]["description"];
		@$data_pdf_url = $data["goodies"][0]["original_url"];
		@$data_swf_url = $data["goodies"][0]["url"];
		if ( $data_pdf_url )
		{
			$path = $data_pdf_url;
			$pdf_id = basename($path);
			preg_match('/\/goodies(\/([^\/]*)?|$)\/(.*).pdf/', $path, $pdf_array);
			$pdf_url_id = $pdf_array[2] . ':' . $pdf_array[3];
			$pdf_id = construct_the_id(QOBUZSERVICE . 'Booklet', $pdf_url_id);
			$pdf_time = time() + (60 * 60 * 24 * 21); // 21 days
			$pdf_secret = generate_booklet_link($pdf_id, $pdf_time );
			$pdf_link = ASSETSSERVER_SSL . BOOKLETS_LOCATION . '/' . $pdf_id . '.pdf' . '?expires=' . $pdf_time . '&signature=' . $pdf_secret;
		}
		
		@$data_genre_id_1 = $data["genre"]["path"][0];
		@$data_genre_id_2 = $data["genre"]["path"][1];
		@$data_genre_id_3 = $data["genre"]["path"][2];
		@$data_genre_id_4 = $data["genre"]["path"][3];
	
		@$data_copyright = has_copyright_sign(remove_duplicate_copyright($data["copyright"]));
		@$data_recording_information = $data["recording_information"];
	
		@$data_program = $data["program"]; // We don't use this for now
		
		@$data_technical_specifications = $data["maximum_technical_specifications"];
	
		@$data_created = $data["created_at"];
		@$data_released = $data["released_at"];
		
		@$data_duration = $data["duration"];
		@$data_media = $data["media_count"];
		@$data_tracks = $data["tracks_count"];
	
		@$data_popularity = $data["popularity"];
		@$data_product_sales_weekly = $data["product_sales_factors_weekly"];
		@$data_product_sales_monthly = $data["product_sales_factors_monthly"];
		@$data_product_sales_yearly = $data["product_sales_factors_yearly"];
	
		@$data_product_type = $data["product_type"];
	
		@$data_recording_information = $data["recording_information"];
	
		@$data_sampling = $data["maximum_sampling_rate"];
		@$data_depth = $data["maximum_bit_depth"];
	
		@$data_purchasable_at = $data["purchasable_at"];
		@$data_streamable_at = $data["streamable_at"];
		@$data_purchasable = $data["purchasable"];
		@$data_streamable = $data["streamable"];
		@$data_previewable = $data["previewable"];
		@$data_sampleable = $data["sampleable"];
		@$data_downloadable = $data["downloadable"];
		@$data_displayable = $data["displayable"];
	
		@$data_hires = $data["hires"];
		
		@$data_parental_warning = $data['parental_warning'];
		
		@$data_upc = $data['upc'];
		
		@$data_awards = $data["awards"]; // Will use later
		
		@$data_tracks_offset = $data["tracks"]["offset"];
		@$data_tracks_limit = $data["tracks"]["limit"];
		@$data_tracks_total = $data["tracks"]["total"];
		@$data_items = $data["tracks"]["items"];
		
	
		if ( $data_genre_id_1 )
		{
			$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_1), "name"=>ic_genres($data_genre_id_1), "name_fa"=>ic_genres_fa($data_genre_id_1));
		}
		if ( $data_genre_id_2 )
		{
			$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_2), "name"=>ic_genres($data_genre_id_2), "name_fa"=>ic_genres_fa($data_genre_id_2));
		}
		if ( $data_genre_id_3 )
		{
			$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_3), "name"=>ic_genres($data_genre_id_3), "name_fa"=>ic_genres_fa($data_genre_id_3));
		}
		if ( $data_genre_id_4 )
		{
			$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_4), "name"=>ic_genres($data_genre_id_4), "name_fa"=>ic_genres_fa($data_genre_id_4));
		}
	
		$current_time = time();
		@$album_id = checkSafeValue( construct_the_id(QOBUZSERVICE . 'Album', $data_id), null );
		@$album_is_free = (is_free_album($data_id) == true ? true : false);
		@$album_title = hdryn_change_france($data_title);
		@$album_subtitle = hdryn_change_france($data_subtitle);
		@$album_description = extract_text_from_html($data_description); // 0822189022716
		@$album_genre = $genre_array;
		@$album_image = array(
				"50"   => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 50 . ':' . $data_id) . '.jpg',
				"230"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 230 . ':' . $data_id) . '.jpg',
				"600"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 600 . ':' . $data_id) . '.jpg',
			);
		@$album_composer = array(
				"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_comp_id), null ),
				"name"  => hdryn_change_france($data_composer),
				"slug"  => $link_comp_slug,
				"albums_count"  => $data_comp_albums_count 
			);
		@$album_artist = array(
				"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_artist_id), null ),
				"name"  => hdryn_change_france($data_artist),
				"slug"  => $link_artist_slug,
				"albums_count"  => $data_artist_albums_count 
			);
		@$album_label = array(
				"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Label', $data_label_id), null ),
				"name"  => $data_label,
				"slug"  => $data_label_slug,
				"albums_count"  => $data_label_albums_count 
			);
		@$album_booklet = $pdf_link;
		@$album_copyright = $data_copyright;
		@$album_program = $data_program;
		@$album_created_at = $data_created;
		@$album_released_at = $data_released;
		@$album_duration = $data_duration;
		@$album_media_count = $data_media;
		@$album_tracks_count = $data_tracks;
		@$album_parental_warning = $data_parental_warning;
		@$album_upc = $data_upc;
		// After sometime maybe live values
		@$album_product_sales = $data_popularity;
		@$album_popularity_weekly = 10 * $data_product_sales_weekly;
		@$album_popularity_monthly = 10 * $data_product_sales_monthly;
		@$album_popularity_yearly = 10 * $data_product_sales_yearly;
		//
		@$response_type = $data_product_type;
		@$album_sampling_rate = $data_sampling;
		@$album_bit_depth = $data_depth;
		@$album_technical_specifications = $data_technical_specifications;
		@$album_hires = $data_hires;
		@$album_url = SITEURL . 'album' . '/' . $album_id . '-' . $data_slug . ($link_artist_slug ? '-' . $link_artist_slug : '') . ($link_comp_slug ? '-' . $link_comp_slug : '') . '.html';

		
		$album_can_preview = false;
		if ( $data_sampleable == 1 )
		{
			$album_can_preview = true;
		}
		
		$album_can_buy = false;
		$album_can_buy_at = null;
		if ( !is_null($data_streamable_at) )
		{
			$album_can_buy_at = $data_streamable_at;
			
			if ( $album_can_buy_at < $current_time )
			{
				$album_can_buy = true;
			}
		}
	
		@$album_tracks_offset = $data_tracks_offset;
		@$album_tracks_limit = $data_tracks_limit;
		@$album_tracks_total = $data_tracks_total;
		
		if ( !is_null($album_artist) ) // [QUICK_FIX]: APP doesn't download if the artist is null ! 11/11/2017 5:55:04 AM
		{
			$track_artist_correction = array(
					"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_artist_id), null ),
					"name"  => hdryn_change_france($data_artist),
				);
			
		} elseif ( !is_null($album_composer) )
		{
			$track_artist_correction = array(
					"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_comp_id), null ),
					"name"  => hdryn_change_france($data_composer),
				);
			
		} else
		{
			$track_artist_correction = null;
		}
		
		
		// Foreach correction ! http://stackoverflow.com/a/15150384
		$awards_array = isset($data_awards[0]) ? $data_awards : array($data_awards);
		foreach($awards_array as $num => $award){
			$album_awards[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Award', $award['award_id']), "name"=>$award['name'], "name_fa"=>'', "awarded_at"=>$award['awarded_at']);
		}
	
		$tracks_array = isset($data_items[0]) ? $data_items : array($data_items);
		foreach($tracks_array as $num => $track){

			@$track_id = $track['id'];
			@$track_title = $track['title'];
			@$track_composer = isset($track['composer']['id']) ? array("id"=>construct_the_id(QOBUZSERVICE . 'Artist', $track['composer']['id']), "name"=>hdryn_change_france($track['composer']['name'])) : null;
			@$track_artist = isset($track['performer']['id']) ? array("id"=>construct_the_id(QOBUZSERVICE . 'Artist', $track['performer']['id']), "name"=>hdryn_change_france($track['performer']['name'])) : $track_artist_correction;
			@$track_duration = $track['duration'];
			@$track_performers = hdryn_change_france($track['performers']);
			@$track_media_number = $track['media_number'];
			@$track_copyright = has_copyright_sign(remove_duplicate_copyright($track['copyright']));
			@$track_track_number = $track['track_number'];
			@$track_version = $track['version'];
			@$track_parental_warning = $track['parental_warning'];
			@$track_isrc = $track['isrc'];
			@$track_work = $track['work'];
			@$track_purchasable = $track['purchasable'];
			@$track_streamable = $track['streamable'];
			@$track_previewable = $track['previewable'];
			@$track_sampleable = $track['sampleable'];
			@$track_downloadable = $track['downloadable'];
			@$track_displayable = $track['displayable'];
			@$track_purchasable_at = $track['purchasable_at'];
			@$track_streamable_at = $track['streamable_at'];
			
			@$track_md5_encrypt = construct_the_id(QOBUZSERVICE . 'Track', $track_id);
			@$track_md5_encrypt_full = construct_the_id(QOBUZSERVICE . 'FullLengthMP3', $track_id);

			$track_can_buy = false;
			$track_can_buy_at = null;
			if ( !is_null($track_streamable_at) )
			{
				$track_can_buy_at = $track_streamable_at;
				
				if ( $track_streamable_at <= $current_time )
				{
					$track_can_buy = true;
				}
			}

            $track_can_preview = false;
            $track_hls_preview = null;
            if ( $track_sampleable == 1 )
            {
                $track_can_preview = true;
                $track_hls_preview = STREAMSERVER . 'listening/,' . $track_md5_encrypt . 'b.m4a,' . $track_md5_encrypt . 'd.m4a,.urlset/master.m3u8';
            }

            $track_can_subscribe = false;
            $track_hls_subscribe = null;
            if ( !is_null($track_streamable_at) && ($track_purchasable_at <= $current_time) ) //@TODO: Make a better decision
            {
                $track_can_subscribe = true;
                $track_hls_subscribe = FULLSTREAMSERVER . 'cascade/,' . $track_md5_encrypt_full . 'b.m4a,' . $track_md5_encrypt_full . 'd.m4a,.urlset/master.m3u8';
            }
			
			@$track_maximum_sampling_rate = $track['maximum_sampling_rate'];
			@$track_maximum_bit_depth = $track['maximum_bit_depth'];
			@$track_hires = $track['hires'];
			
			$album_tracks[] = array(
				"id"		  				   => checkSafeValue( construct_the_id(QOBUZSERVICE . 'Track', $track_id), null ),
				"title"						   => $track_title,
				"composer"					   => $track_composer,
				"artist"					   => $track_artist,
				"duration"		   			   => $track_duration,
				"performers"	   			   => $track_performers,
				"media_number"		   		   => $track_media_number,
				"copyright"			   		   => $track_copyright,
				"track_number"	   			   => $track_track_number,
				"version"			   		   => $track_version,
				"work"			   		   	   => $track_work,
				"content_warning"			   => (!empty($track_parental_warning) ? $track_parental_warning : false),
				"isrc"						   => (!empty($track_isrc) ? $track_isrc : null),
				"can_preview"				   => $track_can_preview,
				"is_free"					   => $album_is_free, //@TODO: we just provide this by checking if <album> is free, however we need to check individual tracks later
				"preview_url"				   => $track_hls_preview,
				"preview_duration"			   => ($album_is_free == true ? (int)$track_duration : ( (int)$track_duration >= 30 ? 30 : (int)$track_duration ) ), //@TODO: if the album is free, set duration to the original duration, else 30
                "subscription_url"			   => $track_hls_subscribe,
				"subscription_duration"        => $track_duration,
                "start_at"                     => 0,
                "end_at"                       => (int)$track_duration,
                "is_segmentation"              => false,
                "force_segmentation"           => false,
				"can_buy"					   => $track_can_buy,
				"can_buy_at"				   => $track_can_buy_at,
				"maximum_sampling_rate"		   => $track_maximum_sampling_rate,
				"maximum_bit_depth"			   => $track_maximum_bit_depth,
				"hires"						   => $track_hires
			);
		}
	
		$album_tracks_array = array(
			"offset"		=> $album_tracks_offset,
			"limit"			=> $album_tracks_limit,
			"total"			=> $album_tracks_total,
			"items"			=> $album_tracks
		);
		
	} else {
		echo status_code(404);
		exit;
	}


	@$op_time = $current_time;
	@$op_results = $single_album;
	@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
	@$op_url = '';
	
	$export = response_json($op_time, $album_id, $album_title, $album_subtitle, $album_description, $album_image, $album_booklet, $album_composer, $album_artist, $album_genre, $album_label, $response_type, $album_copyright, $album_url, $album_media_count, $album_tracks_count, $album_duration, $album_awards, $album_program, $album_product_sales, $album_popularity_weekly, $album_popularity_monthly, $album_popularity_yearly, $album_created_at, $album_released_at, $album_is_free, $album_can_preview, $album_can_buy, $album_can_buy_at, $album_sampling_rate, $album_bit_depth, $album_technical_specifications, $album_hires, $album_parental_warning, $album_upc, $album_tracks_array, $op_right, $op_url);
	// Creating temporary cache file
	temp_creator_on_server( basename(__FILE__, '_functions.php'), $id_original, $export );
	
	return $export;

}

//
function response_json($op_time, $album_id, $album_title, $album_subtitle, $album_description, $album_image, $album_booklet, $album_composer, $album_artist, $album_genre, $album_label, $response_type, $album_copyright, $album_url, $album_media_count, $album_tracks_count, $album_duration, $album_awards, $album_program, $album_product_sales, $album_popularity_weekly, $album_popularity_monthly, $album_popularity_yearly, $album_created_at, $album_released_at, $album_is_free, $album_can_preview, $album_can_buy, $album_can_buy_at, $album_sampling_rate, $album_bit_depth, $album_technical_specifications, $album_hires, $album_parental_warning, $album_upc, $album_tracks_array, $op_right, $op_url = ''){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'results'		=> array(
					'id'						=> $album_id,
					'title'						=> $album_title,
					'subtitle'					=> $album_subtitle,
					//'description'				=> $album_description,
					'image'						=> $album_image,
					'booklet'					=> $album_booklet,
					'composer'					=> ( !empty($album_composer['name']) ? $album_composer : null ),
					'artist'					=> ( !empty($album_artist['name']) ? $album_artist : null ),
					'label'						=> ( !empty($album_label['name']) ? $album_label : null ),
					//'awards'					=> ( !empty($album_awards['name']) ? $album_awards : null ),
					'genre'						=> $album_genre,
					'type'						=> $response_type,
					'copyright'					=> $album_copyright,
					'url'						=> $album_url,
					'media_count'				=> $album_media_count,
					'tracks_count'				=> $album_tracks_count,
					'duration'					=> $album_duration,
					'program'					=> $album_program,
					'product_sales'				=> $album_product_sales,
					'popularity_weekly'			=> $album_popularity_weekly,
					'popularity_monthly'		=> $album_popularity_monthly,
					'popularity_yearly'			=> $album_popularity_yearly,
					'content_warning'			=> $album_parental_warning,
					'upc'						=> $album_upc,
					'created_at'				=> $album_created_at,
					'released_at'				=> $album_released_at,
					"is_free"					=> $album_is_free,
					'can_preview'				=> $album_can_preview,
					'can_buy'					=> $album_can_buy,
					'can_buy_at'				=> $album_can_buy_at,
					'sampling_rate'				=> $album_sampling_rate,
					'bit_depth'					=> $album_bit_depth,
					'technical_specifications'	=> $album_technical_specifications,
					'hires'						=> $album_hires,
					'tracks'					=> $album_tracks_array,
				),
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}

?>