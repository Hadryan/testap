<?php

//
// Performance checker https://stackoverflow.com/a/2482007
function filter_black_genres($genre_id){

	$black = array(
		'1'		=> 	1, // compilation
		'112'	=> 	1, // pop-rock
		'6'		=> 	1, // french-music 
		'64'	=> 	1, // electro 
		'127'	=> 	1, // soul-funk-rap 
		'133'	=> 	1, // rap-hip-hop 
		'2'		=> 	1, // blues-country-folk 
		'91'	=> 	1, // soundtracks 
		'10'	=> 	1, // classical-music 
		'80'	=> 	1, // jazz 
		'94'	=> 	1, // world-music 
		'142'	=> 	1, // ambience 
		'167'	=> 	1, // children 
		'59'	=> 	1, // spoken-words 

		'117'	=> 	1, // pop 
		'157'	=> 	1, // indie-pop 
		'119'	=> 	1, // rock 
		'113'	=> 	1, // alternative-and-indie 
		'115'	=> 	1, // hard-rock 
		'116'	=> 	1, // metal 
		'118'	=> 	1, // punk-new-wave 
		'120'	=> 	1, // progressive-rock 
		'121'	=> 	1, // rockabilly 
		'122'	=> 	1, // international-pop 
		'114'	=> 	1, // crooners 
		'8'		=> 	1, // retro-french-music 
		'7'		=> 	1, // french-artists 
		'9'		=> 	1, // french-rock 
		'65'	=> 	1, // ambiant 
		'129'	=> 	1, // dance 
		'66'	=> 	1, // downtempo 
		'67'	=> 	1, // drum-bass 
		'68'	=> 	1, // house 
		'69'	=> 	1, // lounge 
		'141'	=> 	1, // new-age 
		'70'	=> 	1, // techno 
		'71'	=> 	1, // trance 
		'72'	=> 	1, // trip-hop 
		'128'	=> 	1, // acid-jazz 
		'130'	=> 	1, // disco 
		'131'	=> 	1, // funk 
		'132'	=> 	1, // r-and-b 
		'134'	=> 	1, // soul 
		'3'		=> 	1, // blues 
		'4'		=> 	1, // country 
		'5'		=> 	1, // folk 
		'92'	=> 	1, // film-soundtracks 
		'93'	=> 	1, // musical-theatre 
		'148'	=> 	1, // video-games 
		'147'	=> 	1, // tv-series 

		'11'	=> 	1, // experimental-music 
		'15'	=> 	1, // lieder 
		'22'	=> 	1, // concertos 
		'27'	=> 	1, // chamber-music 
		'37'	=> 	1, // orchestral-music 
		'44'	=> 	1, // vocal-music 
		'176'	=> 	1, // secular-vocal-music 
		'50'	=> 	1, // sacred-vocal-music 
		'55'	=> 	1, // opera 
		'58'	=> 	1, // operettas 
		'12'	=> 	1, // concrete-music 
		'13'	=> 	1, // electronic-music 
		'14'	=> 	1, // minimal-music 
		'17'	=> 	1, // art-songs 
		'16'	=> 	1, // german-lieder 
		'18'	=> 	1, // melodies 
		'19'	=> 	1, // english-melodies 
		'20'	=> 	1, // northern-europe-melodies 
		'21'	=> 	1, // french-melodies 
		'24'	=> 	1, // keyboard-concertos 
		'138'	=> 	1, // concertos-for-wind-instruments 
		'137'	=> 	1, // concertos-for-trumpet 
		'25'	=> 	1, // concertos-for-violin 
		'26'	=> 	1, // concertos-for-violoncello 
		'33'	=> 	1, // duets 
		'30'	=> 	1, // solo-piano 
		'31'	=> 	1, // quartets 
		'32'	=> 	1, // quintets 
		'34'	=> 	1, // trios 
		'35'	=> 	1, // solo-violin 
		'36'	=> 	1, // solo-violoncello 
		'38'	=> 	1, // ballets 
		'39'	=> 	1, // theatre-music 
		'40'	=> 	1, // cinema-music 
		'41'	=> 	1, // overtures 
		'42'	=> 	1, // symphonic-poems 
		'43'	=> 	1, // symphonies 
		'46'	=> 	1, // choral-music 
		'47'	=> 	1, // vocal-ensemble 
		'49'	=> 	1, // vocal-recitals 
		'45'	=> 	1, // secular-cantatas 
		'48'	=> 	1, // secular-oratorios 
		'51'	=> 	1, // sacred-cantatas 
		'52'	=> 	1, // sacred-chorals 
		'53'	=> 	1, // masses-passions-requiems 
		'54'	=> 	1, // sacred-oratorios 
		'56'	=> 	1, // opera-extracts 
		'57'	=> 	1, // complete-operas 
		'81'	=> 	1, // bebop 
		'82'	=> 	1, // cool-jazz 
		'144'	=> 	1, // crossover-jazz 
		'145'	=> 	1, // dixieland 
		'83'	=> 	1, // free-jazz-and-avant-garde 
		'84'	=> 	1, // gospel 
		'85'	=> 	1, // contemporary-jazz 
		'86'	=> 	1, // jazz-fusion-and-jazz-rock 
		'87'	=> 	1, // gypsy-jazz 
		'88'	=> 	1, // traditional-jazz-and-new-orleans 
		'89'	=> 	1, // vocal-jazz 
		'90'	=> 	1, // latin-jazz 
		'146'	=> 	1, // ragtime 
		'95'	=> 	1, // africa 
		'96'	=> 	1, // afrobeat 
		'150'	=> 	1, // north-america 
		'149'	=> 	1, // latin-america 
		'97'	=> 	1, // asia 
		'98'	=> 	1, // bossa-nova-and-brazilian-music 
		'99'	=> 	1, // celtic-music 
		'151'	=> 	1, // european-music 
		'101'	=> 	1, // fado 
		'102'	=> 	1, // flamenco 
		'152'	=> 	1, // gypsy 
		'154'	=> 	1, // maghreb 
		'104'	=> 	1, // indian-music 
		'105'	=> 	1, // oriental-music 
		'106'	=> 	1, // rai 
		'123'	=> 	1, // reggae 
		'155'	=> 	1, // russian-music 
		'107'	=> 	1, // salsa 
		'108'	=> 	1, // tango 
		'156'	=> 	1, // turkish-music 
		'110'	=> 	1, // yiddish-and-klezmer 
		'111'	=> 	1, // zouk-and-antilles 
		'160'	=> 	1, // german-music 
		'161'	=> 	1, // scottish-music 
		'162'	=> 	1, // spanish-music 
		'100'	=> 	1, // eastern-european-music 
		'163'	=> 	1, // music-of-greece 
		'164'	=> 	1, // irish-music 
		'165'	=> 	1, // italian-music 
		'168'	=> 	1, // swiss-folk-music 
		'166'	=> 	1, // music-of-portugal 
		'173'	=> 	1, // schlager 
		'171'	=> 	1, // stimmungsmusik 
		'172'	=> 	1, // volksmusik 
		'174'	=> 	1, // irish-celtic 
		'175'	=> 	1, // irish-pop-music 
		'124'	=> 	1, // dancehall 
		'125'	=> 	1, // dub 
		'126'	=> 	1, // ska-rocksteady 
		'74'	=> 	1, // accordion-music 
		'158'	=> 	1, // bawdy-songs 
		'77'	=> 	1, // karaoke 
		'78'	=> 	1, // military-music 
		'159'	=> 	1, // christmas-music 
		'79'	=> 	1, // relaxation 
		'75'	=> 	1, // stories-and-nursery-rhymes 
		'76'	=> 	1, // educational-music 
		'178'	=> 	1, // german 
		'177'	=> 	1, // english 
		'170'	=> 	1, // french 
		'62'	=> 	1, // humor 
		'63'	=> 	1, // literature 
		'179'	=> 	1, // dutch 
		'61'	=> 	1, // historical-documents 
		'60'	=> 	1, // educational
		
	);

	if ( isset($black[$genre_id]) )
	{
		return true;
		
	} else
	{
		return false;
	}
}

?>