module.exports = {
  apps : [{
    name      : 'Express server',
    script    : 'app.js',
    env: {
      NODE_ENV: 'development'
    },
    env_production : {
      NODE_ENV: 'production'
    }
  },
  {
    name      : 'RabbitMQ Server',
    script    : './rabbit-mq/worker.js',
    env: {
      NODE_ENV: 'development'
    },
    env_production : {
      NODE_ENV: 'production'
    }
  }],

  deploy : {
    production : {
      user : 'node',
      host : '130.185.123.144',
      ref  : 'origin/master',
      repo : 'git@github.com:repo.git',
      path : '/home/rabbitQueue',
      'post-deploy' : 'npm install && pm2 reload ecosystem.config.js --env production'
    }
  }
};

