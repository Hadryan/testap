<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(600);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Credentials: TRUE");
header("X-Diginava-Algorithm: Algorithm-4");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");

include dirname(__FILE__) . '/' . basename(__FILE__, '.php') . '_functions.php';
use FastBill\ParallelProcessDispatcher\Process;
use FastBill\ParallelProcessDispatcher\Dispatcher;

	@$uri = $_GET['uri'];
	@$check = $_GET['security_check']; // This value is set within Nginx configuration
	
	if ( isset($check) && $check == NGINX_SECURITY_VALUE )
	{
		if ( $uri )
		{
			if( preg_match("/\/(?<document>([^\/]*)?).(?<extension>(?:pdf))/", $uri, $matchings) )
			{
				$booklet_id = $matchings['document'];
				$extension = $matchings['extension'];
			
				$decrypted_id = remove_non_utf8(md5_decrypt($booklet_id, MD5_EXTERNAL_RESOURCE));
				$constructed_id = explode(':', $decrypted_id); // processor_node_id:url_id:document_id
				$id = $constructed_id[2];
				$path = $constructed_id[1];
			
				// Check to see if the id has legitimate encrypted endpoint value
				$script_name = basename(__FILE__, '.php');
				$endpoint_name = preg_replace('/(get|send|do|process|redirect|set|unset)/', '', $script_name);
				$process_request = false;
				foreach ( aquired_services() as $service ) {
					if ( ($process_request == 0) && (map_endpoint_to_service($service . $endpoint_name) == $constructed_id[0]) )
					{
						$process_request = true;
					}
				}
				if ( $process_request == 0 )
				{
					echo status_code(400, 'this is not a valid ' . strtolower($endpoint_name) . ' id.');
					exit;
				}
			
				@$document_url = 'http://d250ptlkmugbjz.cloudfront.net/goodies/' . $path . '/' . $id . '.' . $extension;
	
				// Save document
				$time = time();
				$document_path_id = $path . ':' . $id; 
				$no_output_wait = ' > /dev/null 2> /dev/null';
				$no_output_wait_background = ' > /dev/null 2> /dev/null &';
				
				// Creating temporary directory
				$destination = $_SERVER['DOCUMENT_ROOT'] . '/' . MEDIAURI;
				if (!is_dir($destination)) {
					$make_directory = createPath($destination);
				}
			
				$dispatcher = new Dispatcher(1);    // will make sure only one of those will actually run at the same time
				
				// Downloading / Uploading document file
				// https://stackoverflow.com/a/52620939
				$original_file = MEDIAURI . '/' . $id . $time;
				file_put_contents($original_file, ''); // Dummy file creation to solve "permission denied" issue
				$processDownload = new Process('wget -q -O ' . $destination . '/' . $id . $time . ' ' . $document_url . $no_output_wait);
				$dispatcher->addProcess($processDownload, true);
				$processUpload__d = new Process('aws s3 cp ' . $original_file . ' s3://' . BUCKET_ASSETS . '/booklets/' . construct_the_id(QOBUZSERVICE . 'Booklet', $document_path_id) . '.' . $extension . '  --acl public-read --cache-control public,max-age=604800 --content-type application/' . $extension . ' --storage-class INTELLIGENT_TIERING' . $no_output_wait);				
				$dispatcher->addProcess($processUpload__d, true);
				$processUpload_tag = new Process('aws s3api put-object-tagging --bucket ' . BUCKET_ASSETS . ' --key "' . 'booklets/' . construct_the_id(QOBUZSERVICE . 'Booklet', $document_path_id) . '.' . $extension . '"' . ' --tagging TagSet="[{Key=type,Value=' . $extension . '}]"' . $no_output_wait_background);
				$dispatcher->addProcess($processUpload_tag, true);
			
				$dispatcher->tick();
				$dispatcher->dispatch();  // this will run until all processes are finished.
				$processes = $dispatcher->getFinishedProcesses();
			
				// Download document
				if(file_exists($original_file)) {
					header('Content-Type: application/' . $extension);
					header('Content-Disposition: inline; filename='.basename(construct_the_id(QOBUZSERVICE . 'Booklet', $document_path_id) . '.' . $extension));
					header('Content-Transfer-Encoding: binary');
					header('Accept-Ranges: bytes');
					header('Expires: '.gmdate('D, d M Y H:i:s \G\M\T', time())); // 0 seconds
					header('Cache-Control: public');
					header('Pragma: public');
					header('Content-Length: ' . filesize($original_file));
					ob_clean();
					flush();
					readfile($original_file);
				}
			
			} else {
				echo status_code(400);
				exit;
			}
		
		} else {
			echo status_code(417);
			exit;
		}
		
	} else {
		echo status_code(403);
		exit;
	}

?>
