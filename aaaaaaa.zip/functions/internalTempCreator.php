<?php
@set_time_limit(144);

define("ALBUM",  	"album");
define("ARTIST", 	"artist");
define("TRACK",  	"track");
define("LABEL",  	"label");
define("GENRE", 	"genre");
define("FEATURED", 	"featured");
define("SIMILAR", 	"similar");
define("SEARCH", 	"search");



//
function temp_creator_on_server( $script_name, $naming_id, $content ) {
	
	// http://stackoverflow.com/q/6955913
	if ( isset($content[340]) ) // We cache only there is response, not in case of errors (340 is approximate characters length of errors)
	{
		if ( $script_name == 'getAlbum' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . ALBUM . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getTrack' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . TRACK . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getLabel' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . LABEL . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getGenre' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . GENRE . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getFeatured' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . FEATURED . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getArtist' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . ARTIST . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getSimilarAlbums' || $script_name == 'getSimilarArtists' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . SIMILAR . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getArtistInfo' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . ARTIST . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getHotWords' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . SEARCH . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getChartsList' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . SEARCH . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getMoodsList' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . SEARCH . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getPackagesList' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . SEARCH . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getBillboard' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . FEATURED . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getCatalog' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . FEATURED . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getLatestVersion' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . FEATURED . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getSystemAds' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . FEATURED . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		} elseif ( $script_name == 'getCharts' )
		{
			$gzdirectory =  realpath(__DIR__ . '/..') . '/' . FEATURED . '/';
			$gzname = $naming_id . '.json.gz';
			$gzfile = $gzdirectory . $gzname;
			
			$fp = gzopen ($gzfile, 'w9');
			gzwrite ($fp, $content);
			gzclose($fp);
			
		}
	}
	
}

?>