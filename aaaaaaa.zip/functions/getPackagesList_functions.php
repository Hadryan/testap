<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';
// Asynchronous request
require dirname(__FILE__) . '/library/vendor/autoload.php';
use mpyw\Co\Co;
use mpyw\Co\CURLException;

//
function curl_async_put($url, array $options = [], $user_token = ''){
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	}

	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "PUT",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_post($url, array $headers = [], array $data = [], array $options = []){
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => json_encode($data),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_get($url, array $options = [], $user_token = ''){
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	};
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function get_packages_list( $limit, $offset, $app_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Platform_Packages';
		$database_headers = array(
			"Content-Type: application/json",
		);
		$database_where = '?where=is_active' . urlencode("='" . true . "'") . '&pageSize=' . $limit . '&offset=' . $offset . '&sortBy=created%20desc';
		
		$get_counters = Co::wait([
			
			"0" => function () use ( $database_url, $database_headers, $database_where ) {
				$content = (yield curl_async_get( $database_url . $database_where, $database_headers ));
				//yield Co::RETURN_WITH =>$content; // PHP 5.6
				return $content; // PHP 7+
			},
			
			"1" => function () use ( $database_headers ) {
				$content = (yield curl_async_get('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Platform_Packages?props=Count(objectId)'));
				//yield Co::RETURN_WITH =>$content; // PHP 5.6
				return $content; // PHP 7+
			},
			
		]);
		
		@$database_results_array = json_decode($get_counters[0], true);
		@$total_results_array = json_decode($get_counters[1], true);
		
		// ("package_id", "package_validity", "package_quota", "single_track_price", "package_price", "package_before_discount", "color_start", "color_end", "gradient_degree", "image_url", "package_title_en", "package_title_fa", "package_description_en", "package_description_fa", "background_image_opacity", "package_type")
		$items = array();
		
		// https://stackoverflow.com/a/43079905
		array_multisort(array_column($database_results_array, 'package_sort'), SORT_ASC, $database_results_array);
		
		foreach ($database_results_array as $result_array) {
			$items[] = array(
				$result_array["package_id"],
				( !empty($result_array["package_validity"]) ? $result_array["package_validity"] : "" ),
				$result_array["package_quota"],
				$result_array["package_single_track_price"],
				$result_array["package_price"],
				$result_array["package_before_discount"],
				$result_array["package_gradient_start"],
				$result_array["package_gradient_end"],
				$result_array["package_gradient_degree"],
				$result_array["package_image_url"],
				$result_array["package_title_en"],
				$result_array["package_title_fa"],
				$result_array["package_description_en"],
				$result_array["package_description_fa"],
				$result_array["package_background_image_opacity"],
				$result_array["package_type"]
			);
		}
		
		
		@$op_time = $current_time;
		@$op_limit = (int)$limit;
		@$op_offset = (int)$offset;
		@$op_total = (int)$total_results_array[0]['count'];
		@$op_more_results = has_more_results($op_offset, $op_limit, $op_total);
		@$op_results = ( !empty($items) ? array_values($items) : [] );
		@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
		@$op_url = '';
		
		$export = response_json($op_time, $op_offset, $op_limit, $op_total, $op_results, $op_right, $op_url, $op_more_results);
		// Creating temporary cache file
		temp_creator_on_server( basename(__FILE__, '_functions.php'), 'packageslist', $export );
		
		
		return $export;
	
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_time, $op_offset, $op_limit, $op_total, $op_results, $op_right, $op_url = '', $op_more_results){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'offset'		=> $op_offset,
				'limit'			=> $op_limit,
				'total'			=> $op_total,
				'more_results'	=> $op_more_results,	
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}

?>