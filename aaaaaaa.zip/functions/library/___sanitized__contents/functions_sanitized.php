<?php

include dirname(__FILE__) . '/white_albums.php';
include dirname(__FILE__) . '/black_albums.php';
include dirname(__FILE__) . '/black_artists.php';
include dirname(__FILE__) . '/black_genres.php';
//include dirname(__FILE__) . '/black_labels.php';
//include dirname(__FILE__) . '/black_keywords.php';


// Free albums // @TODO: Dynamic mechanism
include dirname(__FILE__) . '/free_albums.php';

?>