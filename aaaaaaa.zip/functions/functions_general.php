<?php

require dirname(__FILE__) . '/library/vendor/autoload.php';
include dirname(__FILE__) . '/library/OAuth.class.php';
include dirname(__FILE__) . '/library/Slug.class.php';
include dirname(__FILE__) . '/library/geoHex/Hex.php';
include dirname(__FILE__) . '/library/graphQL_functions.php';
include dirname(__FILE__) . '/internalTempCreator.php';
include dirname(__FILE__) . '/filter_functions.php';
include dirname(__FILE__) . '/library/___sanitized__contents/functions_sanitized.php';
include dirname(__FILE__) . '/library/error_codes.php';
include dirname(__FILE__) . '/library/html_templates.php';

use Mexitek\PHPColors\Colors;

use Ausi\SlugGenerator\SlugGenerator;
use Ausi\SlugGenerator\SlugOptions;


date_default_timezone_set('UTC');

define("APIVERSION", 					"2.0");
define("URLVERSION", 					"v2");
define("APINAME", 						"diginava.com");
define("APP_PRETTY_NAME",				"Diginava");
define("APP_FARSI_NAME",				"دیجی‌نوا");
define("DIGINAVASERVICE",               "Diginava");
define("APIENDPOINT", 					"http://api.diginava.com/");
define("APIENDPOINT_SSL",				"https://api.diginava.com/");
define("SITEURL", 						"https://www.diginava.com/");
define("SAMPLESERVER", 					"http://sample.diginava.com/");
define("ASSETSSERVER", 					"https://assets.diginava.com/");
define("ASSETSSERVER_SSL", 				"https://assets.diginava.com/");
define("AUDIOSERVER_SSL", 				"https://audio.diginava.com/");
define("STREAMSERVER", 					"http://stream.diginava.com/");
//define("FULLSTREAMSERVER", 				"http://streaming.diginava.site/");
define("FULLSTREAMSERVER", 				"http://streaming.musicmundi.com/");
define("ADMEDIASERVER",					"http://media.diginava.com/");
define("DUMMYIMAGE", 					"http://media.diginava.com/placeholder.png");

define("GRAPHQL_ENDPOINT",				"http://194.5.193.192:8080/v1/graphql");
define("GRAPHQL_ADMINPASS",				"Aa12345679/*!");
define("MUSIC_GRAPHQL_ENDPOINT",		"http://130.185.123.144:6142/v1/graphql");
define("MUSIC_GRAPHQL_ADMINPASS",		"75DBA87160B2F4B5033e8e09B068F461");
define("USERS_GRAPHQL_ENDPOINT",		"http://130.185.123.144:6132/v1/graphql");
define("USERS_GRAPHQL_ADMINPASS",		"1967A69C6908aCda0D8039DE3D0797E4");

define("USERS_LOGS_PASSWORD",		    "17FD1D8d92aECE91E8CF83fcFF719F34");
define("USERS_LOGS_SECRET",		        "_MCVzr5c5Q/H:+M{E8:FH.EKcEgX!CT3y7E@~F-&P[micQ8^EHHEkTdQiLX,FS");

define("MEDIAALGORITHM",				"mix_1"); // assets, media, mix_1, mix_2, mix_3, OTHERs
define("EXTERNAL_MEDIAALGORITHM",		"media"); // assets, media, OTHERs
define("ORIGINALAPI", 					"http://www.qobuz.com/api.json/0.2/");
define("ORIGINALAPPID", 				"172934108");

define("APKVERSION", 					"1.0.10.981207");
define("APKCODE",						10); // Increment by 1
define("APKBUILTDATE", 					"01.03.20 07:40 AM");
define("APKANDROID", 					"Android");
define("APKHASH",						"9b8c6abd9ffe3e985d76c777d7e76a01"); // Use : https://md5file.com/calculator
//define("APKANDROIDURL",					"https://www.diginava.com/download/android/"); // @TODO: upload this file && upload fake package with .zip extension
define("APKANDROIDURL",					"https://github.com/Hadryan/testap/raw/master/"); // @TODO: omit this for production
define("APKMAYUPDATE",					may_update_versions()); // These versions may be updated

define("QOBUZSERVICE",					"Qobuz");
define("QOBUZUSER",						"_filmsdotly@gmail.com");
define("QOBUZEMAIL",					"_filmsdotly@gmail.com");
define("QOBUZPASSWORD",					"Qobuz2019");
define("QOBUZAPPID",					"579169010");
define("QOBUZAPPSECRET",				"e28e9f3d71d274a605693111477d4fe2");
define("QOBUZUSERTOKEN",				"U8aJu8f7o6wH787lQBMnf3HKtyLnDnoGzuWMoUZ2seRTueuVXaXu8AZXtvcx_qLK2hapMimPRFBZXFrM4Keeqg");
define("QOBUZDEVICEID",					"ab5d1973-d82d-487d-9c01-408c4342132e"); // Auto generated, fake ID! but we will use this afterwards !

define("ZIBAL_MERCHANT_KEY",			"5ca906d518f9344c8c4d26ac");
define("ZIBAL_CALLBACK_URL",			APIENDPOINT_SSL . URLVERSION . "/doUserGatewayPurchase.php");
define("ZIBAL_PRODUCT_PREFIX",			"DNPZ");
define("SEP_MERCHANT_KEY",				"11588643");
define("SEP_CALLBACK_URL",				APIENDPOINT_SSL . URLVERSION . "/doUserGatewayPurchase.php");
define("SEP_PRODUCT_PREFIX",			"DNPS");

define("MYKET_PUBLIC_KEY_BASE64",		"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCQyc4C857IYV473oWqGU9qqZoXUd84ihjSh/Xj1ZP1gZYqWtFJwDQ0vKN3zbIVQWbmbBhxY9+Sw4MvE8GYzVeWAQjZF+iAApbnk12Pk99ueeBWUzUy+SVEpi/WxR8N4EdYT17TH2c3Ix776+fQUCiXuYIeMxAtW3sPQzeuNJrwQwIDAQAB");

define("APPID_MOBILE_V1",				"5c8aa9fc6113a9a7");
define("APP_ENV_MOBILE_V1",				"Android_myket_v1");
define("APPSECRET_MOBILE_V1",			"fc486715f6e289be30ff6d929e91548130922ccda629ee3635b2faa11ebb7fff");

define("MD5_ID_MASTERKEY",				"zZf:a@5AqSd*T~_5^0|OrcQ?fF0=>ge&");
define("MD5_INTERNAL_RESOURCE",			"q\$e[%A*!8F%mX*8Uaw!)}Bj#_uH{*HJin=3+)-8!dhRE]5mb-8,aY*Wf.imgi8@9");
define('MD5_EXTERNAL_RESOURCE',			'BV!;nnYL_xM]hNAf=ie8[;%ASw/d=' . base64_decode('JA==') . '7.qja.fK;:#e&RjFFZ?pd}AhXV7m,XV:[;');
define('MD5_MEDIA_RESOURCE',			'c9]qBDu:DaP-f9XHZd--+_;B%e!TJ[xD2!b' . base64_decode('JA==') . 'h8!+WX9tg:!6n&j%JeMc%8Q9L*F;');
define('MD5_PAYMENT_BARCODE',			'FG*xwr:!pp%3.C%CU#*5]8L?d+T:rkHe');
define('MD5_INTERNAL_IDS',              'ZV{vcSx&W{&n4C}nTN@T$6*%*L&Y_;m+');

define("FULLAUDIO_ACCESS_NODE",			"nE4NHQJUb/JYipJMLi2YG0D#*%mspVSHKF;5z0S6fDjV1Y3CjN3CJmnFUWwOr5");

define("AUDIO_STREAMING_SECRET",		"67ecce737f8290dc40e3c7f24bb158350373daa8a160a4ae052a2b6f7da287a3");
define("AUDIO_STREAMING_EXPIRATION",	28800); // 8 hours

define("AMAZON_S3_SERVICE",				"s3.eu-west-3.amazonaws.com");
define("BUCKET_FULLAUDIO",				"fullaudio7ueelgm5tuoo4zfg4i7nvhbz11t52ne9nxx9gzzou7o4v463ko0");

define("DAY_TO_LIVE_AUDIO_DOWNLOAD",	14);

define("POSTGRES_ALBUM_ONCONFLICT",		true);
define("POSTGRES_ARTIST_ONCONFLICT",	true);

define("SMS_VERIFICATION",				"cee4cc986b0f827f28e04cc6588e3079cd9a2e4299becdfe0a0c784e521b6028");
define("MOKHABERAT_SMS_USER",			"hadi.ayanbod");
define("MOKHABERAT_SMS_PASS",			"Aa@12345679!");
define("MOKHABERAT_SMS_URL",			"https://ippanel.com/api/select");
define("RAYGAN_SMS_USER",				"hadiayanbod");
define("RAYGAN_SMS_PASS",				"Aa12345679");
define("RAYGAN_SMS_URL",				"https://raygansms.com/SendMessageWithCode.ashx");

define("GENERAL_ENCRYPTION_KEY",		"%uMmnaFZ6]GEN{tv5kFd.:ArKMBKzc[S");

// https://gist.github.com/Hadryan/926ae35c229667edd150158cc60b300a
define('AES_METHOD',                    'aes-256-cbc');
define('LOG_AUTH_KEY',                  '17FD1D8d92aECE91E8CF83fcFF719F34');

define("USERAGENT",						user_aget());
define("MEDIASERVER", 					random_image_host());

define("RAPIDUSER", 					"diginava");
define("RAPIDPASS", 					"Aa@12345679");

define("BOOKLETS_LOCATION",				"booklets");
define("BOOKLETS_SECRET",				"v20alntrs9inex07wy0gukzzedoxs5p8n769iet1m89p58mnxwj75w2wcwcwraj1");

define("DOWNLOAD_LOCATION",				"download");
define("DOWNLOAD_SECRET",				"nkhu2rR24fftwzYZmjjT4faie5HWSKFW8G3zGN59eKBh6gYi34F3uD4h8pkBztJA");

define("MD5KEY",						"7ac9efd566a78d4d7445ceadb8e06bf4");
define("BANK_TOKEN_HASH",				"73oWqGU9qqZoXUd84ihjSh/Xj1ZP1gZYqWtF");
define("BANK_REDIRECTOR_URL", 			APIENDPOINT_SSL . URLVERSION . "/redirectUsertoBank.php");

define("ADS_SYSTEM_SEARCH_RADIUS",		"7.5");

define("IPINFOTOKEN",					"84d1f9f65b9a10");

define("POINTS_PREVIEW_TRACKS",			1 );
define("POINTS_BUY_TRACKS", 			5 );
define("POINTS_REPLAY_TRACKS", 			2 );
define("POINTS_ENQUEUE_TRACKS", 		1 );
define("POINTS_BUY_ALBUMS", 			15 );
define("POINTS_INTRACT_APP", 			2 );
define("POINTS_SET_FAVORITES", 			1 );
define("POINTS_UNSET_FAVORITES", 		-3 );

define("CHARACTERSET_16",				'5864231970adbcfe');
define("CHARACTERSET_36",				'5864231970zxcvbnmqwerpoiuytalskdjfhg');
define("CHARACTERSET_62",				'5864231970PZXOCIVUBYNTMREWQLAKSJDHFGzxcvbnmqwerpoiuytalskdjfhg');


//
function media_server($server, $size, $encrypted_album_id) {
	$assets = 'https://media.diginava.com/';
	$media = 'http://media.diginava.com/';
	$cloudfront = 'https://d250ptlkmugbjz.cloudfront.net/';
	
	if ( $server == 'assets' )
	{
		$album_id = $encrypted_album_id;
		$server_location = $assets;
		
		return $server_location . 'getCover.php?size=' . $size . '&id=' . $album_id . '.jpg';
		
	} elseif ( $server == 'media' )
	{
		$album_id = $encrypted_album_id;
		$server_location = $media;
		
		return $server_location . 'getCover.php?size=' . $size . '&id=' . $album_id . '.jpg';
	
	} elseif ( $server == 'mix_1' )
	{
		$album_id = $encrypted_album_id;
		if ( is_numeric(id_decrypt($album_id)) && (id_decrypt($album_id) < 5000050000000) ) // if between 0000100000000 < 5000050000000
		{
			$server_location = $assets;
		} else 
		{
			$server_location = $media;
		}
		
		return $server_location . 'getCover.php?size=' . $size . '&id=' . $album_id . '.jpg';
	
	} elseif ( $server == 'mix_2' )
	{
		$album_id = prepareLength(id_decrypt($encrypted_album_id), 13, '0', 'left');
		if ( is_numeric($album_id) && ($album_id < 5000050000000) )
		{
			$server_location = $assets;
			return $server_location . 'getCover.php?size=' . $size . '&id=' . $encrypted_album_id . '.jpg';
			
		} else
		{
			@$path_1 = substr($album_id, 11, 2);
			@$path_2 = substr($album_id, 9, 2);
			return $cloudfront . 'images/covers/' . $path_1 . '/' . $path_2 . '/' . $album_id . '_' . $size . '.jpg';
			
		}
	
	} elseif ( $server == 'mix_3' )
	{
		$album_id = prepareLength(id_decrypt($encrypted_album_id), 13, '0', 'left');
		if ( is_numeric(id_decrypt($album_id)) && ($album_id < 3333333333333) )
		{
			$server_location = $assets;
			return $server_location . 'getCover.php?size=' . $size . '&id=' . $encrypted_album_id . '.jpg';
			
		} elseif ( is_numeric(id_decrypt($album_id)) && ($album_id < 6666666666666) ) 
		{
			$server_location = $media;
			return $server_location . 'getCover.php?size=' . $size . '&id=' . $encrypted_album_id . '.jpg';
			
		} else // https://d250ptlkmugbjz.cloudfront.net/images/covers/91/81/0002894798191_230.jpg
		{
			@$path_1 = substr($album_id, 11, 2);
			@$path_2 = substr($album_id, 9, 2);
			return $cloudfront . 'images/covers/' . $path_1 . '/' . $path_2 . '/' . $album_id . '_' . $size . '.jpg';
			
		}
	
	} else // cloudfront
	{
		$album_id = prepareLength(id_decrypt($encrypted_album_id), 13, '0', 'left');
		@$path_1 = substr($album_id, 11, 2);
		@$path_2 = substr($album_id, 9, 2);
		return $cloudfront . 'images/covers/' . $path_1 . '/' . $path_2 . '/' . $album_id . '_' . $size . '.jpg';
	
	}
}

//
function external_media_server($server, $md5_encrypted_url_path) {
	$assets = 'http://media.diginava.com';
	$media = 'http://media.diginava.com';
	$cloudfront = 'https://d250ptlkmugbjz.cloudfront.net';
	
	if ( $server == 'assets' )
	{	
		return $assets . '/' . 'getXCover.php?id=' . $md5_encrypted_url_path . '.jpg';
		
	} elseif ( $server == 'media' )
	{		
		return $media . '/' . 'getXCover.php?id=' . $md5_encrypted_url_path . '.jpg';
	
	} else // cloudfront
	{
		$url_path =  remove_non_utf8(md5_decrypt($md5_encrypted_url_path, MD5_EXTERNAL_RESOURCE));
		return $cloudfront . $url_path;
	
	}
}

//
function aquired_services() {
	
	return array(
		QOBUZSERVICE,
		// Add new external services here	
	);
	
}

//
function available_services($service_id) {
	
	$services_array = array(
		'1'			  =>		QOBUZSERVICE,
		'2'			  =>		QOBUZSERVICE,
		'3'			  =>		QOBUZSERVICE,
		'4'			  =>		QOBUZSERVICE,
		'5'			  =>		QOBUZSERVICE,
		'6'			  =>		QOBUZSERVICE,
		'7'			  =>		QOBUZSERVICE,
		'8'			  =>		QOBUZSERVICE,
		'9'			  =>		QOBUZSERVICE,
		'10'		  =>		QOBUZSERVICE,
		'11'		  =>		QOBUZSERVICE,
		'12'		  =>		QOBUZSERVICE,
		'13'		  =>		DIGINAVASERVICE,

		
		// ''			  =>		some_other_service,
	);
	
	return strtr($service_id, $services_array);
}

//
function map_service_to_endpoint($service_id) {
	
	$services_array = array(
		'1'			  =>		QOBUZSERVICE . 'Album',
		'2'			  =>		QOBUZSERVICE . 'Artist',
		'3'			  =>		QOBUZSERVICE . 'Label',
		'4'			  =>		QOBUZSERVICE . 'Genre',
		'5'			  =>		QOBUZSERVICE . 'Track',
		'6'			  =>		QOBUZSERVICE . 'Award',
		'7'			  =>		QOBUZSERVICE . 'ArtistsImage',
		'8'			  =>		QOBUZSERVICE . 'Cover',
		'9'			  =>		QOBUZSERVICE . 'Booklet',
		'10'		  =>		QOBUZSERVICE . 'BillboardImage',
		'11'		  =>		QOBUZSERVICE . 'FullLengthMP3',
		'12'		  =>		QOBUZSERVICE . 'PaymentBarcode',
		'13'		  =>		DIGINAVASERVICE . 'InternalId',

		
		// ''			  =>		some_other_service . 'Album',
	);
	
	return strtr($service_id, $services_array);
}

//
function map_endpoint_to_service($endpoint) {
	
	$endpoints_array = array(
		QOBUZSERVICE . 'Album'				=>		'1',
		QOBUZSERVICE . 'Artist'				=>		'2',
		QOBUZSERVICE . 'Label'				=>		'3',
		QOBUZSERVICE . 'Genre'				=>		'4',
		QOBUZSERVICE . 'Track'				=>		'5',
		QOBUZSERVICE . 'Award'				=>		'6',
		QOBUZSERVICE . 'ArtistsImage'		=>		'7',
		QOBUZSERVICE . 'Cover'				=>		'8',
		QOBUZSERVICE . 'Booklet'			=>		'9',
		QOBUZSERVICE . 'BillboardImage'		=>		'10',
		QOBUZSERVICE . 'FullLengthMP3'		=>		'11',
		QOBUZSERVICE . 'PaymentBarcode'		=>		'12',
        DIGINAVASERVICE . 'InternalId'		=>		'13',

		
		// some_other_service . 'Album'			  =>		'',
	);
	
	return strtr($endpoint, $endpoints_array);
}

//
function construct_the_id($service_id, $extrenal_id) {
	
	$pattern_one_array = array(
		QOBUZSERVICE . 'Album',
		QOBUZSERVICE . 'Artist',
		QOBUZSERVICE . 'Label',
		QOBUZSERVICE . 'Genre',
		QOBUZSERVICE . 'Track',
		QOBUZSERVICE . 'Award',
	);
	
	$pattern_two_array = array(
		QOBUZSERVICE . 'ArtistsImage',
		QOBUZSERVICE . 'Cover',
		QOBUZSERVICE . 'Booklet',
		QOBUZSERVICE . 'BillboardImage',
	);
	
	$pattern_three_array = array(
		QOBUZSERVICE . 'FullLengthMP3',
	);

	$pattern_four_array = array(
		QOBUZSERVICE . 'PaymentBarcode',
	);

	$pattern_five_array = array(
        DIGINAVASERVICE . 'InternalId',
	);

	if ( in_array($service_id, $pattern_one_array) )
	{
		$id = md5_encrypt(map_endpoint_to_service($service_id) . ':' . $extrenal_id, MD5_ID_MASTERKEY);
		
	} elseif ( in_array($service_id, $pattern_two_array) )
	{
		$id = md5_encrypt(map_endpoint_to_service($service_id) . ':' . $extrenal_id, MD5_EXTERNAL_RESOURCE);
		
	} elseif ( in_array($service_id, $pattern_three_array) )
	{
		$id = md5_encrypt(map_endpoint_to_service($service_id) . ':' . $extrenal_id, MD5_MEDIA_RESOURCE);
		
	} elseif ( in_array($service_id, $pattern_four_array) )
	{
		$id = md5_encrypt(map_endpoint_to_service($service_id) . ':' . $extrenal_id, MD5_PAYMENT_BARCODE);

    } elseif ( in_array($service_id, $pattern_five_array) )
    {
        $id = md5_encrypt(map_endpoint_to_service($service_id) . ':' . $extrenal_id, MD5_INTERNAL_IDS);

    } elseif ( $service_id == QOBUZSERVICE . 'service_three_???' )
	{
		$id = md5_encrypt(map_endpoint_to_service($service_id) . ':' . $extrenal_id, MD5_ID_MASTERKEY);
		
	}
		
	return $id;
}

//
function custom_button_types($place) {

    $place_array = array(
        'Login'								=>			'1',
        'Verify'							=>			'2',
        'Email'		    					=>			'3',
        'FirstName'		    				=>			'4',
        'LastName'		    				=>			'5',
        'Mobile'							=>			'6',
        'Gender'							=>			'7',
        'Avatar'							=>			'8',
        'First'		    					=>			'9',
        'LowQuota'							=>			'10',
        'TimeBasedExpiring'					=>			'11',
        'NormalExpiring'					=>			'12',
        'SubscriptionExpiringIn2Days'		=>			'13',
        'SubscriptionExpired'				=>			'14',
        'NotDownloadedYet'					=>			'15',
        'DontHaveFavorites'					=>			'16',
        'PurchasesReached100'				=>			'17',
        'UserBirthday'				        =>			'18',

    );

    return strtr($place, $place_array);
}

//
function custom_button_action_types($action) {

    $action_array = array(
        'Login'					=>			'1',
        'Verify'				=>			'2',
        'Profile'		    	=>			'3',
        'Packages'		    	=>			'4',
        'Main'					=>			'5',
        'Gateway'				=>			'6',
        'Discount'				=>			'7',
        'ShareApp'		    	=>			'8',
        'Search'				=>			'9',
        'Charts'				=>			'10',
        'Favorites'				=>			'11',
        'LastMood'		        =>			'12',
        'LastArtist'			=>			'13',
        'LastSearch'			=>			'14',
        'PlayHistory'			=>			'15',
        'PlayAnalytics'			=>			'16',
        'Friends'				=>			'17',
        'WebPage'				=>			'18',

    );

    return strtr($action, $action_array);
}

//
function main_custom_button($user_login, $user_lastseen, $user_firstname, $user_lastname, $user_email, $user_mobile, $user_gender, $user_updated, $active_packages, $favorite_items, $user_avatar, $user_birthday, $user_birthday_updated, $user_total_spent, $user_total_purchases, $user_is_verified) {
    $active_packages = json_decode(json_encode($active_packages), true);
    $normal_value = $active_packages['normal']['value'];
    $normal_validity = $active_packages['normal']['validity'];
    $timebased_value = $active_packages['timebased']['value'];
    $timebased_validity = $active_packages['timebased']['validity'];
    $subscription_validity = $active_packages['subscription']['validity'];
    $user_available_quota = $normal_value + $timebased_value;
    $control_behavior = false;

    if ($user_is_verified != true)
    {
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('Verify') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Verify';
        $type = 'Verify';
        $is_expandable = true;
        $can_view= true;
        $can_view_after = null;
        $can_view_before = null;
        $view_count = 100000;
        $name_en = 'Verify mobile';
        $name_fa = 'ثبت موبایل';
        $description_en = 'In order to access all part of the App, please verify your mobile number';
        $description_fa = 'برای استفاده از تمام قابلیت‌های اپلیکیشن، لطفاَ شماره موبایل خودتان را ثبت نمایید';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int) 45;
        $gradient_opacity = (int) 89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($user_email === null || $user_email === ' ')
    {
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('Email') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Profile';
        $type = 'Email';
        $is_expandable = true;
        $can_view= true;
        $can_view_after = null;
        $can_view_before = null;
        $view_count = 100000;
        $name_en = 'Add email';
        $name_fa = 'ثبت ایمیل';
        $description_en = 'Please provide your email. If you lose your account information we are unable to recover your account';
        $description_fa = 'لطفاَ ایمیل خودتان را ثبت کنید. اگر اطلاعات کاربری خودتان را فراموش کنید ما قادر به بازیابی اطلاعات کاربری شما نخواهیم بود';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int) 45;
        $gradient_opacity = (int) 89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($user_firstname === null || $user_firstname === ' ') {
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('FirstName') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Profile';
        $type = 'FirstName';
        $is_expandable = false;
        $can_view = true;
        $can_view_after = null;
        $can_view_before = null;
        $view_count = 100000;
        $name_en = 'Profile name';
        $name_fa = 'تکمیل نام';
        $description_en = 'Change your name in the profile page';
        $description_fa = 'نام‌تان را در صفحه پروفایل تغییر دهید';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($user_lastname === null || $user_lastname === ' ') {
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('LastName') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Profile';
        $type = 'LastName';
        $is_expandable = false;
        $can_view = true;
        $can_view_after = null;
        $can_view_before = null;
        $view_count = 100000;
        $name_en = 'Profile name';
        $name_fa = 'تکمیل نام';
        $description_en = 'Change your name in the profile page';
        $description_fa = 'نام‌تان را در صفحه پروفایل تغییر دهید';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($user_mobile === null || $user_mobile === ' ') {
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('Mobile') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Profile';
        $type = 'Mobile';
        $is_expandable = true;
        $can_view = true;
        $can_view_after = null;
        $can_view_before = null;
        $view_count = 100000;
        $name_en = 'Verify mobile';
        $name_fa = 'ثبت موبایل';
        $description_en = 'In order to access all part of the App, please verify your mobile number';
        $description_fa = 'برای استفاده از تمام قابلیت‌های اپلیکیشن، لطفاَ شماره موبایل خودتان را ثبت نمایید';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($user_gender === null || $user_gender === ' ') {
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('Gender') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Profile';
        $type = 'Gender';
        $is_expandable = true;
        $can_view = true;
        $can_view_after = null;
        $can_view_before = $user_updated + (7 * 60 * 60 * 24); // 7 days after registration
        $view_count = 100000;
        $name_en = 'Gender';
        $name_fa = 'جنسیت';
        $description_en = 'How we should address you';
        $description_fa = 'چگونه شما را صدا بزنیم';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($user_avatar === null || $user_avatar === ' ') {
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('Avatar') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Profile';
        $type = 'Avatar';
        $is_expandable = false;
        $can_view = true;
        $can_view_after = null;
        $can_view_before = null;
        $view_count = 100000;
        $name_en = 'Avatar';
        $name_fa = 'آواتار';
        $description_en = 'You don\'t have any pictrue';
        $description_fa = 'پروفایل شما هیچ عکسی ندارد';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($user_available_quota < 1 && $normal_validity == null) { // First login
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('First') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Packages';
        $type = 'FirstBuy';
        $is_expandable = true;
        $can_view = true;
        $can_view_after = null;
        $can_view_before = null;
        $view_count = 100000;
        $name_en = 'Charge account';
        $name_fa = 'شارژ اکانت';
        $description_en = 'Charge your account. Select, download and enjoy from thousands of tracks available in the ' . APP_PRETTY_NAME;
        $description_fa = 'اکانت‌تان را شارژ کنید. از بین هزاران تراک موجود در اپلیکیشن دیجی‌نوا انتخاب و دانلود کنید و لذت ببرید';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($user_available_quota < 5 ) { // Less than 5 quota available -> Charge quota
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('LowQuota') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Packages';
        $type = 'LowQuota';
        $is_expandable = true;
        $can_view = true;
        $can_view_after = null;
        $can_view_before = null;
        $view_count = 100000;
        $name_en = 'Low quota';
        $name_fa = 'تعداد کم';
        $description_en = 'Your quota is very low. You may download only few tracks. Please charge your quota to enjoy more';
        $description_fa = 'شارژ بسته‌تان خیلی کم شده است. تنها چند موسیقی دیگر می‌توانید دانلود کنید. لطفاَ اکانت‌تان را شارژ کنید تا لذت بیشتری ببرید';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($timebased_validity != null && $timebased_value > 1 && ($timebased_validity - time() < 60 * 60 * 24)) { // Timebased quota will expiring in less than a day
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('TimeBasedExpiring') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Packages';
        $type = 'TimeBasedExpiring';
        $is_expandable = true;
        $can_view = true;
        $can_view_after = time() - (3 * 60 * 60);
        $can_view_before = $timebased_validity - (3 * 60 * 60);
        $view_count = 100000;
        $name_en = 'Expiring';
        $name_fa = 'در حال انقضا';
        $description_en = 'Your timebased quota will expiring in less than a day. Please download some tracks';
        $description_fa = 'بسته زمان‌دار شما در کمتر از یک روز دیگر منقضی می‌شود.لطفاَ تراک‌های باقیمانده را دانلود نمایید';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($normal_value > 1 && ($normal_validity - time() < 60 * 60 * 24)) { // Normal quota will expiring in less than a day
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('NormalExpiring') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Packages';
        $type = 'NormalExpiring';
        $is_expandable = true;
        $can_view = true;
        $can_view_after = time() - (3 * 60 * 60);
        $can_view_before = $normal_validity - (3 * 60 * 60);
        $view_count = 100000;
        $name_en = 'Expiring';
        $name_fa = 'در حال انقضا';
        $description_en = 'Your quota will expiring in less than a day. Please download remaining tracks';
        $description_fa = 'بسته شما در کمتر از یک روز دیگر منقضی می‌شود.لطفاَ تراک‌های باقیمانده را دانلود نمایید';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($subscription_validity != null && $subscription_validity < time() + (2 * 24 * 60 * 60)) { // Subscription will expires in 2 days
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('SubscriptionExpiringIn2Days') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Packages';
        $type = 'SubscriptionExpiringIn2Days';
        $is_expandable = true;
        $can_view = true;
        $can_view_after = time() - (2 * 24 * 60 * 60);
        $can_view_before = $subscription_validity - (3 * 60 * 60);
        $view_count = 50;
        $name_en = 'Expiring';
        $name_fa = 'در حال انقضا';
        $description_en = 'Your subscription will expire in less than two days. Please renew your subscription plan';
        $description_fa = 'اشتراک سرویس استریم شما در کمتر از دو روز دیگر به اتمام می‌رسد. لطفاَ اشتراک خود را تمدید نمایید';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($subscription_validity != null && $subscription_validity < time()) { // Subscription already expired
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('SubscriptionExpired') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Packages';
        $type = 'SubscriptionExpired';
        $is_expandable = true;
        $can_view = true;
        $can_view_after = time();
        $can_view_before = $subscription_validity + (5 * 24 * 60 * 60);
        $view_count = 100000;
        $name_en = 'Expired';
        $name_fa = 'منقضی شده';
        $description_en = 'Your subscription is expired few days ago. Please renew your subscription plan to enjoy more';
        $description_fa = 'اشتراک سرویس استریم شما چند روز است که منقضی شده. لطفاَ برای لذت بیشتر اشتراک خود را تمدید نمایید';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($user_total_spent < 1) {
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('NotDownloadedYet') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Main';
        $type = 'NotDownloadedYet';
        $is_expandable = false;
        $can_view = true;
        $can_view_after = null;
        $can_view_before = null;
        $view_count = 50;
        $name_en = 'Download';
        $name_fa = 'دانلود';
        $description_en = 'Download your first track ;)';
        $description_fa = 'اولین آهنگ‌تان را دانلود کنید ;)';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif(!isset($favorite_items[0]) && $user_lastseen < time() - (3 * 24 * 60 * 60)) { // User is logged in the system but doesn't favorite anything
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('DontHaveFavorites') . ':' . $user_login);
        $control_behavior = true;
        $layout_id = 1;
        $action = 'Main';
        $type = 'DontHaveFavorites';
        $is_expandable = false;
        $can_view = true;
        $can_view_after = null;
        $can_view_before = null;
        $view_count = 100000;
        $name_en = 'Favorite';
        $name_fa = 'محبوب';
        $description_en = 'Make anything your favorite ;)';
        $description_fa = 'چیزی را محبوب کنید ;)';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($user_total_purchases > 100) { // User total purchase is more than 100, so give him a gift
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('PurchasesReached100') . ':' . $user_login);
        $control_behavior = false; // Change to activate
        $layout_id = 1;
        $action = 'Main';
        $type = 'PurchasesReached100';
        $is_expandable = false;
        $can_view = true;
        $can_view_after = null;
        $can_view_before = null;
        $view_count = 100000;
        $name_en = 'Favorite';
        $name_fa = 'محبوب';
        $description_en = 'Make anything your favorite ;)';
        $description_fa = 'چیزی را محبوب کنید ;)';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    } elseif($user_birthday_updated != null && $user_birthday_updated < (10 * 30 * 24 * 60 * 60 / 1000) /* && $user_birthday is in range */ ) { // During user_birthday 3 days, offer discount code
        $id = construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('UserBirthday') . ':' . $user_login);
        $control_behavior = false; // Change to activate
        $layout_id = 1;
        $action = 'Main';
        $type = 'UserBirthday';
        $is_expandable = false;
        $can_view = true;
        $can_view_after = null;
        $can_view_before = null;
        $view_count = 100000;
        $name_en = 'Favorite';
        $name_fa = 'محبوب';
        $description_en = 'Make anything your favorite ;)';
        $description_fa = 'چیزی را محبوب کنید ;)';
        $gradient_start = '#' . '1E31A1';
        $gradient_end = '#' . '2A4DB8';
        $gradient_degree = (int)45;
        $gradient_opacity = (int)89 / 100;
        $text_color = '#' . 'FFFFFF';
        $small_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';
        $large_image = 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg';

    }

    if ($control_behavior === true) {

        $custom_button = array(
            'id'                        => $id, // Service_id:System_id:User_token
            'layout_id'                 => $layout_id, // App layout
            'action'                    => $action,
            'type'                      => $type,
            'is_expandable'             => $is_expandable,
            'can_view'                  => $can_view,
            'can_view_after'            => $can_view_after,
            'can_view_before'           => $can_view_before,
            'view_count'                => $view_count,
            'gradient_start'            => $gradient_start,
            'gradient_end'              => $gradient_end,
            'gradient_degree'           => $gradient_degree,
            'gradient_opacity'          => $gradient_opacity,
            'text_color'                => $text_color,
            'name'                      => array(
                'en'		                => array(
                    'content'	                => $name_en,
                ),
                'fa'		                => array(
                    'content'	                => $name_fa,
                ),
            ),
            'description'                      => array(
                'en'		                => array(
                    'content'	                => $description_en,
                ),
                'fa'		                => array(
                    'content'	                => $description_fa,
                ),
            ),
            'small_image' 			   => $small_image,
            'large_image' 			   => $large_image,
        );

    } else
    {
        $custom_button = json_decode('{}');
    }

    return $custom_button;
}

//
function ic_normalize($string) {
	$normalizeChars = array(
		'Š'=>'S', 'š'=>'s', 'Ð'=>'Dj','Ž'=>'Z', 'ž'=>'z', 'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A',
		'Å'=>'A', 'Æ'=>'A', 'Ç'=>'C', 'È'=>'E', 'É'=>'E', 'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I',
		'Ï'=>'I', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U', 'Ú'=>'U',
		'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'B', 'ß'=>'ss','à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a',
		'å'=>'a', 'æ'=>'a', 'ç'=>'c', 'è'=>'e', 'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i', 'î'=>'i',
		'ï'=>'i', 'ð'=>'o', 'ñ'=>'n', 'ò'=>'o', 'ó'=>'o', 'ô'=>'o', 'õ'=>'o', 'ö'=>'o', 'ø'=>'o', 'ù'=>'u',
		'ú'=>'u', 'û'=>'u', 'ý'=>'y', 'þ'=>'b', 'ÿ'=>'y', 'ƒ'=>'f', 'Ł'=>'L', 'ł'=>'l', 
		'ă'=>'a', 'î'=>'i', 'â'=>'a', 'ș'=>'s', 'ț'=>'t', 'Ă'=>'A', 'Î'=>'I', 'Â'=>'A', 'Ș'=>'S', 'Ț'=>'T',
	);
	return strtr($string, $normalizeChars);
}

//
function ic_fr_genre($num) {
		$french_array = array(
			'1'=>'divers',
			'112'=>'pop-rock',
			'6'=>'chanson-francaise', 
			'64'=>'electro', 
			'127'=>'soul-funk-rap', 
			'133'=>'rap-hip-hop', 
			'2'=>'blues-country-folk', 
			'91'=>'musique-de-films', 
			'10'=>'classique', 
			'80'=>'jazz', 
			'94'=>'musiques-du-monde', 
			'142'=>'ambiance', 
			'167'=>'enfants', 
			'59'=>'diction-litterature', 

			'117'=>'pop', 
			'157'=>'pop-inde', 
			'119'=>'rock', 
			'113'=>'alternatif-et-inde', 
			'115'=>'hard-rock', 
			'116'=>'metal', 
			'118'=>'punk-new-wave', 
			'120'=>'rock-progressif', 
			'121'=>'rockabilly', 
			'122'=>'variete-internationale', 
			'114'=>'crooners', 
			'8'=>'retro', 
			'7'=>'interpretes', 
			'9'=>'rock-francais', 
			'65'=>'ambiant', 
			'129'=>'dance', 
			'66'=>'downtempo', 
			'67'=>'drum-bass', 
			'68'=>'house', 
			'69'=>'lounge', 
			'141'=>'new-age', 
			'70'=>'techno', 
			'71'=>'trance', 
			'72'=>'trip-hop', 
			'128'=>'acid-jazz', 
			'130'=>'disco', 
			'131'=>'funk', 
			'132'=>'rb', 
			'134'=>'soul', 
			'3'=>'blues', 
			'4'=>'country', 
			'5'=>'folk', 
			'92'=>'bandes-originales-de-films', 
			'93'=>'comedies-musicales', 
			'148'=>'jeux-video', 
			'147'=>'series-tv', 

			'11'=>'electronique-ou-concrete', 
			'15'=>'melodies-lieder', 
			'22'=>'musique-concertante', 
			'27'=>'musique-de-chambre', 
			'37'=>'musique-orchestrale', 
			'44'=>'musique-vocale-profane-et-sacree', 
			'176'=>'musique-vocale-profane', 
			'50'=>'musique-vocale-sacree', 
			'55'=>'opera', 
			'58'=>'operette', 
			'12'=>'musique-concrete', 
			'13'=>'musique-electronique', 
			'14'=>'musique-minimaliste', 
			'17'=>'lieder-autres-territoires', 
			'16'=>'lieder-allemagne', 
			'18'=>'melodies-autres-territoires', 
			'19'=>'melodies-angleterre', 
			'20'=>'melodies-europe-du-nord', 
			'21'=>'melodies-france', 
			'24'=>'concertos-pour-piano', 
			'138'=>'concertos-pour-instruments-a-vent', 
			'137'=>'concertos-pour-trompette', 
			'25'=>'concertos-pour-violon', 
			'26'=>'concertos-pour-violoncelle', 
			'33'=>'sonates-pour-deux-instruments', 
			'30'=>'piano-solo', 
			'31'=>'quatuors', 
			'32'=>'quintettes', 
			'34'=>'trios', 
			'35'=>'violon-solo', 
			'36'=>'violoncelle-solo', 
			'38'=>'ballets', 
			'39'=>'musique-de-scene', 
			'40'=>'musiques-pour-le-cinema', 
			'41'=>'ouvertures', 
			'42'=>'poemes-symphoniques', 
			'43'=>'symphonies', 
			'46'=>'musique-chorale-pour-chour', 
			'47'=>'musique-d-ensemble-musique-sans-chour', 
			'49'=>'recitals-vocaux', 
			'45'=>'cantates-profanes', 
			'48'=>'oratorios-profanes', 
			'51'=>'cantates-sacrees', 
			'52'=>'chours-sacres', 
			'53'=>'messes-passions-requiems', 
			'54'=>'oratorios-sacrees', 
			'56'=>'extraits', 
			'57'=>'integrales', 
			'81'=>'be-bop', 
			'82'=>'cool', 
			'144'=>'jazz-crossover', 
			'145'=>'dixieland', 
			'83'=>'free-jazz-avant-garde', 
			'84'=>'gospel', 
			'85'=>'jazz-contemporain', 
			'86'=>'jazz-fusion-jazz-rock', 
			'87'=>'jazz-manouche', 
			'88'=>'jazz-traditionnel-new-orleans', 
			'89'=>'jazz-vocal', 
			'90'=>'latin-jazz', 
			'146'=>'ragtime', 
			'95'=>'afrique', 
			'96'=>'afrobeat', 
			'150'=>'amerique-du-nord', 
			'149'=>'amerique-latine', 
			'97'=>'asie', 
			'98'=>'bossa-nova-bresil', 
			'99'=>'celtique', 
			'151'=>'europe', 
			'101'=>'fado', 
			'102'=>'flamenco', 
			'152'=>'gipsy', 
			'154'=>'maghreb', 
			'104'=>'musique-indienne', 
			'105'=>'orient-maghreb', 
			'106'=>'rai', 
			'123'=>'reggae', 
			'155'=>'russie', 
			'107'=>'salsa', 
			'108'=>'tango', 
			'156'=>'turquie', 
			'110'=>'yiddish-klezmer', 
			'111'=>'zouk-antilles', 
			'160'=>'allemagne', 
			'161'=>'ecosse', 
			'162'=>'espagne', 
			'100'=>'europe-de-l-est', 
			'163'=>'grece', 
			'164'=>'irlande', 
			'165'=>'italie', 
			'168'=>'musique-folklorique-suisse', 
			'166'=>'portugal', 
			'173'=>'schlager', 
			'171'=>'stimmungsmusik', 
			'172'=>'volksmusik', 
			'174'=>'irish-celtic', 
			'175'=>'irish-popmusic', 
			'124'=>'dancehall', 
			'125'=>'dub', 
			'126'=>'ska-rocksteady', 
			'74'=>'accordeon', 
			'158'=>'chansons-paillardes', 
			'77'=>'karaoke', 
			'78'=>'musique-militaire', 
			'159'=>'musiques-de-noel', 
			'79'=>'relaxation', 
			'75'=>'contes-et-comptines', 
			'76'=>'educatif', 
			'178'=>'allemand', 
			'177'=>'anglais', 
			'170'=>'francais', 
			'62'=>'humour', 
			'63'=>'litterature', 
			'179'=>'neerlandais', 
			'61'=>'documents-historiques', 
			'60'=>'pedagogie', 
		);
		return strtr($num, $french_array);
	}

//
function ic_en_genre($num) {
		$english_array = array(
			'1'=>'compilation',
			'112'=>'pop-rock',
			'6'=>'french-music', 
			'64'=>'electro', 
			'127'=>'soul-funk-rap', 
			'133'=>'rap-hip-hop', 
			'2'=>'blues-country-folk', 
			'91'=>'soundtracks', 
			'10'=>'classical-music', 
			'80'=>'jazz', 
			'94'=>'world-music', 
			'142'=>'ambience', 
			'167'=>'children', 
			'59'=>'spoken-words', 

			'117'=>'pop', 
			'157'=>'indie-pop', 
			'119'=>'rock', 
			'113'=>'alternative-and-indie', 
			'115'=>'hard-rock', 
			'116'=>'metal', 
			'118'=>'punk-new-wave', 
			'120'=>'progressive-rock', 
			'121'=>'rockabilly', 
			'122'=>'international-pop', 
			'114'=>'crooners', 
			'8'=>'retro-french-music', 
			'7'=>'french-artists', 
			'9'=>'french-rock', 
			'65'=>'ambiant', 
			'129'=>'dance', 
			'66'=>'downtempo', 
			'67'=>'drum-bass', 
			'68'=>'house', 
			'69'=>'lounge', 
			'141'=>'new-age', 
			'70'=>'techno', 
			'71'=>'trance', 
			'72'=>'trip-hop', 
			'128'=>'acid-jazz', 
			'130'=>'disco', 
			'131'=>'funk', 
			'132'=>'r-and-b', 
			'134'=>'soul', 
			'3'=>'blues', 
			'4'=>'country', 
			'5'=>'folk', 
			'92'=>'film-soundtracks', 
			'93'=>'musical-theatre', 
			'148'=>'video-games', 
			'147'=>'tv-series', 

			'11'=>'experimental-music', 
			'15'=>'lieder', 
			'22'=>'concertos', 
			'27'=>'chamber-music', 
			'37'=>'orchestral-music', 
			'44'=>'vocal-music', 
			'176'=>'secular-vocal-music', 
			'50'=>'sacred-vocal-music', 
			'55'=>'opera', 
			'58'=>'operettas', 
			'12'=>'concrete-music', 
			'13'=>'electronic-music', 
			'14'=>'minimal-music', 
			'17'=>'art-songs', 
			'16'=>'german-lieder', 
			'18'=>'melodies', 
			'19'=>'english-melodies', 
			'20'=>'northern-europe-melodies', 
			'21'=>'french-melodies', 
			'24'=>'keyboard-concertos', 
			'138'=>'concertos-for-wind-instruments', 
			'137'=>'concertos-for-trumpet', 
			'25'=>'concertos-for-violin', 
			'26'=>'concertos-for-violoncello', 
			'33'=>'duets', 
			'30'=>'solo-piano', 
			'31'=>'quartets', 
			'32'=>'quintets', 
			'34'=>'trios', 
			'35'=>'solo-violin', 
			'36'=>'solo-violoncello', 
			'38'=>'ballets', 
			'39'=>'theatre-music', 
			'40'=>'cinema-music', 
			'41'=>'overtures', 
			'42'=>'symphonic-poems', 
			'43'=>'symphonies', 
			'46'=>'choral-music', 
			'47'=>'vocal-ensemble', 
			'49'=>'vocal-recitals', 
			'45'=>'secular-cantatas', 
			'48'=>'secular-oratorios', 
			'51'=>'sacred-cantatas', 
			'52'=>'sacred-chorals', 
			'53'=>'masses-passions-requiems', 
			'54'=>'sacred-oratorios', 
			'56'=>'opera-extracts', 
			'57'=>'complete-operas', 
			'81'=>'bebop', 
			'82'=>'cool-jazz', 
			'144'=>'crossover-jazz', 
			'145'=>'dixieland', 
			'83'=>'free-jazz-and-avant-garde', 
			'84'=>'gospel', 
			'85'=>'contemporary-jazz', 
			'86'=>'jazz-fusion-and-jazz-rock', 
			'87'=>'gypsy-jazz', 
			'88'=>'traditional-jazz-and-new-orleans', 
			'89'=>'vocal-jazz', 
			'90'=>'latin-jazz', 
			'146'=>'ragtime', 
			'95'=>'africa', 
			'96'=>'afrobeat', 
			'150'=>'north-america', 
			'149'=>'latin-america', 
			'97'=>'asia', 
			'98'=>'bossa-nova-and-brazilian-music', 
			'99'=>'celtic-music', 
			'151'=>'european-music', 
			'101'=>'fado', 
			'102'=>'flamenco', 
			'152'=>'gypsy', 
			'154'=>'maghreb', 
			'104'=>'indian-music', 
			'105'=>'oriental-music', 
			'106'=>'rai', 
			'123'=>'reggae', 
			'155'=>'russian-music', 
			'107'=>'salsa', 
			'108'=>'tango', 
			'156'=>'turkish-music', 
			'110'=>'yiddish-and-klezmer', 
			'111'=>'zouk-and-antilles', 
			'160'=>'german-music', 
			'161'=>'scottish-music', 
			'162'=>'spanish-music', 
			'100'=>'eastern-european-music', 
			'163'=>'music-of-greece', 
			'164'=>'irish-music', 
			'165'=>'italian-music', 
			'168'=>'swiss-folk-music', 
			'166'=>'music-of-portugal', 
			'173'=>'schlager', 
			'171'=>'stimmungsmusik', 
			'172'=>'volksmusik', 
			'174'=>'irish-celtic', 
			'175'=>'irish-pop-music', 
			'124'=>'dancehall', 
			'125'=>'dub', 
			'126'=>'ska-rocksteady', 
			'74'=>'accordion-music', 
			'158'=>'bawdy-songs', 
			'77'=>'karaoke', 
			'78'=>'military-music', 
			'159'=>'christmas-music', 
			'79'=>'relaxation', 
			'75'=>'stories-and-nursery-rhymes', 
			'76'=>'educational-music', 
			'178'=>'german', 
			'177'=>'english', 
			'170'=>'french', 
			'62'=>'humor', 
			'63'=>'literature', 
			'179'=>'dutch', 
			'61'=>'historical-documents', 
			'60'=>'educational', 
		);
		return strtr($num, $english_array);
	}

//
function ic_genres($num) {
		$english_array = array(
			'1'=>'Compilation',
			'112'=>'Pop & Rock', 
			'6'=>'French Music', 
			'64'=>'Electro', 
			'127'=>'Soul, Funk, Rap', 
			'133'=>'Rap, Hip-hop', 
			'2'=>'Blues, Country, Folk', 
			'91'=>'Soundtracks', 
			'10'=>'Classical Music', 
			'80'=>'Jazz', 
			'94'=>'World Music', 
			'142'=>'Ambience', 
			'167'=>'Children', 
			'59'=>'Spoken Words', 

			'117'=>'Pop', 
			'157'=>'Indie Pop', 
			'119'=>'Rock', 
			'113'=>'Alternative & Indie', 
			'115'=>'Hard Rock', 
			'116'=>'Metal', 
			'118'=>'Punk, New Wave', 
			'120'=>'Progressive Rock', 
			'121'=>'Rockabilly', 
			'122'=>'International Pop', 
			'114'=>'Crooners', 
			'8'=>'Retro French Music', 
			'7'=>'French Artists', 
			'9'=>'French Rock', 
			'65'=>'Ambient', 
			'129'=>'Dance', 
			'66'=>'Downtempo', 
			'67'=>'Drum & Bass', 
			'68'=>'House', 
			'69'=>'Lounge', 
			'141'=>'New Age', 
			'70'=>'Techno', 
			'71'=>'Trance', 
			'72'=>'Trip Hop', 
			'128'=>'Acid Jazz', 
			'130'=>'Disco', 
			'131'=>'Funk', 
			'132'=>'R&B', 
			'134'=>'Soul', 
			'3'=>'Blues', 
			'4'=>'Country', 
			'5'=>'Folk', 
			'92'=>'Film Soundtracks', 
			'93'=>'Musical Theater', 
			'148'=>'Video Games', 
			'147'=>'TV Series', 

			'11'=>'Experimental Music', 
			'15'=>'Lieder', 
			'22'=>'Concertos', 
			'27'=>'Chamber Music', 
			'37'=>'Orchestral Music', 
			'44'=>'Vocal Music', 
			'176'=>'Secular Vocal Music', 
			'50'=>'Sacred Vocal Music', 
			'55'=>'Opera', 
			'58'=>'Operettas', 
			'12'=>'Concrete Music', 
			'13'=>'Electronic Music', 
			'14'=>'Minimal Music', 
			'17'=>'Art Songs', 
			'16'=>'German Lieder', 
			'18'=>'Melodies', 
			'19'=>'English Melodies', 
			'20'=>'Northern Europe Melodies', 
			'21'=>'French Melodies', 
			'24'=>'Keyboard Concertos', 
			'138'=>'Concertos for Wind Instruments', 
			'137'=>'Concertos for Trumpet', 
			'25'=>'Concertos for Violin', 
			'26'=>'Concertos for Violoncello', 
			'33'=>'Duets', 
			'30'=>'Solo Piano', 
			'31'=>'Quartets', 
			'32'=>'Quintets', 
			'34'=>'Trios', 
			'35'=>'Solo Violin', 
			'36'=>'Solo Violoncello', 
			'38'=>'Ballets', 
			'39'=>'Theater Music', 
			'40'=>'Cinema Music', 
			'41'=>'Overtures', 
			'42'=>'Symphonic Poems', 
			'43'=>'Symphonies', 
			'46'=>'Choral Music', 
			'47'=>'Vocal Ensemble', 
			'49'=>'Vocal Recitals', 
			'45'=>'Secular Cantatas', 
			'48'=>'Secular Oratorios', 
			'51'=>'Sacred Cantatas', 
			'52'=>'Sacred Chorals', 
			'53'=>'Masses, Passions, Requiems', 
			'54'=>'Sacred Oratorios', 
			'56'=>'Opera Extracts', 
			'57'=>'Complete Operas', 
			'81'=>'Bebop', 
			'82'=>'Cool Jazz', 
			'144'=>'Crossover Jazz', 
			'145'=>'Dixieland', 
			'83'=>'Free Jazz & Avant-garde', 
			'84'=>'Gospel', 
			'85'=>'Contemporary Jazz', 
			'86'=>'Jazz Fusion & Jazz Rock', 
			'87'=>'Gypsy Jazz', 
			'88'=>'Traditional Jazz & New Orleans', 
			'89'=>'Vocal Jazz', 
			'90'=>'Latin Jazz', 
			'146'=>'Ragtime', 
			'95'=>'Africa', 
			'96'=>'Afrobeat', 
			'150'=>'North America', 
			'149'=>'Latin America', 
			'97'=>'Asia', 
			'98'=>'Bossa Nova & Brazilian Music', 
			'99'=>'Celtic Music', 
			'151'=>'European Music', 
			'101'=>'Fado', 
			'102'=>'Flamenco', 
			'152'=>'Gypsy', 
			'154'=>'Maghreb', 
			'104'=>'Indian Music', 
			'105'=>'Oriental Music', 
			'106'=>'Rai', 
			'123'=>'Reggae', 
			'155'=>'Russian Music', 
			'107'=>'Salsa', 
			'108'=>'Tango', 
			'156'=>'Turkish Music', 
			'110'=>'Yiddish & Klezmer', 
			'111'=>'Zouk & Antilles', 
			'160'=>'German Music', 
			'161'=>'Scottish Music', 
			'162'=>'Spanish Music', 
			'100'=>'Eastern European Music', 
			'163'=>'Music of Greece', 
			'164'=>'Irish Music', 
			'165'=>'Italian Music', 
			'168'=>'Swiss Folk Music', 
			'166'=>'Music of Portugal', 
			'173'=>'Schlager', 
			'171'=>'Stimmungsmusik', 
			'172'=>'Volksmusik', 
			'174'=>'Irish Celtic', 
			'175'=>'Irish Pop Music', 
			'124'=>'Dancehall', 
			'125'=>'Dub', 
			'126'=>'Ska & Rocksteady', 
			'74'=>'Accordion Music', 
			'158'=>'Bawdy Songs', 
			'77'=>'Karaoke', 
			'78'=>'Military Music', 
			'159'=>'Christmas Music', 
			'79'=>'Relaxation', 
			'75'=>'Stories & Nursery Rhymes', 
			'76'=>'Educational Music', 
			'178'=>'German', 
			'177'=>'English', 
			'170'=>'French', 
			'62'=>'Humor', 
			'63'=>'Literature', 
			'179'=>'Dutch', 
			'61'=>'Historical Documents', 
			'60'=>'Educational', 
		);
		return strtr($num, $english_array);
	}

//
function ic_genres_fa($num) {
		$english_array = array(
			'1'=>'گلچین',
			'112'=>'پاپ و راک', 
			'6'=>'موسیقی فرانسوی', 
			'64'=>'الکترو', 
			'127'=>'سول، فانک ، رَپ', 
			'133'=>'رَپ، هیپ‌هاپ', 
			'2'=>'بلوز، کانتری، فولک', 
			'91'=>'ساند تراک', 
			'10'=>'موسیقی کلاسیک', 
			'80'=>'جَز', 
			'94'=>'موسیقی جهان', 
			'142'=>'آمبیِنس', 
			'167'=>'کودکانه', 
			'59'=>'منابع گفتاری', 

			'117'=>'پاپ', 
			'157'=>'پاپ مستقل', 
			'119'=>'راک', 
			'113'=>'نوع دیگر، موسیقی مستقل', 
			'115'=>'هارد راک', 
			'116'=>'متال', 
			'118'=>'پانک، موج نو', 
			'120'=>'راک پروگرسیو', 
			'121'=>'راک اَند رول', 
			'122'=>'پاپ بین‌المللی', 
			'114'=>'کرونرز', 
			'8'=>'موسیقی قدیمی', 
			'7'=>'هنرمندان فرانسوی', 
			'9'=>'راک فرانسوی', 
			'65'=>'آمبیِنت', 
			'129'=>'دانس', 
			'66'=>'موسیقی آرام', 
			'67'=>'باس و درامز', 
			'68'=>'هاووس', 
			'69'=>'لانژ', 
			'141'=>'نیو ایج', 
			'70'=>'تکنو', 
			'71'=>'ترانس', 
			'72'=>'تریپ هاپ', 
			'128'=>'اسید جَز', 
			'130'=>'دیسکو', 
			'131'=>'فانک', 
			'132'=>'آر اَند بی', 
			'134'=>'سول', 
			'3'=>'بلوز', 
			'4'=>'کانتری', 
			'5'=>'فولک', 
			'92'=>'موسیقی فیلم', 
			'93'=>'تئاتر موزیکال', 
			'148'=>'موسیقی بازی', 
			'147'=>'سریال‌های تلویزیونی', 

			'11'=>'اکسپریمنتال', 
			'15'=>'لید', 
			'22'=>'کنسرتو', 
			'27'=>'موسیقی مجلسی', 
			'37'=>'موسیقی ارکسترال', 
			'44'=>'موسیقی آوازی', 
			'176'=>'موسیقی آوازی غیرمذهبی', 
			'50'=>'موسیقی آوازی مذهبی', 
			'55'=>'اُپرا', 
			'58'=>'اُپرت', 
			'12'=>'موسیقی کانکریت', 
			'13'=>'موسیقی الکترونیک', 
			'14'=>'موسیقی مینیمال', 
			'17'=>'آواز‌های هنری', 
			'16'=>'لید آلمانی', 
			'18'=>'بِل کانتو', 
			'19'=>'آوازهای انگلیسی', 
			'20'=>'آوازهای اروپای شمالی', 
			'21'=>'آوازهای فرانسوی', 
			'24'=>'کنسرتو برای ساز شستی‌دار', 
			'138'=>'کنسرتو‌های بادی چوبی', 
			'137'=>'ترومپت کنسرتو', 
			'25'=>'ویولن کنسرتو', 
			'26'=>'ویولنسل کنسرتو', 
			'33'=>'دوئت', 
			'30'=>'پیانو', 
			'31'=>'کوارتت', 
			'32'=>'کوئینتت', 
			'34'=>'تریو', 
			'35'=>'ویولن', 
			'36'=>'ویولنسل', 
			'38'=>'بالت', 
			'39'=>'موسیقی تئاتر', 
			'40'=>'موسیقی سینماتیک', 
			'41'=>'اُورتور', 
			'42'=>'پوئم سمفونی', 
			'43'=>'سمفونی', 
			'46'=>'موسیقی کُرال', 
			'47'=>'گروه آوازی', 
			'49'=>'رسیتال آواز', 
			'45'=>'کانتات غیرمذهبی', 
			'48'=>'اُراتوریو غیرمذهبی', 
			'51'=>'کانتات مذهبی', 
			'52'=>'کُر مذهبی', 
			'53'=>'مَس، پاسیون، رکوئیم', 
			'54'=>'اُراتوریو مذهبی', 
			'56'=>'خلاصه اُپرا', 
			'57'=>'اُپرای کامل', 
			'81'=>'بیباپ', 
			'82'=>'کوول جَز', 
			'144'=>'جَز تلفیقی', 
			'145'=>'دیکسیلند', 
			'83'=>'جَز آزاد و آوانگارد', 
			'84'=>'گوسپل', 
			'85'=>'جَز معاصر', 
			'86'=>'فیوژن جَز ، راک جَز', 
			'87'=>'جَز کولی', 
			'88'=>'جَز اصیل و نیواُرلئان', 
			'89'=>'جَز آوازی', 
			'90'=>'لاتین جَز', 
			'146'=>'رگتایم', 
			'95'=>'آفریقا', 
			'96'=>'آفرو بیت', 
			'150'=>'آمریکای شمالی', 
			'149'=>'آمریکای لاتین', 
			'97'=>'آسیا', 
			'98'=>'بوسا نووا و موسیقی برزیل', 
			'99'=>'موسیقی سلتیک', 
			'151'=>'موسیقی اروپا', 
			'101'=>'فادو', 
			'102'=>'فلامنکو', 
			'152'=>'کولی', 
			'154'=>'مغرب', 
			'104'=>'موسیقی هند', 
			'105'=>'موسیقی بومی', 
			'106'=>'رای', 
			'123'=>'رِگی', 
			'155'=>'موسیقی روسیه', 
			'107'=>'سالسا', 
			'108'=>'تانگو', 
			'156'=>'موسیقی ترکی', 
			'110'=>'کلزمر', 
			'111'=>'زوک و آنتیل', 
			'160'=>'موسیقی آلمانی', 
			'161'=>'موسیقی اسکاتلند', 
			'162'=>'موسیقی اسپانیولی', 
			'100'=>'موسیقی اروپای شرقی', 
			'163'=>'موسیقی یونان', 
			'164'=>'موسیقی ایرلندی', 
			'165'=>'موسیقی ایتالیایی', 
			'168'=>'موسیقی محلی سوییس', 
			'166'=>'موسیقی پرتغال', 
			'173'=>'شلاگر', 
			'171'=>'موود موزیک', 
			'172'=>'فولک آلمانی', 
			'174'=>'سلتیک ایرلندی', 
			'175'=>'پاپ ایرلندی', 
			'124'=>'بالروم', 
			'125'=>'داب', 
			'126'=>'اسکا و موسیقی جامائیکا', 
			'74'=>'آکاردئون', 
			'158'=>'هجو', 
			'77'=>'کارائوکه', 
			'78'=>'موسیقی نظامی', 
			'159'=>'موسیقی کریسمس', 
			'79'=>'آرامش بخش', 
			'75'=>'داستان و لالائی', 
			'76'=>'موسیقی آموزشی', 
			'178'=>'آلمانی', 
			'177'=>'انگلیسی', 
			'170'=>'فرانسوی', 
			'62'=>'کمیک', 
			'63'=>'ادبی', 
			'179'=>'هلندی', 
			'61'=>'اسناد تاریخی', 
			'60'=>'آموزشی', 
		);
		return strtr($num, $english_array);
	}

//
function octal_2_encrypt($string, $base = 9){

	return base_convert($string, 10, $base);
}

//
function encrypt_2_octal($string, $base = 9){

	return base_convert($string, $base, 10);
}

//
function charset_base_convert($numstring, $fromcharset, $tocharset) {
	// https://stackoverflow.com/a/4668620/4013321
	// EX.
	// echo charset_base_convert('104953317194547002202', '0123456789', '0123456789zxcvbnmasdfghjklqwertyuiopZXCVBNMASDFGHJKLQWERTYUIOP-_');
	$frombase=strlen($fromcharset);
	$tobase=strlen($tocharset);
	$chars = $fromcharset;
	$tostring = $tocharset;
	
	$length = strlen($numstring);
	$result = '';
	for ($i = 0; $i < $length; $i++) {
		$number[$i] = strpos($chars, $numstring{$i});
	}
	do {
		$divide = 0;
		$newlen = 0;
		for ($i = 0; $i < $length; $i++) {
			$divide = $divide * $frombase + $number[$i];
			if ($divide >= $tobase) {
				$number[$newlen++] = (int)($divide / $tobase);
				$divide = $divide % $tobase;
			} elseif ($newlen > 0) {
				$number[$newlen++] = 0;
			}
		}
		$length = $newlen;
		$result = $tostring{$divide} . $result;
	}
	while ($newlen != 0);
	return $result;
}

//
function explode_unique_id($unique_id) {
	return explode('-', $unique_id);
}

//
function generate_small_uuid($timestamp){
	// At first we trim timestamp the biggest number : e.g. 1583736724 to 583736724  
	$small_uuid = substr($timestamp, 1, strlen($timestamp));
	// we convert the number to base36
	$small_uuid = octal_2_encrypt($small_uuid, 36);
	// for the sake of uniqueness we add two alphabets at the first position
	// https://stackoverflow.com/a/5439548
	$small_uuid = substr(str_shuffle("123456789abcdefghijklmnopqrstuvwxyz"), 0, 2) . $small_uuid;
	
	return $small_uuid;
}

//
function convert_small_uuid_with_hash($small_uuid, $first_place = 2, $second_place = 5){
	// put hash in 2nd and 5th place of the string
	$small_uuid = substr_replace($small_uuid, '-', $first_place, 0);
	$small_uuid = substr_replace($small_uuid, '-', ($second_place + 1), 0);
	
	return $small_uuid;
}

//
function hdryn_change_france($string) {
	$normalizeChars = array(
		'Compositeurs Divers'=>'Various Composers', 'Interprètes Divers'=>'Various Artists', 'Œuvres'=>'Works', 'oeuvre'=>'works', 'ioloncelle'=>'ioloncello',
		' pour '=>' for ', ' par '=>' by ', ' et '=>' and ', 'Quatuors à cordes'=>'String Quartet', 'Intégrale des quatuors'=>'Complete Quartets', 'rchestre'=>'rchestra',
		'Quatuor'=>'Quartet', 'Musique'=>'Music', 'musique'=>'music', 'Mélodies'=>'Melodies', 'instruments à vent'=>'Woodwind Instruments', ' ou '=>' or ', 'guitare'=>'guitar',
		'clavier'=>'keyboard', 'Clavier'=>'Keyboard', 'quatuor'=>'quartet', 'Musique de chambre'=>'Chamber music', ' du '=>' of ', 'Œuvres orchestrales'=>'Orchestral works', 
		' des '=>' ', 'chœur'=>'choir', 'Chœur'=>'Choir', 'vocaux'=>'voice', 'Vocaux'=>'Voice', 'Chœurs'=>'Choir', 'œuvres orchestrales'=>'orchestral works', 
		'Extraits d\'opéra'=>'Opera extracts', 'Intégrales d\'opéra'=>'Complete opera', ' de '=>' of ', 'Les '=>'The ', 'Intégrale'=>'Complete', 'Compositeurs Divers'=>'Various Composers', 
		'cordes'=>'strings', 'Cordes'=>'Strings', 'Multi Interpretes'=>'Various Artists', 'musique'=>'music', 'classique'=>'classical', 'compositeurs divers'=>'various composers', 
		' les '=>' the ', 'Le '=>'The ', 'La '=>'The ', ' sur '=>' on ', 'ompositeur'=>'omposer', 'interprète'=>'performer', 'Interprète'=>'Artist', ' auteur'=>' author', ' Auteur'=>' Author',
		'Livre '=>'Book ', ' seul '=>' solo ', ' Seul '=>' Solo ', ' per '=>' for ', 'Orchestre de chambre'=>'Chamber Orchestra', 'Œuvres originales'=>'Original Works',
		' avec '=>' with ', ' Avec '=>' With ', ' flûte à bec'=>' recorder', 'Flûte à bec '=>'Recorder ', 'larinette '=>'larinet ', 'Oeuvres '=>'Works ', ' oeuvres'=>' works',
		' violon'=>' violin', 'Violon '=>'Violin ', ' orgue'=>' organ', 'Orgue '=>'Organ ', 'rompette'=>'rompet', 'concertos romantiques'=>'romantic concertos', 'Concertos romantiques'=>'Romantic concertos',
		'Bande originale'=>'Original sound track', 'Bande Originale'=>'Original Soundtrack', 'bande originale'=>'original sound track', 'L\''=>'The ', ' l\''=>' the ', ' le '=>' the ', ' la '=>' the ',
		'Interprets'=>'Performers', 'interprets'=>'performers', 'D\''=>'The ', ' d\''=>' the ', ' chefs-d\'oeuvre'=>' masterpieces', ' chef-d\'oeuvre'=>' masterpiece', 'Chefs-d\'oeuvre'=>'Masterpieces',
 		'Chef-d\'oeuvre'=>'Masterpiece'

	);
	return strtr($string, $normalizeChars);
}

//
function prepareLength($string, $length = 14, $placeholder = '_', $placement = 'left'){
	if ( $placement == 'right' )
	{
		while ( strlen($string) < $length ) {
			$string = $string . $placeholder;
		}
		
	} else {
		while ( strlen($string) < $length ) {
			$string = $placeholder . $string;
		}
	}

	return $string;
}

//
function non_negative($num) {
    // Bug, fixed according to https://andy-carter.com/blog/setting-negative-numbers-to-zero-in-php
    return max($num, 0);
}

//
function image_corrector($image, $change = 'd250ptlkmugbjz.cloudfront.net'){
	return preg_replace("/static.qobuz.com/", $change, $image);
}

//
function random_image_host( $check = FALSE ){

	$array=array("https://daaghs1.cdnmundi.com/","https://daaghs2.cdnmundi.com/");

	$array_size=count($array);

	if ( $check == 1 ) // always first one
	{
		$rand_key= 1;
	} else {
		$rand_key=rand(0,$array_size-1);
	}

	$rand_element=$array[$rand_key];

	return $rand_element;
}

//
function checkSafeValue($var, $default = "null") {
	return empty($var) ? $default : $var;
}

//
function change_category_type($string) {
			
	// 		most-streamed, best-sellers, new-releases, press-awards, editor-picks, most-featured, harmonia-mundi, universal-classic, universal-jazz, universal-jeunesse, universal-chanson, new-releases-full, recent-releases, ideal-discography
			
	$name_array = array(
		'most-listened'		  =>		'most-streamed',
		'most-downloaded'	  =>		'best-sellers',
		'most-awards'		  =>		'press-awards',
		'diginava-pick'		  =>		'editor-picks',
		'best-overall'		  =>		'most-featured',
		'new-albums'		  =>		'new-releases-full',
		'new-artists'		  =>		'universal-jeunesse',
		'most-collectors'	  =>		'ideal-discography',
		'new-music'			  =>		'new-releases',
		'new-reissue'		  =>		'recent-releases',
			
	);
	return strtr($string, $name_array);
}
	
//
function back_category_type($string) {
			
	// 		most-streamed, best-sellers, new-releases, press-awards, editor-picks, most-featured, harmonia-mundi, universal-classic, universal-jazz, universal-jeunesse, universal-chanson, new-releases-full, recent-releases, ideal-discography
			
	$name_array = array(
		'most-streamed'		  =>		'most-listened',
		'best-sellers'		  =>		'most-downloaded',
		'press-awards'		  =>		'most-awards',
		'editor-picks'		  =>		'diginava-pick',
		'most-featured'		  =>		'best-overall',
		'new-releases-full'	  =>		'new-albums',
		'universal-jeunesse'  =>		'new-artists',
		'ideal-discography'	  =>		'most-collectors',
		'new-releases'		  =>		'new-music',
		'recent-releases'	  =>		'new-reissue',
			
	);
	return strtr($string, $name_array);
}

//
function trimSpace($string) {
	if ( strlen($string) < 7 )
	{
		$string = preg_replace("/ /", "", $string);
		$string = preg_replace("/(\\\r|\\\r\\\n|\\\n)/", "", $string);

	} elseif ( !preg_match("/[a-z]/i", $string) )  // [\r\n ]. We also search if the $string doesn't contain the alphabet [could be a blank in any length "\r\n  " ]
	{
		$string = preg_replace("/ /", " ", $string);
		$string = preg_replace("/(\\\r|\\\r\\\n|\\\n)/", "", $string);
	}

	return $string;
}

//
function id_encrypt($id) {
	return preg_replace("/_/", "", encrypt($id, '17acbece5763563d'));
}
	
//
function id_decrypt($id) {
	return decrypt($id, '17acbece5763563d');
}

//
function encrypt($str, $key = "F2avHrF62o8jLZFREEEEN65zs7otsXV"){
  $result = '';
  for($i=0, $iMax = strlen($str); $i< $iMax; $i++) {
     $char = substr($str, $i, 1);
     $keychar = substr($key, ($i % strlen($key))-1, 1);
     $char = chr(ord($char)+ord($keychar));
     $result.=$char;
  }
  return safe_b64encode($result);
}

//
function decrypt($str, $key = "F2avHrF62o8jLZFREEEEN65zs7otsXV"){
  $str = safe_b64decode($str);
  $result = '';
  for($i=0, $iMax = strlen($str); $i< $iMax; $i++) {
    $char = substr($str, $i, 1);
    $keychar = substr($key, ($i % strlen($key))-1, 1);
    $char = chr(ord($char)-ord($keychar));
    $result.=$char;
  }
return $result;
}

//
function safe_b64encode($string) {
	$data = base64_encode($string);
	$data = str_replace(array('+','/','='),array('-','~','_'),$data);
	return $data;
}

//
function safe_b64decode($string) {
	$data = str_replace(array('-','~','_'),array('+','/','='),$string);
	$mod4 = strlen($data) % 4;
	if ($mod4) {
			$data .= substr('====', $mod4);
	}
	return base64_decode($data);
}

//
function md5_encrypt($plainText, $key) {
	// Based on Nanhe Kumar answer : https://stackoverflow.com/a/52253745/4013321
	$secretKey = hextobin(md5($key));
	$initVector = pack("C*", 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f);
	$openMode = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', 'cbc', '');
	$blockSize = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, 'cbc');
	$plainPad = pkcs5_pad($plainText, $blockSize);
	if (mcrypt_generic_init($openMode, $secretKey, $initVector) != -1) {
		$encryptedText = mcrypt_generic($openMode, $plainPad);
		mcrypt_generic_deinit($openMode);
	}
	return bin2hex($encryptedText);
}

//
function md5_decrypt($encryptedText, $key) {
		$secretKey = hextobin(md5($key));
		$initVector = pack("C*", 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f);
		$encryptedText = hextobin($encryptedText);
		$openMode = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', 'cbc', '');
		mcrypt_generic_init($openMode, $secretKey, $initVector);
		$decryptedText = mdecrypt_generic($openMode, $encryptedText);
		$decryptedText = rtrim($decryptedText, "\0");
		mcrypt_generic_deinit($openMode);
	return $decryptedText;
}

//
function pkcs5_pad($plainText, $blockSize){
	//*********** Padding Function *********************
	$pad = $blockSize - (strlen($plainText) % $blockSize);
	return $plainText . str_repeat(chr($pad), $pad);
}

//
function hextobin($hexString) {
	//********** Hexadecimal to Binary function for php 4.0 version ********
	$length = strlen($hexString);
	$binString = "";
	$count = 0;
	while ($count < $length) {
		$subString = substr($hexString, $count, 2);
		$packedString = pack("H*", $subString);
		if ($count == 0) {
			$binString = $packedString;
		} else {
			$binString .= $packedString;
		}

		$count += 2;
	}
	return $binString;
}

//
function log_encrypt($message, $password)
{
    if (OPENSSL_VERSION_NUMBER <= 268443727) {
        throw new RuntimeException('OpenSSL Version too old, vulnerability to Heartbleed');
    }

    $iv_size        = openssl_cipher_iv_length(AES_METHOD);
    $iv             = openssl_random_pseudo_bytes($iv_size);
    $ciphertext     = openssl_encrypt($message, AES_METHOD, $password, OPENSSL_RAW_DATA, $iv);
    $ciphertext_hex = bin2hex($ciphertext);
    $iv_hex         = bin2hex($iv);
    return "$iv_hex:$ciphertext_hex";
}

//
function log_decrypt($ciphered, $password) {
    $iv_size    = openssl_cipher_iv_length(AES_METHOD);
    $data       = explode(":", $ciphered);
    $iv         = hex2bin($data[0]);
    $ciphertext = hex2bin($data[1]);
    return openssl_decrypt($ciphertext, AES_METHOD, $password, OPENSSL_RAW_DATA, $iv);
}

//
function stream_open($url, $refer = 'http://www.google.com/', $host = 'google.com', $accept = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', $agent = USERAGENT, $https = false, $connection_alive = false ){
	
	$options = array(
		
		CURLOPT_CUSTOMREQUEST  =>"GET",        //set request type post or get
		CURLOPT_POST           =>false,        //set to GET
		
		CURLOPT_RETURNTRANSFER => true,     // return web page
		CURLOPT_HEADER         => false,    // don't return headers
		CURLOPT_FOLLOWLOCATION => true,     // follow redirects
		CURLOPT_ENCODING       => "",       // handle all encodings
		CURLOPT_AUTOREFERER    => true,     // set referer on redirect
		CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
		CURLOPT_TIMEOUT        => 120,      // timeout on response
		CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
	);
		
		$ch      = curl_init( $url );
		
		$cookie_string = "";
		$cookie_string .= "i18next=fr-FR; ";
		
		
		$headers = array();
		$headers[] = 'User-Agent: ' . $agent;
		$headers[] = 'Accept-Encoding: gzip, deflate';
		$headers[] = 'Accept-Language: fr-FR,fr;q=0.8,en-US;q=0.6,en;q=0.4';
		$headers[] = 'Host: ' . $host;
		$headers[] = 'Referer: '  . $refer;
		if ( $connection_alive == 1 )
		{
			$headers[] = 'Connection : keep-alive';
		}
		$headers[] = $accept;
	
		
		curl_setopt($ch, CURLOPT_URL, $url);  
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			if ( $https == 1 )
			{
				curl_setopt ($ch, CURLOPT_CAINFO, dirname(__FILE__)."/cacert.pem");
			}
			
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_ENCODING, '');
		curl_setopt($ch, CURLOPT_TIMEOUT, 55);
		curl_setopt($ch, CURLOPT_COOKIE, $cookie_string);
		
		curl_setopt_array( $ch, $options );
		$content = curl_exec( $ch );
		$err     = curl_errno( $ch );
		$errmsg  = curl_error( $ch );
		$header  = curl_getinfo( $ch );
		curl_close( $ch );
		
		$header['errno']   = $err;
		$header['errmsg']  = $errmsg;
		$header['content'] = $content;
	return $header['content'];
}

//
function request($url, $method, $data = null, array &$headers = []) {
	// https://stackoverflow.com/a/38206024
	/*
	* Performs memory-safe HTTP request.
	*
	* @param string $url       Request URL, e.g. "https://example.com:23986/api/upload".
	* @param string $method    Request method, e.g. "GET", "POST", "PATCH", etc.
	* @param mixed $data       [optional] Data to pass with the request.
	* @param array $headers    [optional] Additional headers.
	*
	* @return string           Response body.
	*
	* @throws Exception
	*/

	static $schemes = [
		'https' => ['', 80],
		'http'  => ['', 80],
	];
	
	$u = parse_url($url);
	if (!isset($u['host']) || !isset($u['scheme']) || !isset($schemes[$u['scheme']])) {
		throw new Exception('URL parameter must be a valid URL.');
	}
	
	$scheme = $schemes[$u['scheme']];
	if (isset($u['port'])) {
		$scheme[1] = $u['port'];
	}
	
	$fp = @fsockopen($scheme[0] . $u['host'], $scheme[1], $errno, $errstr);
	if ($fp === false) {
		throw new Exception($errstr, $errno);
	}
	
	$uri = isset($u['path']) ? $u['path'] : '/';
	if (isset($u['query'])) {
		$uri .= '?' . $u['query'];
	}
	
	if (is_array($data)) {
		$data = http_build_query($data);
		$headers['Content-Length'] = strlen($data);
	} elseif ($data instanceof SplFileInfo) {
		$headers['Content-Length'] = $data->getSize();
	}
	
	$headers['Connection'] = 'close';
	
	fwrite($fp, sprintf("%s %s HTTP/1.1\r\n", $method, $uri));
	foreach ($headers as $header => $value) {
		fwrite($fp, $header . ': ' . $value . "\r\n");
	}
	fwrite($fp, "\r\n");
	
	if ($data instanceof SplFileInfo) {
		$fh = fopen($data->getPathname(), 'rb');
		while ($chunk = fread($fh, 4096)) {
			fwrite($fp, $chunk);
		}
		fclose($fh);
	} else {
		fwrite($fp, $data);
	}
	
	$response = '';
	while (!feof($fp)) {
		$response .= fread($fp, 1024);
	}
	fclose($fp);
	
	if (false === $pos = strpos($response, "\r\n\r\n")) {
		throw new Exception('Bad server response body.');
	}
	
	$headers = explode("\r\n", substr($response, 0, $pos));
	if (!isset($headers[0]) || strpos($headers[0], 'HTTP/1.1 ')) {
		throw new Exception('Bad server response headers.');
	}
	
	return substr($response, $pos + 4);
}

//
function stream_send($url, $headers, $object_data){
	$rest = curl_init();

	$cookie_string = "__atuvc=1%7C40%2C1%7C41; ";
	$cookie_string .= "i18next=fr-FR; ";
	

	$headers = array();
	$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
	$headers[] = 'Accept-Encoding: gzip, deflate';
	$headers[] = 'Accept-Language: fr-FR,en;q=0.5';
	$headers[] = 'Cache-Control: no-cache';
	$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=utf-8';
	$headers[] = 'Connection : keep-alive';
	$headers[] = 'User-Agent: ' . user_aget();
	

	
	curl_setopt($rest, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($rest, CURLOPT_ENCODING, '');
	curl_setopt($rest, CURLOPT_COOKIE, $cookie_string);

	curl_setopt($rest, CURLOPT_URL, $url);
	curl_setopt($rest, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($rest, CURLOPT_POSTFIELDS, $object_data);
	curl_setopt($rest, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($rest, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($rest, CURLOPT_ENCODING, '');
	curl_setopt($rest, CURLOPT_COOKIE, $cookie_string);
	curl_setopt($rest, CURLOPT_FRESH_CONNECT, false);
	curl_setopt($rest, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($rest, CURLOPT_RETURNTRANSFER, true);

	$response = curl_exec($rest);

	curl_close($rest);
	
	return $response;
}

//
function user_aget() {
	
		$random = array(
			1 => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
			2 => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36',
			3 => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
			4 => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2226.0 Safari/537.36',
			5 => 'Mozilla/5.0 (Windows NT 6.4; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36',
			6 => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36',
			7 => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36',
			8 => 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36',
			9 => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.67 Safari/537.36',
			
			10 => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) ChromePlus/4.0.222.3 Chrome/4.0.222.3 Safari/532.2',
			11 => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.28.3 (KHTML, like Gecko) Version/3.2.3 ChromePlus/4.0.222.3 Chrome/4.0.222.3 Safari/525.28.3',
			
			12 => 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1',
			13 => 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0',
			
			14 => 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko',
			15 => 'Mozilla/5.0 (compatible, MSIE 11, Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko',
			16 => 'Mozilla/5.0 (compatible; MSIE 10.6; Windows NT 6.1; Trident/5.0; InfoPath.2; SLCC1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 2.0.50727) 3gpp-gba UNTRUSTED/1.0',
			
			17 => 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
			18 => 'Mozilla/5.0 (Linux; U; Android 4.0.3; de-ch; HTC Sensation Build/IML74K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
			19 => 'Mozilla/5.0 (Linux; U; Android 2.3.5; zh-cn; HTC_IncredibleS_S710e Build/GRJ90) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			20 => 'Mozilla/5.0 (Linux; U; Android 2.3.4; fr-fr; HTC Desire Build/GRJ22) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			21 => 'Mozilla/5.0 (Linux; U; Android 2.3.3; zh-tw; HTC_Pyramid Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari',
			22 => 'Mozilla/5.0 (Linux; U; Android 2.3.3; de-de; HTC Desire Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			23 => 'Mozilla/5.0 (Linux; U; Android 2.2.1; en-gb; HTC_DesireZ_A7272 Build/FRG83D) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			24 => 'Mozilla/5.0 (Linux; U; Android 2.2.1; en-ca; LG-P505R Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			25 => 'Mozilla/5.0 (Linux; U; Android 2.3.4; en-us; T-Mobile myTouch 3G Slide Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			26 => 'Mozilla/5.0 (Linux; U; Android 4.0.3; en-us; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
			27 => 'Mozilla/5.0 (Linux; U; Android 2.3.3; en-us; LG-LU3000 Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			
			28 => 'Mozilla/5.0 (compatible; MSIE 9.0; Windows Phone OS 7.5; Trident/5.0; IEMobile/9.0)',
			
			29 => 'Opera/12.02 (Android 4.1; Linux; Opera Mobi/ADR-1111101157; U; en-US) Presto/2.9.201 Version/12.02',
			30 => 'Opera/9.80 (S60; SymbOS; Opera Mobi/SYB-1107071606; U; en) Presto/2.8.149 Version/11.10',
			31 => 'Opera/9.80 (Android 2.3.3; Linux; Opera Mobi/ADR-1111101157; U; en-US) Presto/2.9.201 Version/11.50',
			
			// Repeating the chrome browser ! (favorite browser)
			32 => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
			33 => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36',
			34 => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
			
		);
	
		$selected = strtr(rand(1,sizeof($random)), $random);
	
	return $selected;
}

//
function may_update_versions() {
	
		$updatable_versions = array(
			// array("c"=>"Category", "f"=>true), App "Category", Whether the user should "Force" update the app in order to continue or not. 
			array("c"=>"Beta", "f"=>false),
			array("c"=>"Private", "f"=>false),
			array("c"=>"Educational", "f"=>true),
			array("c"=>"Hobby", "f"=>true),
			array("c"=>"Friends", "f"=>false),
			array("c"=>"Business", "f"=>true),
		);
	
	return $updatable_versions;
}

//
function sms_send_number() {
	
		$random = array(
			1 => '+9810009330000000',
			2 => '+9820009330000',			
		);
		
		$selected = strtr(rand(1,sizeof($random)), $random);
	
	return $selected;
}

//
function send_sms_with_pattern( $pattern_code, $fromNum, $toNum, $input_data = [] ){
	$sms_url = MOKHABERAT_SMS_URL;
	$sms_headers = array(
		"Content-Type: application/json",
	);
	$sms_data = array(
		'op' 	 	 	   => 'patternV2',
		'user' 	 	  	   => MOKHABERAT_SMS_USER,
		'pass' 	 	 	   => MOKHABERAT_SMS_PASS,
		'fromNum' 		   => $fromNum,
		'toNum' 	 	   => $toNum,
		'patternCode' 	   => $pattern_code,
		'inputData' 	   => $input_data,
	);

	$exec = sendBackendlessRequest( $sms_url, $sms_headers, json_encode($sms_data));
	
	if ( is_numeric($exec) )
	{
		return true;
	} else {
		return false;
	}
}

//
function send_sms_with_rayganSMS( $toNum, $message ){ //@TODO: Change this function for a better algorithm
	$sms_url = RAYGAN_SMS_URL . '?Username=' . RAYGAN_SMS_USER . '&Password=' . RAYGAN_SMS_PASS . '&Mobile=' . $toNum . '&Message=' . $message;
	$sms_headers = array(
		"Content-Type: text/html",
	);
	
	$exec = getBackendlessResponse( $sms_url, $sms_headers, '');
	
	if ( is_numeric($exec) )
	{
		return true;
	} else {
		return false;
	}
}

//
function array_column_recursive($input = NULL, $columnKey = NULL, $indexKey = NULL) {
	// https://gist.github.com/tripflex/2818993b85db39a1f89a
	// Using func_get_args() in order to check for proper number of
	// parameters and trigger errors exactly as the built-in array_column()
	// does in PHP 5.5.

	$argc = func_num_args();
	$params = func_get_args();
	if ($argc < 2)
	{
		trigger_error("array_column_recursive() expects at least 2 parameters, {$argc} given", E_USER_WARNING);
		return NULL;
	}

	if (!is_array($params[0]))
	{

		// Because we call back to this function, check if call was made by self to
		// prevent debug/error output for recursiveness :)

		$callers = debug_backtrace();
		if ($callers[1]['function'] != 'array_column_recursive')
		{
			trigger_error('array_column_recursive() expects parameter 1 to be array, ' . gettype($params[0]) . ' given', E_USER_WARNING);
		}

		return NULL;
	}

	if (!is_int($params[1]) && !is_float($params[1]) && !is_string($params[1]) && $params[1] !== NULL && !(is_object($params[1]) && method_exists($params[1], '__toString')))
	{
		trigger_error('array_column_recursive(): The column key should be either a string or an integer', E_USER_WARNING);
		return FALSE;
	}

	if (isset($params[2]) && !is_int($params[2]) && !is_float($params[2]) && !is_string($params[2]) && !(is_object($params[2]) && method_exists($params[2], '__toString')))
	{
		trigger_error('array_column_recursive(): The index key should be either a string or an integer', E_USER_WARNING);
		return FALSE;
	}

	$paramsInput = $params[0];
	$paramsColumnKey = ($params[1] !== NULL) ? (string)$params[1] : NULL;
	$paramsIndexKey = NULL;
	if (isset($params[2]))
	{
		if (is_float($params[2]) || is_int($params[2]))
		{
			$paramsIndexKey = (int)$params[2];
		}
		else
		{
			$paramsIndexKey = (string)$params[2];
		}
	}

	$resultArray = array();
	foreach($paramsInput as $row)
	{
		$key = $value = NULL;
		$keySet = $valueSet = FALSE;
		if ($paramsIndexKey !== NULL && array_key_exists($paramsIndexKey, $row))
		{
			$keySet = TRUE;
			$key = (string)$row[$paramsIndexKey];
		}

		if ($paramsColumnKey === NULL)
		{
			$valueSet = TRUE;
			$value = $row;
		}
		elseif (is_array($row) && array_key_exists($paramsColumnKey, $row))
		{
			$valueSet = TRUE;
			$value = $row[$paramsColumnKey];
		}

		$possibleValue = array_column_recursive($row, $paramsColumnKey, $paramsIndexKey);
		if ($possibleValue)
		{
			$resultArray = array_merge($possibleValue, $resultArray);
		}

		if ($valueSet)
		{
			if ($keySet)
			{
				$resultArray[$key] = $value;
			}
			else
			{
				$resultArray[] = $value;
			}
		}
	}

	return $resultArray;
}

//
function arabic_w2e($str) {
	$arabic_eastern = array('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', ':');
	$arabic_western = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':');
	return str_replace($arabic_western, $arabic_eastern, $str);
}

//
function arabic_e2w($str) {
	$arabic_eastern = array('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', ':');
	$arabic_western = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':');
	return str_replace($arabic_eastern, $arabic_western, $str);
}

//
function string_find_replace($string, $find, $replace = ''){
	$normalizeChars = array(
		$find => $replace
	);
	return strtr($string, $normalizeChars);
}

//
function array_find_replace($string, $find_replace){
	return strtr($string, $find_replace);
}

//
function remove_value_of_array($value, $array){

	if ( sizeof($array) > 1 )
	{
		if(($key = array_search($value, $array)) !== false) {
			unset($array[$key]);
		}

		return array_values($array);

	} else {

		return null;
	}
}

//
function image_remote_to_local($src, $type = 'L'){ // [L, M, S] for internal categorisation - images sizes
	// src="' . MEDIASERVERPREPARE . 'image.php?s=a&type=b&id=' . encrypt('http:' . $result['img']['src']) . '.jpg' . '"
	if ( strpos( $src, 'http' ) === false ) // the src does not start with [http|https]
	{
		$src = 'http' . $src;
	}
	$image_src = MEDIASERVER . 'getCover.php?s=D&type=' . $type . '&id=' . encrypt( $src ) . '.jpg';

	return $image_src;
}

//
function get_redirected_location( $url, $refer = 'http://www.google.com/', $host = 'google.com', $https = false ){

	$ch      = curl_init( $url );
	
	$cookie_string = "";
	$cookie_string .= "i18next=en-US; ";

	$headers = array();
	$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
	$headers[] = 'Accept-Encoding: gzip, deflate';
	$headers[] = 'Accept-Language: en-US;q=0.6,en;q=0.4 ';
	$headers[] = 'Host: ' . $host . '';
	$headers[] = 'Referer: '  . $refer . '';
	$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1';
		
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_HEADER, TRUE); // We'll parse redirect url from header.
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, FALSE); // We want to just get redirect url but not to follow it.
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		if ( $https == true )
		{
			curl_setopt ($ch, CURLOPT_CAINFO, dirname(__FILE__)."/cacert.pem");
		}
		
	curl_setopt($ch, CURLOPT_COOKIE, $cookie_string);
					
	$response = curl_exec($ch);
	preg_match_all('/^Location:(.*)$/mi', $response, $matches);
	curl_close($ch);
	return !empty($matches[1]) ? trim($matches[1][0]) : '';

}

//
function monthWord_to_number($type){
	$type_array = array(
		"فرروردین" => 1,
		"اردیبهشت" => 2,
		"خرداد" => 3,
		"تیر" => 4,
		"مرداد" => 5,
		"شهریور" => 6,
		"مهر" => 7,
		"آبان" => 8,
		"آذر" => 9,
		"دی" => 10,
		"بهمن" => 11,
		"اسفند" => 12,
	);

	return strtr($type, $type_array);
}

//
function avatar_generator($name, $size = '256', $rounded = 'false', $font_size = '0.37', $bold = 'false', $h_color = null){
	if ( !empty($h_color) )
	{
		$the_color['H'] = $h_color;
	} else {
		$the_color['H'] = rand(0,360);
	}
	$the_color['S'] = 50;
	$the_color['L'] = 50;

	$color_back = Colors::hslToHex($the_color);
	//$color_back = prepareLength(substr($color_back, 0, 6), 6, 0); // Because there is error in color class !
	$color_back = prepareLength(substr($color_back, strlen($color_back) - 6, rand(6, strlen($color_back))), 6, 0); // Random !
	$background = new Colors($color_back);

	if ( $background->isDark() == 1 )
	{
		$foreground = 'eee';
		
	} else
	{
		$foreground = '222';
	}

	$api = 'https://ui-avatars.com/api/?background=' . $color_back . '&color=' . $foreground . '&size=' . $size . '&bold=' . $bold . '&font-size=' . $font_size . '&rounded=' . $rounded . '&name=' . preg_replace("/ /", "+", $name);

	return $api;
}

//
function timeWord_to_number($type){
	$type_array = array(
		"ثانیه پیش" => 1,
		"دقیقه پیش" => 60,
		"ساعت پیش" => 3600,
		"روز پیش" => 86400,
		"هفته پیش" => 604800,
		"ماه پیش" => 2635200,
		"سال پیش" => 31622400,
	);

	return strtr($type, $type_array);
}

//
function copyright_icon_fixer($string){
	$normalizeChars = array(
		'(p)'=>'℗',
		'(P)'=>'℗',
		'(c)'=>'©',
		'(C)'=>'©',
		'(r)'=>'®',
		'(R)'=>'®',
	);
	return strtr($string, $normalizeChars);
}

//
function remove_duplicate_copyright($string){
	return preg_replace("/(\\b\\w{2,}\\b)(?=.*?\\1+)\W*/mu", "$2", copyright_icon_fixer($string));
}

//
function remove_external_links($string){
	return preg_replace("/<a(.*?)href=('|\")http(.*?)>(.*?)<\/a>/", "$4", $string);
}

//
function remove_non_utf8($string){
	// https://stackoverflow.com/a/1176923/4013321
	return preg_replace('/[\x00-\x1F\x7F\xA0]/u', '', $string);
}

//
function autoParagraph($pee, $br=1) {

    $pee = $pee . "\n"; // just to make things a little easier, pad the end
    $pee = preg_replace('|<br />\s*<br />|', "\n\n", $pee);
    $pee = preg_replace('!(<(?:table|ul|ol|li|pre|form|blockquote|h[1-6])[^>]*>)!', "\n$1", $pee); // Space things out a little
    $pee = preg_replace('!(</(?:table|ul|ol|li|pre|form|blockquote|h[1-6])>)!', "$1\n", $pee); // Space things out a little
    $pee = preg_replace("/(\r\n|\r)/", "\n", $pee); // cross-platform newlines
    $pee = preg_replace("/\n\n+/", "\n\n", $pee); // take care of duplicates
    $pee = preg_replace('/\n?(.+?)(?:\n\s*\n|\z)/s', "\t<p>$1</p>\n", $pee); // make paragraphs, including one at the end
    $pee = preg_replace('|<p>\s*?</p>|', '', $pee); // under certain strange conditions it could create a P of entirely whitespace
    $pee = preg_replace("|<p>(<li.+?)</p>|", "$1", $pee); // problem with nested lists
    $pee = preg_replace('|<p><blockquote([^>]*)>|i', "<blockquote$1><p>", $pee);
    $pee = str_replace('</blockquote></p>', '</p></blockquote>', $pee);
    $pee = preg_replace('!<p>\s*(</?(?:table|tr|td|th|div|ul|ol|li|pre|select|form|blockquote|p|h[1-6])[^>]*>)!', "$1", $pee);
    $pee = preg_replace('!(</?(?:table|tr|td|th|div|ul|ol|li|pre|select|form|blockquote|p|h[1-6])[^>]*>)\s*</p>!', "$1", $pee);
    if ($br) $pee = preg_replace('|(?<!<br />)\s*\n|', "<br />\n", $pee); // optionally make line breaks
    $pee = preg_replace('!(</?(?:table|tr|td|th|div|dl|dd|dt|ul|ol|li|pre|select|form|blockquote|p|h[1-6])[^>]*>)\s*<br />!', "$1", $pee);
    $pee = preg_replace('!<br />(\s*</?(?:p|li|div|th|pre|td|ul|ol)>)!', '$1', $pee);
    $pee = preg_replace('/&([^#])(?![a-z]{1,8};)/', '&#038;$1', $pee);

    return $pee;
}

//
function cleanSpace($string){
	return preg_replace('/\s+/', ' ', str_replace(array("\\n", "\\r"), '', $string));
}

//
function get_artist_image_id($uri){
	preg_match('/\/([^\/]*)?.(png|gif|bmp|tiff|tif|jpe?g)/', $uri, $output_array);
	return $output_array;
}

//
function array_to_string($array) {
	// Array to String error correction
	$result = '';
    if (is_string($array)) {
        $result = $array;
    } elseif (is_array($array)) {
        $result = array_to_string(current($array));
    }
    return $result;
}

//
function retry_again_yql($retry_number = 3, $url, $referer = 'http://www.google.com/', $host = 'google.com', $accept, $agent, $https = false ) { // NOTE: the yql_oauth second parameter must be TRUE

	$result = '';

	for ($i = 0; $i < $retry_number; $i++)
	{
		@$importIo = stream_open($url, $referer, $host, $accept, $agent, true);
		@$sanitized = json_decode($importIo, true);
		
		@$error_ckeck = $sanitized['diagnostics']['url'][0]; // We need to check at least the first response-table
		
		if ( !isset($error_ckeck['error']) && !empty($sanitized['query']['results']) ) // There is kind of error in response, so we need to repeat the request
		{
			$result = $sanitized;
			break;
		}
	}
	
return $result;
}

//
function simpleTitle($string, $length = 21, $cut_end = false) { // This function returns the original string unlike extractTitle()
	preg_match_all("/(.*)(،|؟|؛|,|^\d*\.?\d*$|;|:|\?|\/|!|$)(.*)/mU", $string, $string_array);
	array_multisort(array_map('strlen', $string_array[1]), $string_array[1]);
	
	$title = $string;
	$string_array[1] = isset($string_array[1][0]) ? $string_array[1] : array($string_array[1]); // Always array for foreach

	foreach ($string_array[1] as $possible_title) {
		if ( strlen($possible_title) < (strlen($string) - 1) ) // We don't return anything if the $title is the same as the $string. -1 [possible trimming of the . at the end of the sentence]
		{
			// برای, چون, در, مانند, مثل, مگر‎, اگر, زیرا, ولی, چون, اگرچه یعنی وی او
			$banned = array('\x{0627}\x{0648}', '\x{0648}\x{06cc}', '\x{06cc}\x{0639}\x{0646}\x{06cc}', '\x{0628}\x{0631}\x{0627}\x{06cc}', '\x{0686}\x{0648}\x{0646}', '\x{062f}\x{0631}', '\x{0645}\x{0627}\x{0646}\x{0646}\x{062f}', '\x{0645}\x{062b}\x{0644}', '\x{0645}\x{06af}\x{0631}\x{200e}', '\x{0627}\x{06af}\x{0631}', '\x{0632}\x{06cc}\x{0631}\x{0627}', '\x{0648}\x{0644}\x{06cc}', '\x{0686}\x{0648}\x{0646}', '\x{0627}\x{06af}\x{0631}\x{0686}\x{0647}'); // UTF-8 regex [http://stackoverflow.com/a/3538296]
			$pattern = '/^\b(?:' . join('|', $banned) . ')\b/miu';
			$possible_title = preg_replace($pattern, '', trim($possible_title));
			
			if ( $cut_end == 1 ) // We also cut the end VERBS
			{
				$banned = array('\x{0627}\x{0633}\x{062a}'); // UTF-8 regex [http://stackoverflow.com/a/3538296]
				$pattern = '/\b(?:' . join('|', $banned) . ')\b$/miu';
				$possible_title = preg_replace($pattern, '', trim($possible_title));
			}
			
			if ( strlen($possible_title) > $length ) // We don't count anything as title if less than 21 characters long
			{
				$title = $possible_title;
				break;
			}
		}
	}
	return $title;
}

//
function extractTitle($string, $length = 21, $cut_end = false) {
	preg_match_all("/(.*)(،|؟|؛|,|^\d*\.?\d*$|;|:|\?|\/|!|$)(.*)/mU", $string, $string_array);
	array_multisort(array_map('strlen', $string_array[1]), $string_array[1]);
	
	$title = '';
	$string_array[1] = isset($string_array[1][0]) ? $string_array[1] : array($string_array[1]); // Always array for foreach

	foreach ($string_array[1] as $possible_title) {
		if ( strlen($possible_title) < (strlen($string) - 1) ) // We don't return anything if the $title is the same as the $string. -1 [possible trimming of the . at the end of the sentence]
		{
			// برای, چون, در, مانند, مثل, مگر‎, اگر, زیرا, ولی, چون, اگرچه یعنی وی او
			$banned = array('\x{0627}\x{0648}', '\x{0648}\x{06cc}', '\x{06cc}\x{0639}\x{0646}\x{06cc}', '\x{0628}\x{0631}\x{0627}\x{06cc}', '\x{0686}\x{0648}\x{0646}', '\x{062f}\x{0631}', '\x{0645}\x{0627}\x{0646}\x{0646}\x{062f}', '\x{0645}\x{062b}\x{0644}', '\x{0645}\x{06af}\x{0631}\x{200e}', '\x{0627}\x{06af}\x{0631}', '\x{0632}\x{06cc}\x{0631}\x{0627}', '\x{0648}\x{0644}\x{06cc}', '\x{0686}\x{0648}\x{0646}', '\x{0627}\x{06af}\x{0631}\x{0686}\x{0647}'); // UTF-8 regex [http://stackoverflow.com/a/3538296]
			$pattern = '/^\b(?:' . join('|', $banned) . ')\b/miu';
			$possible_title = preg_replace($pattern, '', trim($possible_title));
			
			if ( $cut_end == 1 ) // We also cut the end VERBS
			{
				$banned = array('\x{0627}\x{0633}\x{062a}'); // UTF-8 regex [http://stackoverflow.com/a/3538296]
				$pattern = '/\b(?:' . join('|', $banned) . ')\b$/miu';
				$possible_title = preg_replace($pattern, '', trim($possible_title));
			}
			
			if ( strlen($possible_title) > $length ) // We don't count anything as title if less than 21 characters long
			{
				$title = $possible_title;
				break;
			}
		}
	}
	return $title;
}

//
function extract_text_from_html($html) {
	// https://github.com/ezyang/htmlpurifier/issues/56
	$config = HTMLPurifier_Config::create([]);
	
	$config->set('Core.Encoding', 'UTF-8');
	$config->set('HTML.AllowedElements', ['span', 'p', 'br', 'h1', 'h2', 'h3', 'h4', 'h5', 'strong', 'em', 'u', 'ul', 'li', 'ol', 'hr', 'blockquote', 'sub', 'sup', 'img']);
	$config->set('HTML.AllowedAttributes', '*.target,*.title,*.href,*.src,*.border,*.alt,*.width,*.height,*.title,*.name,*.id');
	$config->set('CSS.AllowedProperties', 'text-align,font-weight,text-decoration');
	$config->set('URI.AllowedSchemes', array(
	'http' => true,
	'https' => true,
	'mailto' => true,
	'ftp' => true,
	'nntp' => true,
	'news' => true,
	'data' => true));
	$config->set('AutoFormat.RemoveEmpty', true);
	$config->set('Attr.ForbiddenClasses', ['MsoNormal']);
	
	$purifier = new HTMLPurifier($config);

	return $purifier->purify($html);
}

//
function generate_booklet_link($booklet_id, $time) {
	return str_replace('=', '',strtr(base64_encode(md5($time . ' ' . '/' . BOOKLETS_LOCATION . '/' . $booklet_id . '.pdf' . ' ' . BOOKLETS_SECRET, TRUE)), '+/', '-_'));
}

//
function generate_fullaudio_link($audio_id, $audio_ext, $time) {
	return str_replace('=', '',strtr(base64_encode(md5($time . ' ' . '/' . DOWNLOAD_LOCATION . '/' . $audio_id . '.' . $audio_ext . ' ' . DOWNLOAD_SECRET, TRUE)), '+/', '-_'));
}

//
function uniqueAssocArray($array, $uniqueKey) {
	// https://codereview.stackexchange.com/a/29838
	
	if (!is_array($array)) {
		return array();
	}
	$uniqueKeys = array();
	foreach ($array as $key => $item) {
		$groupBy=$item[$uniqueKey];
		if (isset( $uniqueKeys[$groupBy]))
		{
			//compare $item with $uniqueKeys[$groupBy] and decide if you 
			//want to true;
			 $replace=false;
		}
		else
		{
			$replace=true;
		}
		if ($replace) $uniqueKeys[$groupBy] = $item;   
	}
	return $uniqueKeys;
}

//
function convert_timestamp( $number, $string ){
	$word_to_stamp = timeWord_to_number($string);
	$now = time();
	if ( !is_numeric($word_to_stamp) ) { // the code only uses the hour time [22:07]
		$timestamp = arabic_e2w($number);
		$timestamp = $timestamp . ':00';
		$timestamp = strtotime($timestamp);
		if ( $timestamp >= $now ) { // if we are 9:10 and the news time is 20:58 (yesterday , not today. Can't be in future !)
			$timestamp = $timestamp - 86400;
		}
	} else
	{
		$timestamp = $now - ( (int) arabic_e2w($number) * $word_to_stamp );
	}
	return $timestamp;
}

//
function counter_to_packages($counter, $user_id, $streaming = null){
    // general packages
	/*
	14-digit number 
		timestamp : 1506369011 --> 150636 + controlIfTimePackage[0,1] + package value + packageValueNormalPoints
		150636 + 1 + 003 + 0005 = 15063610030005
	*/
	$general_time_to_live = substr($counter, 0, 6);
	$if_timebased = substr($counter, 6, 1);
	$general_timebased_value = substr($counter, 7, 3);
	$general_normal_value = substr($counter, 10, 4);
	$general_time_to_live = $general_time_to_live . '0000'; // We make the cut time to timestamp again: 1506360000
	
	// Make them as integers
	$general_time_to_live = (int)$general_time_to_live;
	$if_timebased = (int)$if_timebased;
	$general_timebased_value = (int)$general_timebased_value;
	$general_normal_value = (int)$general_normal_value;
	$one_year = 60 * 60 * 24 * 365;

	if (!is_null($streaming)) {
        // streaming packages
        /*
        14-digit number
            timestamp : 1506369011 --> 150636 + activePlanType + timestamp : 1575425712 --> 157542 + futurePLanType
            150636 + 4 + 157542 + 2 = 15063641575422
        */
        $streaming_current_plan_time_to_live = substr($streaming, 0, 6);
        $streaming_current_plan_time_type = substr($streaming, 6, 1);
        $streaming_future_plan_time_to_live = substr($streaming, 7, 6);
        $streaming_future_plan_time_type = substr($streaming, 13, 1);
        $streaming_current_plan_time_to_live = $streaming_current_plan_time_to_live . '0000'; // We make the cut time to timestamp again: 1506360000
        $streaming_future_plan_time_to_live = $streaming_future_plan_time_to_live . '0000'; // We make the cut time to timestamp again: 1575420000

        // Make them as integers
        $streaming_current_plan_time_to_live = (int)$streaming_current_plan_time_to_live;
        $streaming_current_plan_time_type = (int)$streaming_current_plan_time_type;
        $streaming_future_plan_time_to_live = (int)$streaming_future_plan_time_to_live;
        $streaming_future_plan_time_type = (int)$streaming_future_plan_time_type;

    }

	$timebased = array( 'value' => $general_timebased_value , 'validity' => $general_time_to_live );
	$normal = array( 'value' => $general_normal_value , 'validity' => ($general_time_to_live + $one_year) );
	$subscription = array( 'value' => base64_encode(streaming_signature($user_id, streaming_level_to_hash($streaming_current_plan_time_type))) , 'validity' => $streaming_current_plan_time_to_live );
	
	$active_packages = array(
		'timebased'	   			  => ( ($general_timebased_value != 0 && $general_time_to_live > time()) ?  $timebased : json_decode('{}') ), // https://stackoverflow.com/a/25104542
		//'normal'			  	  => ( $general_normal_value != 0 && $general_time_to_live > time() ?  $normal : [] ),
		'normal'			  	  => ( $general_normal_value != 0 ?  $normal : json_decode('{}') ),
		'subscription'			  => ( ($streaming_current_plan_time_type != 0 && ($streaming_current_plan_time_to_live >= time() ) ) ?  $subscription : json_decode('{}') ),
	);
	
	return $active_packages;
}

//
function various_artists(){
	
	$data_artist_id = 573076;
	$data_artist = 'Various Composers';
	$link_artist_slug = 'various_composers';
	$data_artist_albums_count = 1000;
	
	$album_artist = array(
			"id"  	=> construct_the_id(QOBUZSERVICE . 'Artist', $data_artist_id),
			"name"  => hdryn_change_france($data_artist),
			"slug"  => $link_artist_slug,
			"albums_count"  => $data_artist_albums_count 
		);
	
	return $album_artist;
}

//
function geocode_coordinations($code){
	$zone = \Geo\Hex::getZoneByCode($code);
	return array(
		'latitude' =>  $zone['latitude'],
		'longitude' => $zone['longitude']
	);
}

//
function coordinations_geocode($latitude, $longitude, $level = 5){
	$coordinations = \Geo\Hex::getZoneByLocation($latitude, $longitude, $level);
	return $coordinations['code'];
}

//
function has_more_results($offset, $limit, $total) {
	if ( ($offset + $limit) < $total ) {
	    return true;
	} else
	{
	    return false;
	}
}

//
function has_copyright_sign($string) {
    if ( !empty($string) ){
        if (strpos($string, "©") === 0) {
            return $string;
        } else
        {
            if (strpos($string, "℗") === 0) {
                return '©' . $string;
            } else
            {
                return '© ' . $string;
            }
        }
    } else
    {
        return '© ' . APINAME;
    }

}

//
function get_cookie_login($url, $content = NULL, $port = true) {

	// Code from https://github.com/vjeux/phpFileDownload
	/* Open the socket */

	$url_parsed = parse_url($url);

	if ( $port == 1  )
	{
		if (!isset($url_parsed['port'])) {
			if ($url_parsed['scheme'] == 'http') {
				$url_parsed['port'] = 80;
			}
			else if ($url_parsed['scheme'] == 'https') {
				$url_parsed['port'] = 443;
			}
		}
	}

	if ( $port == 1  )
	{
		while (!($fd = fsockopen($url_parsed['host'], $url_parsed['port']))) {
			// Retry
		}
	} else {
		while (!($fd = fsockopen($url_parsed['host'], -1))) {
			// Retry
		}
	}


	/* Generate the Query */

	$query = '';
	if (isset($url_parsed['query'])) {
		$query = $url_parsed['query'];
	}

	if (isset($content)) {
		$method = 'POST';
	} else {
		$method = 'GET';
	}

	if (isset($query) && strlen($query) > 0) {
		$header  = $method." ".$url_parsed['path'].'?'.$query." HTTP/1.1\r\n";
	} else {
		$header  = $method." ".$url_parsed['path']." HTTP/1.1\r\n";
	}
	$header .= "Host: ".$url_parsed['host']."\r\n";
	$header .= "User-Agent: Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36\r\n";
	$header .= "Referer: ".$url_parsed['scheme'].'://'.$url_parsed['host'].$url_parsed['path']."\r\n";

	//$cookie = $this->dumpCookies();
	//if (isset($cookie)) {
	//	$header .= "Cookie: ".$cookie."\r\n";
	//}

	if (isset($content)) {
		$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
		$header .= "Content-Length: ".strlen($content)."\r\n";
	}

	$header .= "Connection: close\r\n\r\n";

	if (isset($content)) {
		$header .= $content;
	}

	fputs($fd, $header);

	/* Handle the results */

	$content = '';
	$header = '';
	$export = '';
	$is_content = false;

	while ($line = fgets($fd)) {
		if ($is_content) {
			$content .= $line;
		} else {
			$header .= $line;
		}
			
		$export .= $line;
			
		if (strlen($line) <= 2) {
			$is_content = true;
		}
	}

	//$this->handleCookies($header);
	fclose($fd);

	return $export;

}

//
function get_qobuz_cookie_login($url) {
	
	$login_headers = array(
		"Content-Type: application/x-www-form-urlencoded",
		"Host: www.qobuz.com",
		"User-Agent: Mozilla/5.0 (Windows NT 6.1; rv:60.0) Gecko/20100101 Firefox/60.0",
		"Accept: text/javascript, application/javascript, application/ecmascript, application/x-ecmascript, */*; q=0.01",
		"Accept-Language: en-US,en;q=0.9",
		"Referer: https://play.qobuz.com/login",
		//"X-Requested-With: XMLHttpRequest",
		"Connection: keep-alive",
		"Origin: https://play.qobuz.com",
		"Accept-Encoding: gzip, deflate",
		"Sec-Fetch-Site: same-site",
		"Sec-Fetch-Mode: cors",
		"X-App-Id: " . QOBUZAPPID,
	);
	
	return sendBackendlessRequest($url , $login_headers , 'username=' . QOBUZUSER . '&email=' . QOBUZEMAIL . '&password=' . md5(QOBUZPASSWORD) . '&extra=partner' . '&device_manufacturer_id=' . strtoupper(QOBUZDEVICEID));
}

//
function get_backendless_cookie_login($url) {
	
	$login_headers = array(
		"Content-Type: application/x-www-form-urlencoded",
		"Host: rapidpars.com",
		"User-Agent: Mozilla/5.0 (Windows NT 6.1; rv:60.0) Gecko/20100101 Firefox/60.0",
		"Accept: text/javascript, application/javascript, application/ecmascript, application/x-ecmascript, */*; q=0.01",
		"Accept-Language: en-US,en;q=0.5",
		"Referer: https://rapidpars.com/",
		"X-Requested-With: XMLHttpRequest",
		"Connection: keep-alive",
	);

	return sendBackendlessRequest($url , $login_headers , 'user_name=' . RAPIDUSER . '&password=' . RAPIDPASS . '&remember=1');
}

//
function generate_hmac_signature($string, $key){
	$md5Fn = function($message) { return md5($message, true); };
	return bin2hex(hmac($string, $key, $md5Fn, 64));
}

//
function verify_hmac_signature($string, $key, $signature){
	$md5Fn = function($message) { return md5($message, true); };
	return hash_equals(bin2hex(hmac($string, $key, $md5Fn, 64)), $signature);
}

//
function hmac($message, $key, callable $hashFn, $hashBlockSizeInBytes){
	if (strlen($key) > $hashBlockSizeInBytes)
	{
		$key = $hashFn($key);
	}
	if (strlen($key) < $hashBlockSizeInBytes)
	{
		$key = $key . str_repeat(chr(0x00), $hashBlockSizeInBytes - strlen($key));
	}
	$outerKeyPad = str_repeat(chr(0x5c), $hashBlockSizeInBytes);
	$innerKeyPad = str_repeat(chr(0x36), $hashBlockSizeInBytes);
	return $hashFn(($outerKeyPad ^ $key) . $hashFn(($innerKeyPad ^ $key) . $message));
}

//
function temp_browser($service, $node, $build, $number = '20', $temp = 'temp'){ // $service == externalService (11, Farsnews) - $node == internalService (name of the services as column in database)
	// In this version, we have omitted the $node [category (?!)] ,  JUST to MAKE Life EASIER !!
	
	$result = '';

	$directory =  $_SERVER['DOCUMENT_ROOT'] . '/' . URLVERSION . '/' . $temp . '/';
	
	if ( $service == '01' ) // global_sources_to_id [Cumulative Service]
	{
		foreach((array)glob($directory . 'temp' . '_' . '*' . '_' . '*' . '_' . $build . '_' . '*') as $file)
		{
			if ( filesize($file) > 500 )
			{
				$fh = fopen($file,'r');
				while ($lines = fgets($fh)) {
					$lines_json = json_decode($lines, true);
					foreach ((array) $lines_json['response']['data']['news'] as $news) {
						if ( !empty($news) || !is_null($news) )
						{
							$result .= json_encode($news) . ',';
						}
					}
				}
				fclose($fh);
			}
		}
	} else {
		foreach((array)glob($directory . 'temp' . '_' . $service . '_' . '*' . '_' . $build . '_' . '*') as $file)
		{
			if ( filesize($file) > 500 )
			{
				$fh = fopen($file,'r');
				while ($lines = fgets($fh)) {
					$lines_json = json_decode($lines, true);
					foreach ((array) $lines_json['response']['data']['news'] as $news) {
						if ( !empty($news) || !is_null($news) )
						{
							$result .= json_encode($news) . ',';
						}
					}
				}
				fclose($fh);
			}
		}
	}

	return $result;
}

//
function scale_normalize_number($value, $min, $max) {
	$normalized = ($value - $min) / ($max - $min);
	return $normalized;
}

//	
function yql_oauth($query_string, $debug = false) {
	$base_api = 'http://query.yahooapis.com/v1';

	$min=1;
	$max=6; // should be updated if we have more keys!
	$random_selection = rand($min,$max);
	$yql_account_array = yqlAccounts($random_selection);		
	$yql_account_json = json_decode($yql_account_array);
	$key = $yql_account_json[0];
	$secret = $yql_account_json[1];

	if ( $debug == 1 )
	{
		$query = '/yql?diagnostics=true&format=json';
	} else {
		$query = '/yql?format=json';
	}
	
	//$query_search = urlencode(preg_replace("/([A-Z]+)/", " $1", $query_string)); // Got error in cloudflareHelper.php encryption
	$query_search = urlencode($query_string);
	
	$hmac_method = new OAuthSignatureMethod_HMAC_SHA1();
	$action = "sign_and_execute_request";
	$sig_method = $hmac_method;
	$consumer = new OAuthConsumer($key, $secret, NULL);

	$endpoint = $base_api . $query . "&q=" . $query_search;	
	$parsed = parse_url($endpoint);
	$params = array();
	parse_str($parsed['query'], $params);
	$req_req = OAuthRequest::from_consumer_and_token($consumer, NULL, "GET", $endpoint, $params);
	$req_req->sign_request($sig_method, $consumer, NULL);

	return $req_req;

}

//
function yqlAccounts($users){ //Aa12345679 or //Aa@12345679 // Client ID (Consumer Key) : Client Secret (Consumer Secret)
	$users_array = array(
		1 => '["dj0yJmk9ZTBPb2l6cGd0RzFaJmQ9WVdrOVVIRkdVa015TjJzbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD03ZQ--", "c91166129cdf1395254291b088be47cd572b2f3e"]', //filmsdotly@yahoo.com
		2 => '["dj0yJmk9T25GV1k2M3lZYWNhJmQ9WVdrOU9VbGhiMEZ2Tkc4bWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD0xMQ--", "a90da0602b112a95232b4d571d7d78195d5b2cb7"]', //filmsdotly2@yahoo.com
		3 => '["dj0yJmk9R1Q5cDlZY25XWTRNJmQ9WVdrOWNtWmliSFJrTm0wbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD04MA--", "fbb5377ca94fa7cb698781e458a50fb08d8a733c"]', //filmsdotly3@yahoo.com
		4 => '["dj0yJmk9QUNZUnFYdTZkSTEzJmQ9WVdrOU5WVlBOV0Z4TldjbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD0zNQ--", "500fc448d8c83cf45cc2fc47a066fedc422a6937"]', //filmsdotly4@yahoo.com
		5 => '["dj0yJmk9Q1JrdjZIeXIxcmNXJmQ9WVdrOVlYTjRkWEV4TjJjbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD1jZA--", "50bd6a4c972b2f5630569b52e0e113deae8edb9e"]', //filmsdotly5@yahoo.com
		6 => '["dj0yJmk9VDVwTkZnU0tsWE1wJmQ9WVdrOVpWcHlPREp5TldrbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD04MA--", "81b7067735ec53b3ce1258e7301bc1e1f1318bf0"]', //filmsdotly6@yahoo.com
		// in case of new key : yql_oauth should be updated !

	);
	
	return strtr($users, $users_array);
}

//
function LastFmApi($users){ //Aa@12345679
	$users_array = array(
		1 => '["2f1b6f28a6daf6e1c297242390107103", "c4557ec638aec1176a7b32dc234d384b"]', // yekdigi@haydoo.com
		2 => '["23f6079db0bb8e4d3ed83fe08e345dd9", "6122884e520489ac9b0d7c0580e81fed"]', // dodigi@ucylu.com
		3 => '["3880bff33f6b171e60ed14dd3b38cc86", "5111d05f1a28b380997549498118d380"]', // sedigi@lucyu.com

	);
	
	return strtr($users, $users_array);
}

//
function graphql_query(string $endpoint, string $query, string $admin = null, array $variables = [], string $token = null): array {
	$headers = ['Content-Type: application/json', 'User-Agent: ' . user_aget()];
	if (null !== $token) {
		$headers[] = "Authorization: bearer $token";
	}
	if (null !== $admin) {
		$headers[] = "X-Hasura-Admin-Secret: " . $admin;
	}
	
	if (false === $data = @file_get_contents($endpoint, false, stream_context_create([
		'http' => [
			'method' => 'POST',
			'header' => $headers,
			'content' => (!empty($variables) ? json_encode(['query' => $query, 'variables' => $variables]) : json_encode(['query' => $query])),

		]
	]))) {
		$error = error_get_last();
		throw new \ErrorException($error['message'], $error['type']);
	}
	
	return json_decode($data, true);
}

//
function FullLengthTrack($track_id, $format_id = 5, $app_id, $app_secret, $user_token) {
	
	$object          = 'track';
	$method          = 'getFileUrl';
	$parameters      = array('track_id' => $track_id, 'format_id' => $format_id, 'intent' => 'import');
	$request_ts      = time();
	$request_sig     = hash('md5', $object.$method.explodeForSignature($parameters).$request_ts.$app_secret);
	
	$url = sprintf('https://www.qobuz.com/api.json/0.2/%s/%s?%s', $object, $method, http_build_query(array_merge( 
	array(
		'request_ts'     			=> $request_ts,
		'request_sig'    			=> $request_sig,
		'app_id'          	 		=> $app_id,
		"user_auth_token"			=> $user_token,
		'intent'    				=> 'import',
	)
	, $parameters)));

	$headers = array(
		"X-App-Id: " . $app_id,
		"X-User-Auth-Token: " . $user_token,
	);
	
	$json = stream_send($url, $headers, '');
	
	return $json;
}

//
function upload_media_to_rapidpars( $sc, $sid, $uid, $media_link, $media_id, $media_ext = '.mp3' ) {
	$fetch_url = 'https://rapidpars.com/api/?timestamp=' . round(microtime(true) * 1000) . '&cmd=convertlinks';
	$fetch_data = array(
				'link0'	   => $media_link,
				'uid'	   => $uid,
				'sid'	   => $sid,
				'sc'	   => $sc
			);
	$fetch_query = http_build_query($fetch_data);

	$fetch_media = remote_rapidpars_media_file($fetch_url, $fetch_query, $sc, $sid, $uid);
	$fetch_media_array = json_decode($fetch_media, true);


	if ( isset($fetch_media_array['rlink']) )
	{
		preg_match("/(.*)rapidpars.com\/(.*)\/(.*)\/(.*)\/(.*)$/U", $fetch_media_array['rlink'][0], $link_array);
		$file_id = $link_array[3];
		$last_name = $link_array[5];
		
	} elseif ( isset($fetch_media_array['nlink']) )
	{
		preg_match("/(.*)rapidpars.com\/(.*)\/(.*)\/(.*)\/(.*)$/U", $fetch_media_array['nlink'][0], $link_array);
		$file_id = $link_array[3];
		$last_name = $link_array[5];
		
	} elseif ( isset($fetch_media_array['clink']) )
	{
		preg_match("/(.*)rapidpars.com\/(.*)\/(.*)\/(.*)\/(.*)$/U", $fetch_media_array['clink'][0], $link_array);
		$file_id = $link_array[3];
		$last_name = $link_array[5];	
	}
	
	$rename_url = 'https://rapidpars.com/api/?timestamp=' . round(microtime(true) * 1000) . '&cmd=rename&target=' . $file_id . '&name=' . $media_id . $media_ext . '&last_name=' . $last_name;
	$rename_data = array(
					'uid'	   => $uid,
					'sid'	   => $sid,
					'sc'	   => $sc
					);
	$rename_query = http_build_query($rename_data);
	
	$rename_media = remote_rapidpars_media_file($rename_url, $rename_query, $sc, $sid, $uid);
	$rename_media_array = json_decode($rename_media, true);
	
	if ( !empty(@$rename_media_array['url']) )
	{
		$downloadable_url = $rename_media_array['url'];
		
	} elseif (!empty(@$fetch_media_array['url'])) 
	{
		$downloadable_url = $rename_media_array['url'];
		
	} else {
		
		$downloadable_url = ''; 
	}
	
	if ( !empty($downloadable_url) )
	{
		return download_url_corrector($downloadable_url);
	}
}

//
function remote_rapidpars_media_file($url, $data, $sc, $sid, $uid) {
	$operation_headers = array(
		"Content-Type: application/x-www-form-urlencoded",
		"Host: rapidpars.com",
		"User-Agent: Mozilla/5.0 (Windows NT 6.1; rv:60.0) Gecko/20100101 Firefox/60.0",
		"Accept: text/javascript, application/javascript, application/ecmascript, application/x-ecmascript, */*; q=0.01",
		"Accept-Language: en-US,en;q=0.5",
		"Referer: https://rapidpars.com/",
		"X-Requested-With: XMLHttpRequest",
		"Connection: keep-alive",
		"Cookie: captcha=1; sc=" . $sc . "; sid=" . $sid . "; uid=" . $uid,
	);
	
	$operation_url = $url;
	$operation_data = $data;
	
	return sendBackendlessRequest($operation_url , $operation_headers , $operation_data);
}

//
function transfere_media_file($url, $data, $sc, $sid, $uid){
	
	$ch = curl_init( $url );
	//curl_setopt( $ch, CURLOPT_POST, 1);
	curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt( $ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt( $ch, CURLOPT_TIMEOUT_MS, 46706);
	curl_setopt( $ch, CURLOPT_HEADER, 0);
	curl_setopt( $ch, CURLOPT_FRESH_CONNECT, false);
	curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true);
	//curl_setopt( $ch, CURLOPT_ENCODING,'gzip');
	curl_setopt ($ch, CURLOPT_CAINFO, dirname(__FILE__)."/cacert.pem");
	
	
	$headers = array();
	$headers[] = 'Accept: text/javascript, application/javascript, application/ecmascript, application/x-ecmascript, */*; q=0.01';
	//$headers[] = 'Accept-Encoding: gzip, deflate';
	$headers[] = 'Accept-Language: en-US,en;q=0.5';
	$headers[] = 'X-Requested-With: XMLHttpRequest';
	$headers[] = 'Content-Type: application/x-www-form-urlencoded';
	$headers[] = 'Referer: https://rapidpars.com/';
	$headers[] = 'Host: rapidpars.com';
	$headers[] = 'Connection : keep-alive';
	$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; rv:60.0) Gecko/20100101 Firefox/60.0';
	$headers[] = 'Cookie: ' . 'captcha=1; sc=' . $sc . '; sid=' . $sid . '; uid=' . $uid;

	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_COOKIE, 'captcha=1; sc=' . $sc . '; sid=' . $sid . '; uid=' . $uid);
	
/*
	$fp = fopen(dirname(__FILE__).'/errorlog.txt', 'w');
	curl_setopt($ch, CURLOPT_VERBOSE, 1);
	curl_setopt($ch, CURLOPT_STDERR, $fp);
	rewind($fp);
	$verboseLog = stream_get_contents($fp);
	echo "Verbose information:\n<pre>", htmlspecialchars($verboseLog), "</pre>\n";
*/

	$response = curl_exec( $ch );
	return $response;
}

//
function download_url_corrector($url, $subdomain = 'navamedia'){
	preg_match("/htt(.+):\/\/(.*?)\.(.*)/", $url, $url_array);
	return 'htt' . $url_array[1] . '://' . $subdomain . '.' . $url_array[3];

}	

//
function streaming_signature($user_id, $subscription_level){
    $secret = AUDIO_STREAMING_SECRET;
    $expire = AUDIO_STREAMING_EXPIRATION;
    $algorithm = 'sha512';
    $timestamp = time();
    $signature_pattern = "{$user_id}{$subscription_level}{$timestamp}{$expire}{$secret}";
    $hash = base64_encode(hash_hmac($algorithm, $signature_pattern, $secret, true));
    $hash = strtr($hash, '+/', '-_');
    $hash = str_replace('=', '', $hash);

    return "?id={$user_id}&level={$subscription_level}&st={$hash}&ts={$timestamp}&e={$expire}";
}

//
function checkRemoteFileExists($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_NOBODY, 1);
	curl_setopt($ch, CURLOPT_FAILONERROR, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	
	if(curl_exec($ch) !== false)
	{
		return true;
	}
	else
	{
		return false;
	}
}

//
function make_slug($string){
	if (extension_loaded('intl')) {
		$generator = new SlugGenerator;	
		return $generator->generate($string);
	} else 
	{
		return (string) new Slug(ic_normalize($string));
	}
}

//
function getVal($data,$chain){
	// https://stackoverflow.com/a/45889023
	// getVal($data,array('foo','bar','2017-08')) will return the equivalent of $data['foo']['bar']['2017-08']
    $level = $data;
    for($i=0, $iMax = count($chain); $i< $iMax; $i++){
        if(isset($level[$chain[$i]]))
            $level = $level[$chain[$i]];
        else
            return null; // key does not exist, return null
    }
    return $level;
}

//
function setVal(&$data,$chain,$value){
	// https://stackoverflow.com/a/45889023
	// setVal($data,array('foo','bar','2017-08'),'hello') will set value as if you called $data['foo']['bar']['2017-08'] = 'hello'
    $level = &$data;
    for($i=0, $iMax = count($chain); $i< $iMax; $i++){
        $level = &$level[$chain[$i]]; // set reference (&) in order to change the value of the object
    }
    $level = $value;
}

//
function do_in_background($command){
	// https://stackoverflow.com/a/25093948
	if (substr(php_uname(), 0, 7) == "Windows"){
		// windows
		pclose(popen("start /B " . $command . " 1> temp/update_log 2>&1 &", "r"));
	}
	else {
		// linux
		exec('nohup ' . $command . ' >> /dev/null 2>&1 &');
	}
}

//
function package_to_price($package) {
	
	$packages_array = array(
		// Normal Packages
		'DN_Track_1'		=>		2000,   // 2000
		'DN_Tracks_5'		=>		9900,	// 1980
		'DN_Tracks_10'		=>		19500,	// 1950
		'DN_Tracks_20'		=>		38500,	// 1925
		'DN_Tracks_50'		=>		94500,	// 1890
		'DN_Tracks_100'		=>		179000,	// 1790
		
		// Timebased Packages
		'DN_Time_1_1'		=>		1900,	// 1900 in 1 day
		'DN_Time_10_2'		=>		14900,	// 1490 in 2 days
		'DN_Time_20_7'		=>		29800,	// 1490 in 7 days
		
		
	);
		
	return strtr($package, $packages_array);
}

//
function package_to_value($package) {
	
	$packages_array = array(
		// Normal Packages
		'DN_Track_1'		=>		'[1, null]', // ["package_worth", "expiration_time"]
		'DN_Tracks_5'		=>		'[5, null]',
		'DN_Tracks_10'		=>		'[10, null]',
		'DN_Tracks_20'		=>		'[20, null]',
		'DN_Tracks_50'		=>		'[50, null]',
		'DN_Tracks_100'		=>		'[100, null]',
		
		// Timebased Packages
		'DN_Time_1_1'		=>		'[1, 86400]', // Expires after one day
		'DN_Time_10_2'		=>		'[10, 172800]', // Expires after two days
		'DN_Time_20_7'		=>		'[20, 604800]', // Expires after one week
		
		
	);
		
	return strtr($package, $packages_array);
}

//
function promotion_to_value($promotion) {
	
	$promotions_array = array(
		// Normal Promotions
		'DN_Promo_1'		=>		'[1, null]', // ["package_worth", "expiration_time"]
		'DN_Promo_5'		=>		'[5, null]',
		'DN_Promo_10'		=>		'[10, null]',
		'DN_Promo_20'		=>		'[20, null]',
		'DN_Promo_50'		=>		'[50, null]',
		'DN_Promo_100'		=>		'[100, null]',
		
		// Timebased Promotions
		'DN_Promo_1_1'		=>		'[1, 86400]', // Expires after one day
		'DN_Promo_1_10'		=>		'[1, 864000]', // Expires after ten day
		'DN_Promo_3_7'		=>		'[3, 604800]', // Expires after seven days
		'DN_Promo_10_2'		=>		'[10, 172800]', // Expires after two days
		'DN_Promo_20_7'		=>		'[20, 604800]', // Expires after one week
		'DN_Promo_25_31'	=>		'[25, 2678400]', // Expires after one month

		
	);
		
	return strtr($promotion, $promotions_array);
}

//
function streaming_to_price($streaming) {
    
    $streaming_array = array(
        'DN_Subscription_1_1'       =>		1500,
        'DN_Subscription_2_1'       =>		2200,
        'DN_Subscription_1_3'       =>		4500,
        'DN_Subscription_2_3'       =>		6600,
        'DN_Subscription_1_30'		=>		40000, // 45000
        'DN_Subscription_2_30'		=>		60000, // 66000
        'DN_Subscription_1_90'		=>		120000, // 135000
        'DN_Subscription_2_90'		=>		180000, // 198000
        'DN_Subscription_1_180'		=>		240000, // 270000
        'DN_Subscription_2_180'		=>		350000, // 396000
        'DN_Subscription_1_365'		=>		470000, // 547500
        'DN_Subscription_2_365'		=>		698000, // 803000

    );

    return strtr($streaming, $streaming_array);
}

//
function streaming_to_value($streaming) {

	$streaming_array = array( // ["streaming_level", "expiration_time"]
		'DN_Subscription_1_1'       =>		'[1, 86400]', // Expires after one day
		'DN_Subscription_2_1'       =>		'[2, 86400]', // Expires after one day
		'DN_Subscription_1_3'       =>		'[1, 259200]', // Expires after three days
		'DN_Subscription_2_3'       =>		'[2, 259200]', // Expires after three days
		'DN_Subscription_1_30'		=>		'[1, 2592000]', // Expires after 30 days
		'DN_Subscription_2_30'		=>		'[2, 2592000]', // Expires after 30 days
		'DN_Subscription_1_90'		=>		'[1, 7776000]',
		'DN_Subscription_2_90'		=>		'[2, 7776000]',
		'DN_Subscription_1_180'		=>		'[1, 15552000]',
		'DN_Subscription_2_180'		=>		'[2, 15552000]',
		'DN_Subscription_1_365'		=>		'[1, 31536000]',
		'DN_Subscription_2_365'		=>		'[2, 31536000]',

	);

	return strtr($streaming, $streaming_array);
}

//
function streaming_level_to_hash($level) {

	$level_array = array(
		1       =>		'06710ab6bf75b184a45429e3734a37d0',
		2       =>		'e5483cd0330638b28ce338b1c3ba938f',

		// Only users with 9th level can request for an Audio
		9       =>		'39cca5b41841cee5d199ff33ed377cd6',

	);

	return strtr($level, $level_array);
}

//
function streaming_hash_to_level($hash) {

	$hash_array = array(
        '06710ab6bf75b184a45429e3734a37d0'       =>		1,
        'e5483cd0330638b28ce338b1c3ba938f'       =>		2,

		// Only users with 9th level can request for an Audio
        '39cca5b41841cee5d199ff33ed377cd6'       =>		9,

	);

	return strtr($hash, $hash_array);
}

//
function streaming_level_privilege($level) {

    $level_array = array(
//        '8',

        // Only users with 9th level can request for an Audio
        '9'

    );

    if ( in_array($level, $level_array) )
    {
        return true;
    }

    return false;
}

//
function ksort_recursive(&$array) {
	// https://stackoverflow.com/a/15669150
    ksort($array);
    foreach ( $array as &$a ) {
        is_array($a) && ksort_recursive($a);
    }
}

//
function post_to_zibal($path, $parameters) {
	$url = 'https://gateway.zibal.ir/v1/'.$path;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($parameters));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	$response  = curl_exec($ch);
	curl_close($ch);
	
	return json_decode($response);
}

//
function post_to_sep($url, $parameters, $content_type = array('Content-Type: application/x-www-form-urlencoded')) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $content_type);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $parameters);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	$response  = curl_exec($ch);
	curl_close($ch);
	
	return $response;
}

//
function random_gateway_selector() {
	
	$gateway_array = array(
		1		=>		'Z', // Zibal
		2		=>		'S', // Sep

	);
	$gateway = mt_rand(1, sizeof($gateway_array));
		
	return strtr($gateway, $gateway_array);
}

//
function explodeForSignature($parameters) {
	ksort($parameters);
	$ret = '';
	foreach ($parameters as $key => $value) {
		if (is_array($value)) {
			asort($value);
			$ret .= $key.implode('', array_values($value));
		} else {
			$ret .= $key.$value;
		}
	}
	return $ret;
}

//
function status_code($status = 200, $message = ''){
	if ( $status == '200' )
	{
		http_response_code(200);
		header("Status: 200 OK");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"ok","code":200,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the api works perfectly.')) . ',"data":{}}}';
	} elseif ( $status == '201' )
	{
		http_response_code(201);
		header("Status: 201 Created");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"created","code":201,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the request has been fulfilled successfully.')) . ',"data":{}}}';
	} elseif ( $status == '202' )
	{
		http_response_code(202);
		header("Status: 202 Accepted");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"accepted","code":202,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the request has been accepted.')) . ',"data":{}}}';
	} elseif ( $status == '400' )
	{
		http_response_code(400);
		header("Status: 400 Bad Request");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"bad request","code":400,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('there was a problem with your request.')) . ',"data":{}}}';
	} elseif ( $status == '401' )
	{
		http_response_code(401);
		header("Status: 401 Unauthorized");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"unauthorized","code":401,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('access is denied due to invalid credentials.')) . ',"data":{}}}';
	} elseif ( $status == '402' )
	{
		http_response_code(402);
		header("Status: 402 Request Failed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"request failed","code":402,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('parameters were valid but request failed.')) . ',"data":{}}}';
	} elseif ( $status == '403' )
	{
		http_response_code(403);
		header("Status: 403 Forbidden");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"forbidden","code":403,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('no permission to access the resource.')) . ',"data":{}}}';
	} elseif ( $status == '404' )
	{
		http_response_code(404);
		header("Status: 404 Not Found");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"not found","code":404,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('no result is matched for given arguments.')) . ',"data":{}}}';
	} elseif ( $status == '412' )
	{
		http_response_code(412);
		header("Status: 412 Precondition Failed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"precondition failed","code":412,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server does not meet one of the preconditions.')) . ',"data":{}}}';
	} elseif ( $status == '417' )
	{
		http_response_code(417);
		header("Status: 417 Expectation Failed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"expectation failed","code":417,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server cannot meet the requirements.')) . ',"data":{}}}';
	} elseif ( $status == '422' )
	{
		http_response_code(422);
		header("Status: 422 Unprocessable Entity");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"unprocessable entity","code":422,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the request was well-formed but was unable to be followed')) . ',"data":{}}}';
	} elseif ( $status == '424' )
	{
		http_response_code(424);
		header("Status: 424 Failed Dependency");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"failed dependency","code":424,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the requested action depends on another action that is failed.')) . ',"data":{}}}';
	} elseif ( $status == '428' )
	{
		http_response_code(428);
		header("Status: 428 Precondition Required");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"precondition required","code":428,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server requires preconditions.')) . ',"data":{}}}';
	}
}

?>