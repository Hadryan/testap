<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';


//
function get_user_status( $app_id, $user_token, $session_id ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		$current_time = time();
		
		if ( $user_objectId == $provided_user_id )
		{
			$related_property = 'user_favorites'; // URL-encoded comma-separated values
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY_PER_USER . '/data/Users/' . $user_objectId . '?loadRelations=' . $related_property;
			$database_headers = array(
				"Content-Type: application/json",
				"user-token: " . $session_id_decrypted,
			);
			
			try {
				@$database_results = getBackendlessResponse( $database_url, $database_headers, '' );
				@$database_results_array = json_decode($database_results, true);
				
			} catch (Exception $ex){
				sendError( 'getUserStatus', 'error', (string)$ex->getCode(), $ex->getMessage(), 'object_id: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}
		
			if ( !empty($database_results_array) )
			{
				if ( empty($database_results_array['code']) )
				{
					if ( $database_results_array['user_is_active'] == 1  )
					{
						$user_favorites_array = $database_results_array['user_favorites'];
						
						if ( !empty($user_favorites_array) )
						{
							$user_favorites_array = isset($user_favorites_array[0]) ? $user_favorites_array : array($user_favorites_array);
							
							foreach($user_favorites_array as $num => $data) {
								
								if ( available_services($data['service_id']) == QOBUZSERVICE )
								{
									preg_match("/(.*)_(.*)/", $data['favorite_id'], $favorite_id_array);
									
									@$favorite_image = array(
											"50"   => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 50 . ':' . $data['image_id']) . '.jpg',
											"230"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 230 . ':' . $data['image_id']) . '.jpg',
											"600"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 600 . ':' . $data['image_id']) . '.jpg',
										);
									
									$_favorite_type = $data['favorite_type'];
									if ( $_favorite_type == 'albums' )
									{
										$favorite_id = construct_the_id(QOBUZSERVICE . 'Album', $favorite_id_array[2]);
										
									} elseif ( $_favorite_type == 'tracks' )
									{
										$favorite_id = construct_the_id(QOBUZSERVICE . 'Track', $favorite_id_array[2]);
										
									} elseif ( $_favorite_type == 'artists' )
									{
										$favorite_id = construct_the_id(QOBUZSERVICE . 'Artist', $favorite_id_array[2]);
										
									} elseif ( $_favorite_type == 'labels' )
									{
										$favorite_id = construct_the_id(QOBUZSERVICE . 'Label', $favorite_id_array[2]);
										
									}
									
									$favorite_items[] = array(						
										'favorite_id'		  => $favorite_id,
										'favorite_type'		  => $data['favorite_type'],
										'favorite_name'		  => $data['favorite_name'],
										'favorite_more'		  => $data['favorite_more'],
										'favorite_image'	  => $favorite_image,
										'object_id'			  => encrypt($data['objectId']),
										'created'			  => round($data['created'] / 1000),
									);
									
								} // else : other services
							}
						}

						$user = array(
							'user_login'			  => $database_results_array['user_login'],
							'user_lastseen'			  => floor($database_results_array['lastLogin'] / 1000),
							'user_firstname'		  => $database_results_array['user_firstname'],
							'user_lastname'			  => $database_results_array['user_lastname'],
							'user_email'			  => $database_results_array['user_email'],
							'user_mobile'			  => $database_results_array['user_mobile'],
							'user_gender'			  => $database_results_array['user_gender'],
							'user_avatar'			  => $database_results_array['user_avatar'],
							'user_birthday'			  => $database_results_array['user_birthday'],
							'user_unique_code'		  => convert_small_uuid_with_hash($database_results_array['user_unique_code']),
							'user_download_total'	  => $database_results_array['user_total_spent'],
							'user_download_quota'	  => counter_to_packages($database_results_array['user_total_purchases'], encrypt($database_results_array['objectId']), $database_results_array['user_subscription']),
							'main_custom_button'	  => main_custom_button($provided_user_id, floor($database_results_array['lastLogin'] / 1000), $database_results_array['user_firstname'], $database_results_array['user_lastname'], $database_results_array['user_email'], $database_results_array['user_mobile'], $database_results_array['user_gender'], round($database_results_array['updated'] / 1000), counter_to_packages($database_results_array['user_total_purchases'], encrypt($database_results_array['objectId']), $database_results_array['user_subscription']), $favorite_items, $database_results_array['user_avatar'], $database_results_array['user_birthday'], $database_results_array['user_birthday_updated'], $database_results_array['user_total_spent'], $database_results_array['user_total_purchases'], $database_results_array['user_is_verified']),
							'user_is_verified'		  => ($database_results_array['user_is_verified'] == 1) ? true : false,
							'user_token'			  => encrypt($database_results_array['objectId']),
							'created'				  => round($database_results_array['created'] / 1000),
							'updated'				  => round($database_results_array['updated'] / 1000),
							'user_favorites'		  => (!empty($favorite_items) ? $favorite_items : []),
						);

						@$op_time = $current_time;
						@$op_results = $user;
						@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
					
						$export = response_json($op_results, $op_time, $op_right);			
						return $export;
				
					} else {
						echo status_code(403, 'user is disabled!');
						exit;
					}
				
				} else {
					//$reason = $database_results_array['code']; // TODO: Change in production
					//echo status_code(401, $reason);
					$reason = $database_results_array['message'];
					echo status_code(401, $reason);
					exit;
				}
			
			} else {
				echo status_code(412);
				exit;
			}
			
		} else {
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_results, $op_time, $op_right){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}


?>