<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';
// Asynchronous request
require dirname(__FILE__) . '/library/vendor/autoload.php';
use mpyw\Co\Co;
use mpyw\Co\CURLException;

//
function curl_async_put($url, array $options = [], $user_token = '') {
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	}

	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "PUT",
		CURLOPT_POSTFIELDS => json_encode($options),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_get($url, array $options = [], $user_token = '') {
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	};
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function do_register_with_reference( $user_reference_code, $user_login, $user_password, $user_firstname = '', $user_lastname = '', $user_email = '', $user_mobile = '', $app_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		// We check to see if the reference user is active
		$reference_code_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users';
		$reference_code_headers = array(
			"Content-Type: application/json",
		);
		$reference_code_where = '?where=' . rawurlencode('user_unique_code=\'') . $user_reference_code .  rawurlencode('\' AND user_is_active=\'') . 1 . rawurlencode('\' AND user_is_verified=\'') . 1 . rawurlencode('\' AND lastLogin > ') . (( (float)$current_time * 1000 ) - (3 * 31 * 24 * 60 * 60 * 1000 /*3 months*/)) . '&pageSize=1' . '&sortBy=created%20desc';
		
		try {
			@$reference_results = getBackendlessResponse( $reference_code_url, $reference_code_headers, $reference_code_where );
			@$reference_results_array = json_decode($reference_results, true);
		
		} catch (Exception $ex){
			sendError( 'doUserRegister_withReference', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_unique_code: ' . @$user_reference_code . ' , app_id: ' . @$app_id . ' and time: ' . time() );
		}

		if ( !empty($reference_results_array) )
		{
			if ( empty($reference_results_array['code']) )
			{
				$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/users/register';
				$database_headers = array(
					"Content-Type: application/json",
				);
				
				// https://stackoverflow.com/a/11570263
				$data_register = array(
					'user_login'			=> $user_login,
					'password' 				=> $user_password,
					'user_firstname' 		=> $user_firstname,
					'user_lastname' 		=> $user_lastname,
					'user_is_active'		=> true,
					'user_unique_code'		=> generate_small_uuid($current_time),
					'referenced_code'		=> $user_reference_code,
				);
				if ( !empty($user_email) )
				{
					$data_register['email'] = $user_email;
				}
				if ( !empty($user_mobile) )
				{
					$data_register['user_mobile'] = $user_mobile;
				}
				
				
				try {
					@$database_results = sendBackendlessRequest( $database_url, $database_headers, json_encode($data_register) );
					@$database_results_array = json_decode($database_results, true);
					
				} catch (Exception $ex){
					sendError( 'doUserRegister_withReference', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_login: ' . @$user_login . ' , user_pass: ' . @$user_password . ' , user_email: ' . @$user_email . ' , user_mobile: ' . @$user_mobile . ' , app_id: ' . @$app_id . ' and time: ' . time() );
				}
				
				if ( !empty($database_results_array) )
				{
					if ( empty($database_results_array['code']) )
					{						
						$items = array(
							'user_login' 	   	   => $database_results_array['user_login'],
							'user_firstname' 	   => $database_results_array['user_firstname'],
							'user_lastname' 	   => $database_results_array['user_lastname'],
							'user_email'		   => $database_results_array['user_email'],
							'user_mobile'		   => $database_results_array['user_mobile'],
							'user_unique_code'	   => convert_small_uuid_with_hash($database_results_array['user_unique_code']),
							'user_token' 	 	   => encrypt($database_results_array['objectId']),
							'created' 			   => round($database_results_array['created'] / 1000),
						);
						
						
						@$op_user = $items;
						@$op_time = $current_time;
						@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
							
						$export = response_json($op_user, $op_time, $op_right);
						
					} elseif ( $database_results_array['code'] == 3033 ) {
						
						@$results = array(
							'code'		   => ERROR_3033,
							'message'	   => 'User already exists, please choose different username.',
						);
						
						@$op_user = $results;
						@$op_time = $current_time;
						@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
						
						$export = response_json($op_user, $op_time, $op_right);
						
						
					} else {
						//$reason = $database_results_array['code']; // TODO: Change in production
						//echo status_code(400, $reason);
						$reason = $database_results_array['message'];
						echo status_code(400, $reason);
						exit;
					}
					
					return $export;
					
				} else {
					echo status_code(412);
					exit;
				}
			
			} else {
				//$reason = $database_results_array['code']; // TODO: Change in production
				//echo status_code(400, $reason);
				$reason = $database_results_array['message'];
				echo status_code(400, $reason);
				exit;
			}
			
		} else { // Wrong promotion code
			
			@$results = array(
				'message'	   	=> 'Invalid reference code',
				'code'			=> ERROR_6001,
			);
			@$op_time = $current_time;
			@$op_results = $results;
			@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
			@$op_url = '';
			
			$export = response_json($op_results, $op_time, $op_right);
			return $export;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function do_register( $user_login, $user_password, $user_firstname = '', $user_lastname = '', $user_email = '', $user_mobile = '', $app_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/users/register';
		$database_headers = array(
			"Content-Type: application/json",
		);
		
		// https://stackoverflow.com/a/11570263
		$data_register = array(
			'user_login'			=> $user_login,
			'password' 				=> $user_password,
			'user_firstname' 		=> $user_firstname,
			'user_lastname' 		=> $user_lastname,
			'user_is_active'		=> true,
			'user_unique_code'		=> generate_small_uuid($current_time),
		);
		if ( !empty($user_email) )
		{
			$data_register['email'] = $user_email;
		}
		if ( !empty($user_mobile) )
		{
			$data_register['user_mobile'] = $user_mobile;
		}
		
		
		try {
			@$database_results = sendBackendlessRequest( $database_url, $database_headers, json_encode($data_register) );
			@$database_results_array = json_decode($database_results, true);
			
		} catch (Exception $ex){
			sendError( 'doUserRegister', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_login: ' . @$user_login . ' , user_pass: ' . @$user_password . ' , user_email: ' . @$user_email . ' , user_mobile: ' . @$user_mobile . ' , app_id: ' . @$app_id . ' and time: ' . time() );
		}
		
		if ( !empty($database_results_array) )
		{
			if ( empty($database_results_array['code']) )
			{
				$items = array(
                    'code'		   => ERROR_1000,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Registration in Diginava was successful',
                        ),
                        'fa'		   => array(
                            'content'	   => 'ثبت نام در دیجی‌نوا با موفقیت انجام شد',
                        ),
                    ),
					'user_login' 	   	   => $database_results_array['user_login'],
					'user_firstname' 	   => $database_results_array['user_firstname'],
					'user_lastname' 	   => $database_results_array['user_lastname'],
					'user_email'		   => $database_results_array['user_email'],
					'user_mobile'		   => $database_results_array['user_mobile'],
					'user_unique_code'	   => convert_small_uuid_with_hash($database_results_array['user_unique_code']),
					'user_token' 	 	   => encrypt($database_results_array['objectId']),
					'created' 			   => round($database_results_array['created'] / 1000),
				);
				
				@$op_user = $items;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
				
				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3000 ) {

                @$results = array(
                    'code'		   => ERROR_3000,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'User cannot be logged in',
                        ),
                        'fa'		   => array(
                            'content'	   => 'کاربر نمی‌تواند وارد سیستم شود',
                        ),
                    )
                );
				
				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
				
				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3002 ) {

                @$results = array(
                    'code'		   => ERROR_3002,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'User is already logged in from another device',
                        ),
                        'fa'		   => array(
                            'content'	   => 'کاربر با دستگاه دیگری وارد سیستم شده است',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3003 ) {

                @$results = array(
                    'code'		   => ERROR_3003,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Invalid login or password',
                        ),
                        'fa'		   => array(
                            'content'	   => 'نام کاربری یا رمز عبور اشتباه است',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3006 ) {

                @$results = array(
                    'code'		   => ERROR_3006,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Login or password is missing',
                        ),
                        'fa'		   => array(
                            'content'	   => 'نام کاربری یا رمز عبور وارد نشده است',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3016 ) {

                @$results = array(
                    'code'		   => ERROR_3016,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Cannot use provided parameters',
                        ),
                        'fa'		   => array(
                            'content'	   => 'اطلاعات قابل قبول نمی‌باشد',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3017 ) {

                @$results = array(
                    'code'		   => ERROR_3017,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'User property already exists',
                        ),
                        'fa'		   => array(
                            'content'	   => 'اطلاعات کاربری وجود دارد',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3018 ) {

                @$results = array(
                    'code'		   => ERROR_3018,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'User identity already exists',
                        ),
                        'fa'		   => array(
                            'content'	   => 'کاربری با این شناسه وجود دارد',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3020 ) {

                @$results = array(
                    'code'		   => ERROR_3020,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to find the user',
                        ),
                        'fa'		   => array(
                            'content'	   => 'چنین کاربری وجود ندارد',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3021 ) {

                @$results = array(
                    'code'		   => ERROR_3021,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to register user',
                        ),
                        'fa'		   => array(
                            'content'	   => 'ثبت نام قابل انجام نیست',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3022 ) {

                @$results = array(
                    'code'		   => ERROR_3022,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to login user',
                        ),
                        'fa'		   => array(
                            'content'	   => 'ورود به سیستم قابل انجام نیست',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3023 ) {

                @$results = array(
                    'code'		   => ERROR_3023,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to logout user',
                        ),
                        'fa'		   => array(
                            'content'	   => 'خروج از سیستم قابل انجام نیست',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3024 ) {

                @$results = array(
                    'code'		   => ERROR_3024,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to update user account',
                        ),
                        'fa'		   => array(
                            'content'	   => 'تغییر اطلاعات کاربری قابل انجام نیست',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3025 ) {

                @$results = array(
                    'code'		   => ERROR_3025,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to perform password recovery',
                        ),
                        'fa'		   => array(
                            'content'	   => 'بازیابی رمز عبور قابل انجام نیست',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3026 ) {

                @$results = array(
                    'code'		   => ERROR_3026,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to retrieve user properties',
                        ),
                        'fa'		   => array(
                            'content'	   => 'مشخصات کاربری قابل دریافت نیست',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3027 ) {

                @$results = array(
                    'code'		   => ERROR_3027,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unknown error',
                        ),
                        'fa'		   => array(
                            'content'	   => 'خطای ناشناخته',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3028 ) {

                @$results = array(
                    'code'		   => ERROR_3028,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to update user',
                        ),
                        'fa'		   => array(
                            'content'	   => 'اطلاعات کاربر بروزرسانی نشد',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3029 ) {

                @$results = array(
                    'code'		   => ERROR_3029,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to update user',
                        ),
                        'fa'		   => array(
                            'content'	   => 'اطلاعات کاربری بروزرسانی نشد',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                $export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3030 ) {

                @$results = array(
                    'code'		   => ERROR_3030,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to update user',
                        ),
                        'fa'		   => array(
                            'content'	   => 'اطلاعات کاربری بروزرسانی نشد',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                $export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3031 ) {

                @$results = array(
                    'code'		   => ERROR_3031,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to update user',
                        ),
                        'fa'		   => array(
                            'content'	   => 'اطلاعات کاربری بروزرسانی نشد',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                $export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3032 ) {

                @$results = array(
                    'code'		   => ERROR_3032,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to update user',
                        ),
                        'fa'		   => array(
                            'content'	   => 'اطلاعات کاربری بروزرسانی نشد',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                $export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3033 ) {

                @$results = array(
                    'code'		   => ERROR_3033,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'User with the same identity already exists',
                        ),
                        'fa'		   => array(
                            'content'	   => 'کاربری با این نام در سیستم وجود دارد',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                $export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3034 ) {

                @$results = array(
                    'code'		   => ERROR_3034,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'User login is disabled',
                        ),
                        'fa'		   => array(
                            'content'	   => 'ورود به سیستم محدود شده است',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3036 ) {

                @$results = array(
                    'code'		   => ERROR_3036,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'User account is locked out due to too many failed requests',
                        ),
                        'fa'		   => array(
                            'content'	   => 'حساب کاربری به علت درخواست‌های اشتباه موقتاً مسدود شده است',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3039 ) {

                @$results = array(
                    'code'		   => ERROR_3039,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'This name cannot be chosen',
                        ),
                        'fa'		   => array(
                            'content'	   => 'این نام غیرقابل انتخاب است',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3040 ) {

                @$results = array(
                    'code'		   => ERROR_3040,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Email address is in the wrong format',
                        ),
                        'fa'		   => array(
                            'content'	   => 'آدرس ایمیل اشتباه است',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3041 ) {

                @$results = array(
                    'code'		   => ERROR_3041,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Unable to register user',
                        ),
                        'fa'		   => array(
                            'content'	   => 'ثبت نام غیرقابل انجام است',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3044 ) {

                @$results = array(
                    'code'		   => ERROR_3044,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Multiple login limit for the user account',
                        ),
                        'fa'		   => array(
                            'content'	   => 'ورود کاربر موقتاً غیرفعال گردید',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3048 ) {

                @$results = array(
                    'code'		   => ERROR_3048,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Session timeout',
                        ),
                        'fa'		   => array(
                            'content'	   => 'ورود منقضی شده است',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3050 ) {

                @$results = array(
                    'code'		   => ERROR_3050,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Password should be string',
                        ),
                        'fa'		   => array(
                            'content'	   => 'رمز عبور فقط باید شامل حروف و علائم باشد',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3055 ) {

                @$results = array(
                    'code'		   => ERROR_3055,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Incorrect password',
                        ),
                        'fa'		   => array(
                            'content'	   => 'رمز عبور اشتباه است',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3057 ) {

                @$results = array(
                    'code'		   => ERROR_3057,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'Could not find user',
                        ),
                        'fa'		   => array(
                            'content'	   => 'کاربری با این مشخصات یافت نشد',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} elseif ( $database_results_array['code'] == 3090 ) {

                @$results = array(
                    'code'		   => ERROR_3090,
                    'message'	   => array(
                        'en'		   => array(
                            'content'	   => 'User account is disabled',
                        ),
                        'fa'		   => array(
                            'content'	   => 'کاربر غیرفعال شده است',
                        ),
                    )
                );

				@$op_user = $results;
				@$op_time = $current_time;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

				$export = response_json($op_user, $op_time, $op_right);

			} else {
				//$reason = $database_results_array['code']; // TODO: Change in production
				//echo status_code(400, $reason);
				$reason = $database_results_array['message'];
				echo status_code(400, $reason);
				exit;
			}
			
			return $export;
			
		} else {
			echo status_code(412);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_user, $op_time, $op_right){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'results'		=> $op_user,
				'copyright'		=> $op_right,
			)
		)
	);
	
	return json_encode($output);
}

?>