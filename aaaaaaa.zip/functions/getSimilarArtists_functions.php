<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';

//
function get_artist_similar($id, $limit, $offset) {
	
	$id_original = $id;
	$decrypted_id = remove_non_utf8(md5_decrypt($id, MD5_ID_MASTERKEY));
	$constructed_id = explode(':', $decrypted_id);
	$id = $constructed_id[1];
	
	$query = 'http://i-serp.com/fetchSimilarArtists.php?id=' . $id . '&l=' . $limit . '&o=' . $offset;
	@$raw_data = stream_open($query, 'http://i-serp.com/', 'i-serp.com');
	@$data = json_decode($raw_data, true);
	
	if ( @$data["status"] == "error" || empty($data) ) 
	{
		$query = 'http://muism.com/v1/fetchSimilarArtists.php?id=' . $id . '&l=' . $limit . '&o=' . $offset;
		@$raw_data = stream_open($query, 'http://muism.com/', 'muism.com');
		@$data = json_decode($raw_data, true);
			
			if ( @$data["status"] == "error" || empty($data) ) 
			{
				$query = ORIGINALAPI . 'artist/getSimilarArtists?t=-526898600&app_id=' . ORIGINALAPPID . '&limit=' . $limit . '&offset=' . $offset .'&artist_id=' . $id;
				@$raw_data = stream_open($query, 'http://www.qobuz.com/', 'www.qobuz.com');
				@$data = json_decode($raw_data, true);
			}
	}
	
	@$parent_response_offset = $data['artists']['offset'];
	@$parent_response_limit = $data['artists']['limit'];
	@$parent_response_total = $data['artists']['total'];
	@$parent_response_items = $data['artists']['items'];
	$current_time = time();
	
	// Foreach correction ! http://stackoverflow.com/a/15150384
	$response_array = isset($parent_response_items[0]) ? $parent_response_items : array($parent_response_items);
	foreach($response_array as $itme_num => $data) {
		if ( !empty($data) && empty($data['status']) )
		{
			@$data_id = $data["id"];
			@$data_name = $data["name"];
			@$data_slug = make_slug($data["name"]);
			@$data_albums_count = $data["albums_count"];
			
			if ( !empty($data['image']) )
			{
				$artist_image_small_id = get_artist_image_id(parse_url($data['image']['small'], PHP_URL_PATH))[1];
				$artist_image_small_ext = get_artist_image_id(parse_url($data['image']['small'], PHP_URL_PATH))[2];
				$artist_image_medium_id = get_artist_image_id(parse_url($data['image']['medium'], PHP_URL_PATH))[1];
				$artist_image_medium_ext = get_artist_image_id(parse_url($data['image']['medium'], PHP_URL_PATH))[2];
				$artist_image_large_id = get_artist_image_id(parse_url($data['image']['large'], PHP_URL_PATH))[1];
				$artist_image_large_ext = get_artist_image_id(parse_url($data['image']['large'], PHP_URL_PATH))[2];
				$_image_small = 'small' . ':' . $artist_image_small_id;
				$_image_medium = 'medium' . ':' . $artist_image_medium_id;
				$_image_large = 'large' . ':' . $artist_image_large_id;
				$dedicated_image = true;
				$the_color = mt_rand(0,360);
				@$response_image = array(
						"34"	   		 => checkSafeValue(ASSETSSERVER . 'artists/' . construct_the_id(QOBUZSERVICE . 'ArtistsImage', $_image_small) . '.' . $artist_image_small_ext, avatar_generator('', 21, 'false', '0.43', 'true', $the_color)), // We need only background color for color Pallet
						"64"			 => checkSafeValue(ASSETSSERVER . 'artists/' . construct_the_id(QOBUZSERVICE . 'ArtistsImage', $_image_small) . '.' . $artist_image_small_ext, avatar_generator($response_name, 64, 'false', '0.43', 'true', $the_color)),
						"174"			 => checkSafeValue(ASSETSSERVER . 'artists/' . construct_the_id(QOBUZSERVICE . 'ArtistsImage', $_image_medium) . '.' . $artist_image_medium_ext, avatar_generator($response_name, 174, 'false', '0.43', 'true', $the_color)),
						"300"			 => checkSafeValue(ASSETSSERVER . 'artists/' . construct_the_id(QOBUZSERVICE . 'ArtistsImage', $_image_medium) . '.' . $artist_image_medium_ext, avatar_generator($response_name, 300, 'false', '0.43', 'true', $the_color)),
						"600"			 => checkSafeValue(ASSETSSERVER . 'artists/' . construct_the_id(QOBUZSERVICE . 'ArtistsImage', $_image_large) . '.' . $artist_image_large_ext, avatar_generator($response_name, 512, 'false', '0.43', 'true', $the_color)),
						"full"			 => checkSafeValue(ASSETSSERVER . 'artists/' . construct_the_id(QOBUZSERVICE . 'ArtistsImage', $_image_large) . '.' . $artist_image_large_ext, avatar_generator($response_name, 512, 'false', '0.43', 'true', $the_color)),
					);
			} else 
			{
				$dedicated_image = false;
				$the_color = mt_rand(0,360);
				@$response_image = array(
						"34"			 => avatar_generator('', 21, 'false', '0.43', 'true', $the_color), // We need only background color for color Pallet
						"64"			 => avatar_generator($data_name, 64, 'false', '0.43', 'true', $the_color),
						"174"			 => avatar_generator($data_name, 174, 'false', '0.43', 'true', $the_color),
						"300"			 => avatar_generator($data_name, 300, 'false', '0.43', 'true', $the_color),
						"600"			 => avatar_generator($data_name, 512, 'false', '0.43', 'true', $the_color),
						"full"			 => avatar_generator($data_name, 512, 'false', '0.43', 'true', $the_color),
					);
			}
			
			$items[] = array(
					"id"  	   		   => checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_id), null ),
					"name" 			   => hdryn_change_france($data_name),
					"slug"  		   => $data_slug,
					"albums_count"     => $data_albums_count,
					"image"			   => $response_image,
					"dedicated_image"  => $dedicated_image
				);
			
		} else { // Nothing returned from the server
			echo status_code(404);
			exit;
		}
	}


	@$op_time = $current_time;
	@$op_query = $id_original;
	@$op_offset = $parent_response_offset;
	@$op_limit = $parent_response_limit;
	@$op_total = $parent_response_total;
	@$op_more_results = has_more_results($op_offset, $op_limit, $parent_response_total);
	@$op_results = ( !empty($items) ? $items : [] );
	@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
	@$op_url = '';
	
	$export = response_json($op_time, $op_query, $op_offset, $op_limit, $op_total, $op_results, $op_right, $op_url, $op_more_results);
	// Creating temporary cache file
	temp_creator_on_server( basename(__FILE__, '_functions.php'), 'artist' . $id_original . $limit . $offset, $export );
	
	return $export;
	
}

//
function response_json($op_time, $op_query, $op_offset, $op_limit, $op_total, $op_results, $op_right, $op_url = '', $op_more_results){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'query'			=> $op_query,
				'offset'		=> $op_offset,
				'limit'			=> $op_limit,
				'total'			=> $op_total,
				'more_results'	=> $op_more_results,
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}

?>