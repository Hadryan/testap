<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';


//
function set_reports( $album_id, $album_name , $report_type, $app_id, $user_token, $session_id ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$decrypted_id = remove_non_utf8(md5_decrypt($album_id, MD5_ID_MASTERKEY));
			$constructed_id = explode(':', $decrypted_id);
			$album_id = $constructed_id[1];
			
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users_Reports';
			$database_headers = array(
				"Content-Type: application/json",
			);
			$data_set_reports = array(
				'report_id'	  	   	=> $user_objectId . '_' . $album_id . '-' . $report_type,
				'report_type'		=> $report_type,
				'album_name'		=> $album_name,
				'album_id'			=> $album_id,
				'ownerId'			=> $user_objectId,
			);
			
			try {
				@$database_results = updateBackendlessRequest( $database_url, $database_headers, json_encode($data_set_reports) );
				@$database_results_array = json_decode($database_results, true);
			
			} catch (Exception $ex){
				sendError( 'setUserReports', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , album_id: ' . @$album_id . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}		
			
			if ( !empty($database_results_array) )
			{
				if ( empty($database_results_array['code']) )
				{
					$created_owner_id = $database_results_array['ownerId'];
					$created_object_id = $database_results_array['objectId'];
					
					$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $created_owner_id . '/user_reports';
					$relation_data = array(
						'objectId' 	 => $created_object_id
					);
					
					try {
						updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
					
					} catch (Exception $ex){
						sendError( 'setUserReports_relationUpdate', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , report_objectId: ' . @$created_object_id . ' , app_id: ' . @$app_id . ' and time: ' . time() );
					}
					
					return status_code(201);
					
				} else {
					echo status_code(412, 'this value is already set!');
					exit;
				}
			
			} else { // Nothing returned from the server
				echo status_code(404);
				exit;
			}
		
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json(){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'success',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> json_decode('{}')
		)
	);
	
	return json_encode($output);
}

?>