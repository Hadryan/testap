<?php
include dirname(__FILE__) . '/functions/functions_general.php';

error_reporting(-1);
ini_set('display_errors', 1);
@set_time_limit(4500000);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Credentials: TRUE");
header("Content-type: text/html; charset=utf-8");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 19 Jul 1999 09:09:09 GMT");

/*
	09.09.17 09:13 AM
	/v1/getAlbum/{album_id}
	/v1/getAlbum/b3gh16a6g
*/

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Credentials: TRUE");
header("Content-type: application/json; charset=utf-8");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");

 
	$json_album_ids = '["68232","2663561","2065366","91444","247625","270629","613814","53556","4682288","492265"]';
	$album_ids = json_decode($json_album_ids, true);
	//http://localhost:6142/v1/graphql

	foreach ($album_ids as $number => $album_id) {
		update_DB($album_id);

	}


	function update_DB ($id) {
		$encrypted_id = construct_the_id(QOBUZSERVICE . 'Artist', $id);
	
	// GraphQl query begins
		$album_part = <<<ALBUM
		mutation MyMutation {
		  update_music_Artists(where: {artist_id: {_eq: "$id"}}, _set: {id: "$encrypted_id"}) {
			affected_rows
			returning {
			  id
			}
		  }
		}
	ALBUM;
	
		$graphql = $album_part;
		$query = graphql_query('http://localhost:6142/v1/graphql', $graphql, MUSIC_GRAPHQL_ADMINPASS, [], null);
		return $query;
	}
?>