<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(30);
header("Access-Control-Allow-Origin: *");
header("Content-Type:application/json");

include dirname(__FILE__) . '/functions.php';

	@$id = $_GET['id'];
	@$app_id = $_GET['app_id'];
	@$app_secret = $_GET['app_secret'];
	@$user_token = $_GET['user_token'];
	if ( empty($app_id) )
	{
		$app_id = QOBUZAPPID;
	}
	if ( empty($app_secret) )
	{
		$app_secret = QOBUZAPPSECRET;
	}
	if ( empty($user_token) )
	{
		$user_token = QOBUZUSERTOKEN;
	}

	if ( $id  )
	{
		@$raw_data = FullLengthTrack($id, 5, $app_id, $app_secret, $user_token);
		//var_dump($raw_data);
			
			try {
				if (substr($raw_data, 0, 15) == "<methodResponse" || substr($raw_data, 0, 5) == "<?xml")
					{
						$xml = simplexml_load_string($raw_data);
						$json = json_encode($xml);
						//echo $json;
					}
				else
					{
						$json = $raw_data;
					}
			} catch(Exception $ex){
				$json = 'Error while retrieving tracks, try again in few moments..';
			
			}
			
		echo $json;
	}
	
//
function FullLengthTrack($track_id, $format_id = 5, $app_id, $app_secret, $user_token) {
	
	$object          = 'track';
	$method          = 'getFileUrl';
	$parameters      = array('track_id' => $track_id, 'format_id' => $format_id);
	$request_ts      = time();
	$request_sig     = md5($object.$method.explodeForSignature($parameters).$request_ts.$app_secret);
	
	$url = sprintf('http://www.qobuz.com/api.json/0.2/%s/%s?%s', $object, $method, http_build_query(array_merge( $parameters, 
	array(
		'app_id'          	 		=> $app_id,
		'request_ts'     			=> $request_ts,
		'request_sig'    			=> $request_sig,
		"user_auth_token"			=> $user_token,
		"auth_token" 				=> $user_token,
	)
	)));

	$headers = array(
		"X-App-Id: " . $app_id,
		"X-User-Auth-Token: " . $user_token,
	);
	
	$json = stream_send($url, $headers, '');
	
	return $json;
}
?>