<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(600);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Credentials: TRUE");
header("Content-type: application/json; charset=utf-8");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 19 Jul 1999 09:09:09 GMT");


include dirname(__FILE__) . '/' . basename(__FILE__, '.php') . '_functions.php';

	@$track_id = $_POST['track_id'];
	@$track_origin = $_POST['track_origin'];
	@$track_format = $_POST['track_format'];
	@$request_ts = $_GET['request_ts'];
	@$request_sig = $_GET['request_sig'];

	$now = time();
	@$endpoint = 'internalFullAudioProcess';
	$fetch_secret = 'gmStjs6f!Fj~fU*-Q*ttqx#hBu$a8T@~G0D#*%wb2k<}.)<,tt_dyH/4#H_4G~,ZVH+!NJKOr5';

	//if ( $track_id && $request_ts && $request_sig && ($request_ts > $now - 1800 /*30 min*/) && ($request_ts < $now + 900 /*15 min*/) )
	if (1==1)
	{
		@$string = $endpoint . $track_id . $request_ts . $fetch_secret;
		
		//if ( verify_hmac_signature($string, $fetch_secret, $request_sig) === TRUE )
		if (1==1)
		{
			define('AllowToAccessInternalFullAudioProcessFunctions', TRUE);
			$export = process_full_audio( $track_id, $track_format, $track_origin, '512M',  $now );
			echo $export;
			
		} else {
			echo status_code(401);
			exit;
		}
		
	} else // parameter are not provided
	{
		echo status_code(417);
	}

?>
