<?php

//
// Performance checker https://stackoverflow.com/a/2482007
function filter_black_artists($artist_id){

	$black = array(
		'206192'			=> 1,
		'472616'			=> 1,
		'3869459'			=> 1,
		'33'			=> 1,

		
		
		
		
		
		
		
		
		
		
		
		
		
		//''			=> 1,
		
	);

	if ( isset($black[$artist_id]) )
	{
		return true;
		
	} else
	{
		return false;
	}
}

?>