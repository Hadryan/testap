<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';


//
function insert_artist( $id, $url ) {

	if ( defined('AllowToAccessDataBaseFunctions') )
	{
		$current_time = time();
		$service_id = json_encode('1');
		
		@$fetch_url = stream_open($url, parse_url($url, PHP_URL_HOST), parse_url($url, PHP_URL_HOST), $accept = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', USERAGENT, true, false );
		@$data = json_decode($fetch_url, true);
		
		if ( !empty($data["id"]) && ($id == $data["id"]) )
		{
			@$data_image_url = json_encode($data["image"]["large"]);
			@$data_id = json_encode((string)$data["id"]);
			@$data_title = json_encode($data["name"]);
			@$data_picture = json_encode($data["picture"]);
			@$data_information = json_encode($data["information"]);
			@$data_biography_content = json_encode($data["biography"]["content"]);
			@$data_biography_source = json_encode($data["biography"]["source"]);
			@$data_biography_language = json_encode($data["biography"]["language"]);
		
			
// GraphQl query begins		
$query_part = <<<ARTIST
mutation insertArtist {
  insert_music_Artists(
	objects:
	  {
		artist_id: $data_id
		composer_id: $data_id
		biography_content: $data_biography_content
		biography_language: $data_biography_language
		biography_source: $data_biography_source
		image_url: $data_image_url
		information: $data_information
		picture: $data_picture
		service_id: $service_id
		title: $data_title
		_updatedAt: $current_time
	  }
ARTIST;
	
	if ( POSTGRES_ARTIST_ONCONFLICT == 1 )
	{
$query_part .= <<<ARTIST
			on_conflict: {
			  constraint: Artists_pkey
			  update_columns: [
				biography_content
				biography_language
				biography_source
				image_url
				information
				picture
				title
				_updatedAt
			  ]
			}
ARTIST;
	}
	
$query_part .= <<<ARTIST
			) {
			  affected_rows
			  returning {
				id: artist_id
			  }
			}
		  }
ARTIST;
		
		$graphql = $query_part;
		
		$query = graphql_query(MUSIC_GRAPHQL_ENDPOINT, $graphql, MUSIC_GRAPHQL_ADMINPASS, [], null);
		
			if ( $data["id"] == $query["data"]["insert_music_Artists"]["returning"][0]["id"])
			{
				echo status_code(201);
			
			} else {
				sendError( 'insertAlbum', 'error', '', 'database update failed', 'artist_id: ' . $id . ' url_id: ' . $url . ' and time: ' . time() );
				exit;
			}
		
		} else {
			echo status_code(412);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

?>