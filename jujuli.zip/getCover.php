<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(55);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Credentials: TRUE");
header("X-Diginava-Algorithm: Algorithm-4");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");

include dirname(__FILE__) . '/' . basename(__FILE__, '.php') . '_functions.php';
use FastBill\ParallelProcessDispatcher\Process;
use FastBill\ParallelProcessDispatcher\Dispatcher;

	@$uri = $_GET['uri'];
	@$sharpening = $_GET['sh'];
	$size_quality = 89;
	

	if ( $uri )
	{
		if ( empty($sharpening) )
		{
			$sharpening = 'no'; // Do sharpening the image unless the value is "yes"
		}
		
		if( preg_match("/\/(?<image>([^\/]*)?).(?<extension>(?:jpe?g|png|gif|bmp|tiff|tif))/", $uri, $matchings) )
		{
			$image_id = $matchings['image'];
			$extension = $matchings['extension'];
			
			$decrypted_id = remove_non_utf8(md5_decrypt($image_id, MD5_EXTERNAL_RESOURCE));
			$constructed_id = explode(':', $decrypted_id); // processor_node_id:size_desc:image_id
			$id = $constructed_id[2];
			$size = $constructed_id[1];
			$service_id = $constructed_id[0];
			
			if ( $size == '50' )
			{
				$width = $height =  '50';
				$size_quality = 70;
				$sharpening = 'yes';
			} elseif ( $size == '100' ) 
			{
				$width = $height =  '100';
				$size_quality = 75;
			} elseif ( $size == '150' ) 
			{
				$width = $height =  '150';
			} elseif ( $size == '230' ) 
			{
				$width = $height =  '230';
				$size_quality = 89;
				$sharpening = 'yes';
			} elseif ( $size == '300' ) 
			{
				$width = $height =  '300';
			} elseif ( $size == '600' ) 
			{
				$width = $height =  '600';
				$size_quality = 95;
			}
			
			@$path_1 = substr($id, (strlen($id) - 2), 2);
			@$path_2 = substr($id, (strlen($id) - 4), 2);
			
			@$output_1 = substr($id, strlen($id) - 2, 2); // The End two characters
			@$output_2 = substr($id, strlen($id) - 4, 2); // Next to the 2 end, two characters
			@$output_path = $output_1 . '/' . $output_2;
			
			if ( $service_id == 8 ) { // Qobuz service
				
				@$image_url = 'http://d250ptlkmugbjz.cloudfront.net/images/covers/' . $path_1 . '/' . $path_2 . '/' . $id . '_' . $size . '.jpg';
				@$explode = parse_url($image_url);
				@$scheme = $explode['scheme'];
				@$host = $explode['host'];
				@$referer = $scheme . '://' . $host . '/';
				
				@$image_original = stream_open($image_url, $referer, $host, 'Accept: image/png,image/*;q=0.8,*/*;q=0.5');
				@$image = imagecreatefromstring($image_original);
				@$width_original = $width = imagesx($image);
				@$height_original = $height = imagesy($image);
	
				if ( !empty($width_original) ) // If we can't get the image dimensions, there should be something wrong with the image_url 
				{
					if ( $sharpening == 'yes' ) // Only do sharpen image if the value is explicitly "yes" 
					{
						// Sharpening image
						$sharpenMatrix = array
						(
							array(-1.2, -1, -1.2),
							array(-1, 20, -1),
							array(-1.2, -1, -1.2)
						);
						// calculate the sharpen divisor
						$divisor = array_sum(array_map('array_sum', $sharpenMatrix));           
						$offset = 0;
						//apply the matrix
						imageconvolution($image, $sharpenMatrix, $divisor, $offset);
					}	
				
					$thumb = imagecreatetruecolor($width, $height);
					imagecopyresized($thumb, $image, 0, 0, 0, 0, $width, $height, $width_original, $height_original);
				
					// Progressive image
					imageinterlace($thumb, true);
				
					// https://stackoverflow.com/a/22266437
					ob_start(); // Let's start output buffering.
						imagejpeg($thumb); //This will normally output the image, but because of ob_start(), it won't.
						$contents = ob_get_contents(); //Instead, output above is saved to $contents
					ob_end_clean(); //End the output buffer.
				
					// Save image
					$image_size_id = $size . ':' . $id;
					$no_output_wait = ' > /dev/null 2> /dev/null';
					$no_output_wait_background = ' > /dev/null 2> /dev/null &';
				
					// Creating temporary directory
					$destination = $_SERVER['DOCUMENT_ROOT'] . '/' . MEDIAURI;
					if (!is_dir($destination)) {
						$make_directory = createPath($destination);
					}
					file_put_contents($destination . '/' . $id . $size, $contents);
					$original_file = MEDIAURI . '/' . $id . $size;
					$encrypted_id = construct_the_id(QOBUZSERVICE . 'Cover', $image_size_id);
				
					$dispatcher = new Dispatcher(1);    // will make sure only one of those will actually run at the same time
				
					// Uploading image file
					// https://stackoverflow.com/a/52620939
					$processUpload__d = new Process('aws s3 cp ' . $original_file . ' s3://' . BUCKET_ASSETS . '/covers/' . $encrypted_id . '.' . $extension . '  --acl public-read --cache-control public,max-age=604800 --content-type image/' . $extension . ' --storage-class INTELLIGENT_TIERING' . $no_output_wait);				
					$dispatcher->addProcess($processUpload__d, true);
					$processUpload_tag = new Process('aws s3api put-object-tagging --bucket ' . BUCKET_ASSETS . ' --key "' . 'covers/' . $encrypted_id . '.' . $extension . '"' . ' --tagging TagSet="[{Key=size,Value=' . $size . '}]"' . $no_output_wait_background);
					$dispatcher->addProcess($processUpload_tag, true);
				
					$dispatcher->tick();
					$dispatcher->dispatch();  // this will run until all processes are finished.
					$processes = $dispatcher->getFinishedProcesses();
				
					// Show image
					header('Content-Type: image/jpeg');
					imagejpeg($thumb, null, $size_quality);
				
					// Clearing the image cache
					imagedestroy($thumb);
					imagedestroy($image);
				}
				
			}
			
		} else {
			header('Content-Type: image/gif');
			$image=imagecreatefromgif('blank.gif');
			imagegif($image);
			imagedestroy($image);
		}
		
	} else {
		header('Content-Type: image/gif');
		$image=imagecreatefromgif('blank.gif');
		imagegif($image);
		imagedestroy($image);
	}

?>
