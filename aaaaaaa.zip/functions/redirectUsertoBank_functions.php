<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';

//
function redirect_to_bank( $bank_token, $app_id, $user_token, $session_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			@$bank_token = decrypt($bank_token, BANK_TOKEN_HASH);
			$bank_url = 'https://sep.shaparak.ir/MobilePG/MobilePayment';
			
			$html = '
				<html>
					<head>
						<meta charset="UTF-8">
						<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
						<meta http-equiv="X-UA-Compatible" content="ie=edge">
						<title>' . APINAME . '</title>
					</head>
				<body onload=\'document.forms["form"].submit()\'><form name="form" action="' . $bank_url . '" method="POST"><input type="hidden" value="' . $bank_token . '" name="Token"/></form></body>
			';
			
			return $html;
			
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

?>