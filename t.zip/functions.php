<?php

define("QOBUZAPPID",			"421125438");
define("QOBUZAPPSECRET",		"1e51aa18d871fc2b5a00ca9d9d3f1f55");
define("QOBUZUSERTOKEN",		"sfxUMJDVAjfYEnUUOmAk9PaZQPY8Z2wq5Tqh_Hyc80dPiXDDf2dLddxGfwl6RQgNLe9Ij94t9oGqpSI5KxIbxg");


//
function stream_send( $url, $headers, $object_data ){
	$rest = curl_init();

	$cookie_string = "__atuvc=1%7C40%2C1%7C41; ";
	$cookie_string .= "i18next=fr-FR; ";
	

	$headers = array();
	$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
	$headers[] = 'Accept-Encoding: gzip, deflate';
	$headers[] = 'Accept-Language: fr-FR,en;q=0.5';
	$headers[] = 'Cache-Control: no-cache';
	$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=utf-8';
	$headers[] = 'Connection : keep-alive';
	$headers[] = 'User-Agent: ' . user_aget();
	

	
	curl_setopt($rest, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($rest, CURLOPT_ENCODING, '');
	curl_setopt($rest, CURLOPT_COOKIE, $cookie_string);

	curl_setopt($rest, CURLOPT_URL, $url);
	curl_setopt($rest, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($rest, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($rest, CURLOPT_POSTFIELDS, $object_data);
	curl_setopt($rest, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($rest, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($rest, CURLOPT_ENCODING, '');
	curl_setopt($rest, CURLOPT_COOKIE, $cookie_string);
	curl_setopt($rest, CURLOPT_FRESH_CONNECT, false);
	curl_setopt($rest, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($rest, CURLOPT_RETURNTRANSFER, true);

	$response = curl_exec($rest);

	curl_close($rest);
		
return $response;
}

//
function stream_open($url, $refer = 'http://www.google.com/', $host = 'google.com', $https = false ) {
			
	$options = array(
			
		CURLOPT_CUSTOMREQUEST  =>"GET",        //set request type post or get
		CURLOPT_POST           =>false,        //set to GET
			
		CURLOPT_RETURNTRANSFER => true,     // return web page
		CURLOPT_HEADER         => false,    // don't return headers
		CURLOPT_FOLLOWLOCATION => true,     // follow redirects
		CURLOPT_ENCODING       => "",       // handle all encodings
		CURLOPT_AUTOREFERER    => true,     // set referer on redirect
		CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
		CURLOPT_TIMEOUT        => 120,      // timeout on response
		CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
	);
					
		$ch      = curl_init( $url );
					
		$cookie_string = "__atuvc=1%7C40%2C1%7C41; ";
		$cookie_string .= "i18next=fr-FR; ";
		

		$headers = array();
		$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
		$headers[] = 'Accept-Encoding: gzip, deflate';
		$headers[] = 'Accept-Language: fr-FR,en;q=0.5';
		$headers[] = 'Cache-Control: no-cache';
		$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=utf-8';
		$headers[] = 'Host: ' . $host . '';
		$headers[] = 'Referer: '  . $refer . '';
		$headers[] = 'Connection : keep-alive';
		$headers[] = 'User-Agent: ' . user_aget();
		
		curl_setopt($ch, CURLOPT_URL, $url);  
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			if ( $https == 1 )
			{
				curl_setopt ($ch, CURLOPT_CAINFO, dirname(__FILE__)."/cacert.pem");
			}
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_ENCODING, '');
		curl_setopt($ch, CURLOPT_COOKIE, $cookie_string);
					
		curl_setopt_array( $ch, $options );
		$content = curl_exec( $ch );
		$err     = curl_errno( $ch );
		$errmsg  = curl_error( $ch );
		$header  = curl_getinfo( $ch );
		curl_close( $ch );
			
		$header['errno']   = $err;
		$header['errmsg']  = $errmsg;
		$header['content'] = $content;
	return $header['content'];
}

//
function user_aget() {
	
		$random = array(
			1 => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
			2 => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36',
			3 => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
			4 => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2226.0 Safari/537.36',
			5 => 'Mozilla/5.0 (Windows NT 6.4; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36',
			6 => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36',
			7 => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36',
			8 => 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36',
			9 => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.67 Safari/537.36',
			
			10 => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) ChromePlus/4.0.222.3 Chrome/4.0.222.3 Safari/532.2',
			11 => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.28.3 (KHTML, like Gecko) Version/3.2.3 ChromePlus/4.0.222.3 Chrome/4.0.222.3 Safari/525.28.3',
			
			12 => 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1',
			13 => 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0',
			
			14 => 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko',
			15 => 'Mozilla/5.0 (compatible, MSIE 11, Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko',
			16 => 'Mozilla/5.0 (compatible; MSIE 10.6; Windows NT 6.1; Trident/5.0; InfoPath.2; SLCC1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 2.0.50727) 3gpp-gba UNTRUSTED/1.0',
			
			17 => 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
			18 => 'Mozilla/5.0 (Linux; U; Android 4.0.3; de-ch; HTC Sensation Build/IML74K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
			19 => 'Mozilla/5.0 (Linux; U; Android 2.3.5; zh-cn; HTC_IncredibleS_S710e Build/GRJ90) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			20 => 'Mozilla/5.0 (Linux; U; Android 2.3.4; fr-fr; HTC Desire Build/GRJ22) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			21 => 'Mozilla/5.0 (Linux; U; Android 2.3.3; zh-tw; HTC_Pyramid Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari',
			22 => 'Mozilla/5.0 (Linux; U; Android 2.3.3; de-de; HTC Desire Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			23 => 'Mozilla/5.0 (Linux; U; Android 2.2.1; en-gb; HTC_DesireZ_A7272 Build/FRG83D) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			24 => 'Mozilla/5.0 (Linux; U; Android 2.2.1; en-ca; LG-P505R Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			25 => 'Mozilla/5.0 (Linux; U; Android 2.3.4; en-us; T-Mobile myTouch 3G Slide Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			26 => 'Mozilla/5.0 (Linux; U; Android 4.0.3; en-us; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
			27 => 'Mozilla/5.0 (Linux; U; Android 2.3.3; en-us; LG-LU3000 Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			
			28 => 'Mozilla/5.0 (compatible; MSIE 9.0; Windows Phone OS 7.5; Trident/5.0; IEMobile/9.0)',
			
			29 => 'Opera/12.02 (Android 4.1; Linux; Opera Mobi/ADR-1111101157; U; en-US) Presto/2.9.201 Version/12.02',
			30 => 'Opera/9.80 (S60; SymbOS; Opera Mobi/SYB-1107071606; U; en) Presto/2.8.149 Version/11.10',
			31 => 'Opera/9.80 (Android 2.3.3; Linux; Opera Mobi/ADR-1111101157; U; en-US) Presto/2.9.201 Version/11.50',
			
			// Repeating the chrome browser ! (favorite browser)
			32 => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
			33 => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36',
			34 => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
			
		);
	
		$selected = strtr(rand(1,sizeof($random)), $random);
	
	return $selected;
}

//
function alphabeticalQuery($parameters) {
	ksort($parameters);
	$size = sizeof($parameters);
	$index = 0;
	$ret = '';
	foreach ($parameters as $key => $value) {
		if (is_array($value)) {
			asort($value);
			$ret .= $key.implode(',', array_values($value));
			if( $index < $size - 1 ){
			    $ret .= '&';
			}
		} else {
			$ret .= $key.'='.$value;
			if( $index < $size - 1 ){
			    $ret .= '&';
			}
		}
		$index++;
	}
	return $ret;
}

//
function explodeForSignature($parameters) {
	ksort($parameters);
	$ret = '';
	foreach ($parameters as $key => $value) {
		if (is_array($value)) {
			asort($value);
			$ret .= $key.implode('', array_values($value));
		} else {
			$ret .= $key.$value;
		}
	}
	return $ret;
}
?>