#--encofing UTF-8
#Author : Farhad Nadi
#version:399.10.1.0 
import logging as log
from typing import NoReturn
import pandas as pd
import numpy as np
import ast
from os import path
import scann
import zipfile  
import json
import jmespath
import time
from sklearn import preprocessing




#coloredlogs.install(level='INFO')
# FORMAT = '\033[92m%(levelname)s (%(asctime)s):\033[0m\t%(message)s '
FORMAT = '%(levelname)s (%(asctime)s):\t%(message)s '
 
log.basicConfig(level=log.INFO, format=FORMAT)


class cls_NNS_SCANN:
    def __init__(self, aURIdb, jmespath_to_idisrcvec, idx_id=0, idx_isrc=1, idx_vec=2):
        # jmespath_to_row='data.music_tracks[*].[id,isrc,album.albums_genres[*].genre.id|[0]]',
        super().__init__()
        log.info(f'DB location: {aURIdb}')
        
        self.reloadandreindex(aURIdb, jmespath_to_idisrcvec, idx_id, idx_isrc, idx_vec)


        # log.info(self._db_genres)
    def index(self):
        self.index_scann(self.normalize(self.db[self.idx_vec].tolist()))

    def reloadandreindex(self, aURIdb,  jmespath_to_idisrcvec, idx_id=0, idx_isrc=1, idx_vec=2):
        
        self.URIdb = aURIdb
        self.jmespath_to_idisrcvec = jmespath_to_idisrcvec
        self.idx_id = idx_id
        self.idx_isrc = idx_isrc
        self.idx_vec = idx_vec
        self.boldbloaded = False
        self.boldbloaded = self.LoadDB( self.URIdb,  
                                        self.jmespath_to_idisrcvec,
                                        self.idx_id, 
                                        self.idx_isrc, 
                                        self.idx_vec)
        if self.boldbloaded:
            self.index()
        
    
    def normalize(self, veclist):
        log.info(f'Normalizing DB of size {len(veclist)}')
        # return  veclist / np.linalg.norm(veclist, axis=1)[:, np.newaxis]
        x = veclist
        min_max_scaler = preprocessing.MinMaxScaler()
        x_scaled = min_max_scaler.fit_transform(x)
        self.scaled_db = pd.DataFrame(x_scaled)        
        return self.scaled_db


    def index_scann(self, normalized_vector):
        log.info(f'Indexing with SCANN started')
        try:      
            start = time.time()         
            num_samples = normalized_vector.shape[0]
            est_partition_num = (int(np.sqrt(num_samples)))

            if num_samples<20000:# brute force is recommended for small data sets
                self.searcher = scann.scann_ops_pybind.builder(normalized_vector, est_partition_num,'squared_l2').score_brute_force().build()
            else: #for large data sets its recommended to partiotion, score, and reorder
                self.searcher = scann.scann_ops_pybind.builder(normalized_vector, est_partition_num, "squared_l2").tree(
                        num_leaves=est_partition_num, num_leaves_to_search=est_partition_num, training_sample_size=est_partition_num).score_ah(
                            2, anisotropic_quantization_threshold=0.42).reorder(1).build()
            end = time.time()
            log.info(f'databased ({num_samples} samples each of length {normalized_vector.shape[1]}) indexed using SCANN in {end-start:0.2f} seconds.')
            
        except:
            log.error(f'an error occured during indexing process. Verify the input vector and try again.')

    def recommend_by_id(self, anid, top_n):
        # if not self.scaled_db:
        #     self.normalize()

        tmp_vec =  self.scaled_db[self.db[self.idx_id]== anid].values.flatten().tolist() 
        if tmp_vec:
            return self.ret_N_Neighbours(tmp_vec, top_n)
        else:
            log.error(f'Not able to search for the provided Diginava id: {self.idx_id}.')
        
    
    def recommend_by_isrc(self, anisrc, top_n):
        # if not self.scaled_db:
        #     self.normalize()
        tmp_vec =  self.scaled_db[self.db[self.idx_isrc]== anisrc].values.flatten().tolist()#[self.idx_vec]
        if tmp_vec:
            return self.ret_N_Neighbours(tmp_vec, top_n)
        else:
            log.error(f'Not able to search for the provided ISRC: {self.idx_id}.')
        
    
    def ret_N_Neighbours(self, query_vectorslist, top_n):
        # neighbors, distances = self.searcher.search(query_vectorslist)
        qlist = [query_vectorslist]
        neighbors, distances = self.searcher.search_batched(qlist, leaves_to_search=2,
                                               pre_reorder_num_neighbors=2, final_num_neighbors=top_n)
  
        idlists=[]
 
        for idx in neighbors.flatten().tolist():
            tmplst = self.db.iloc[idx].tolist()
            idlists.append([tmplst[self.idx_id], tmplst[self.idx_isrc]])
        return idlists
    
        
    def gethead(self):
        dff = pd.DataFrame(self.db) 
        log.info(dff.head())

        return  ast.literal_eval(dff.head().to_json())
    def LoadDB(self, aURIdb,  jmespath_to_idisrcvec, idx_id, idx_isrc, idx_vec):
        self.idx_id = idx_id
        self.idx_isrc = idx_isrc
        self.idx_vec = idx_vec

        self.jmes_filedpath  = jmespath_to_idisrcvec

        self.URIdb = aURIdb
        res = -1
        #loading db file. It might be a zipped json/json/zipped csv/csv file
        #the input file will be loaded into a pandas data frame

        if not self.URIdb:
            log.warning(f'No DB file is provided.')
        else:
            if  path.exists(self.URIdb):
                if '.zip' in self.URIdb:
                    with zipfile.ZipFile(self.URIdb, "r") as z:
                        log.info(f'loaded zip file:{self.URIdb}')
                        for filename in z.namelist():  
                            log.info(f'zip file extracted: {filename}')
                            f = z.open (filename)                          
                            self.db=pd.DataFrame(jmespath.search(self.jmes_filedpath ,json.loads(ast.literal_eval(json.dumps(f.read().decode('utf8'))))))

                else:
                    f = open(self.URIdb, encoding="utf8")                
                    # self.db =  (json.loads(json.dumps(f.read())))                   
                    
                    jcont = ast.literal_eval(json.dumps(f.read())) 
                    jmres = jmespath.search(self.jmes_filedpath , json.loads(jcont))
                    self.db = pd.DataFrame(jmres)

                    log.info(f'loaded json file: {self.URIdb}')                                              
 
                res = 1
                log.info(f'DB file loaded successfully.\n')        
                     
            else:
                log.warning(f'No DB found.\t-->{self.URIdb}')                

        self.boldbloaded = res
        return res
        
if __name__ == '__main__':
    log.warning('Running from test route.')
    # cls_scann = cls_NNS_SCANN('db/out_bertasservice_artistnames.json', jmespath_to_idisrcvec="[*]")
    cls_scann = cls_NNS_SCANN('db/db.json', jmespath_to_idisrcvec="[].[id,isrc,vec]")
    
    # print((cls_scann.gethead().to_json))
    print(cls_scann.recommend_by_id('1',3))

    # ret=cls_scann.ret_N_Neighbours([[0.50 , 0.25 , 0.50 , 0.666667]], 4)
    # print(ret)

