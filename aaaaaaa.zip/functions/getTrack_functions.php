<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';

//
function get_track($id) {
	
	$id_original = $id;
	$decrypted_id = remove_non_utf8(md5_decrypt($id, MD5_ID_MASTERKEY));
	$constructed_id = explode(':', $decrypted_id);
	$id = $constructed_id[1];
	
	// Check to see if the id has legitimate encrypted endpoint value
	$script_name = basename(__FILE__, '_functions.php');
	$endpoint_name = preg_replace('/(get|send|do|process|redirect|set|unset)/', '', $script_name);
	$process_request = false;
	foreach ( aquired_services() as $service ) {
		if ( ($process_request == 0) && (map_endpoint_to_service($service . $endpoint_name) == $constructed_id[0]) )
		{
			$process_request = true;
		}
	}
	if ( $process_request == 0 )
	{
		echo status_code(400, 'this is not a valid ' . strtolower($endpoint_name) . ' id.');
		exit;
	}
	
	$query = 'http://i-serp.com/fetchTrack.php?id=' . $id;
	@$raw_data = stream_open($query, 'http://i-serp.com/', 'i-serp.com');
	@$data = json_decode($raw_data, true);
	
	if ( @$data["status"] == "error" || empty($data) ) 
	{
		$query = 'http://muism.com/v1/fetchTrack.php?id=' . $id;
		@$raw_data = stream_open($query, 'http://muism.com/', 'muism.com');
		@$data = json_decode($raw_data, true);
			
			if ( @$data["status"] == "error" || empty($data) ) 
			{
				$query = ORIGINALAPI . 'track/get?app_id=' . ORIGINALAPPID . '&t=-526898600' . '&track_id=' . $id;
				@$raw_data = stream_open($query, 'http://www.qobuz.com/', 'www.qobuz.com');
				@$data = json_decode($raw_data, true);
			}
	}
	
	$current_time = time();
	
	if ( !empty($data) && empty($data['status']) )
	{
        @$data_id = checkSafeValue( construct_the_id(QOBUZSERVICE . 'Track', $data["id"]), null );
		@$data_title = hdryn_change_france($data["title"]);
		@$data_work = $data["work"];
			
		@$data_composer = array(
				"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data["composer"]["id"]), null ),
				"name"  => hdryn_change_france($data["composer"]["name"])
			);
			
		@$data_performer = array(
				"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data["performer"]["id"]), null ),
				"name"  => hdryn_change_france($data["performer"]["name"])
			);
			
		@$data_performers = hdryn_change_france($data["performers"]);
		
		@$data_version = $data["version"];
		@$data_copyright = has_copyright_sign(remove_duplicate_copyright($data["copyright"]));
		
		@$data_duration = $data["duration"];
		@$data_media = $data["media_number"];
		@$data_track = $data["track_number"];
		
		@$data_sampling_rate = $data["maximum_sampling_rate"];
		@$data_bit_depth = $data["maximum_bit_depth"];
		@$data_hires = $data["hires"];
		
		@$data_parental_warning = $data["parental_warning"];
		
		@$data_isrc = $data["isrc"];
		
		@$data_purchasable_at = $data["purchasable_at"];
		@$data_streamable_at = $data["streamable_at"];
		@$data_purchasable = $data["purchasable"];
		@$data_streamable = $data["streamable"];
		@$data_previewable = $data["previewable"];
		@$data_sampleable = $data["sampleable"];
		@$data_downloadable = $data["downloadable"];
		@$data_displayable = $data["displayable"];

        @$track_md5_encrypt = construct_the_id(QOBUZSERVICE . 'Track', $data["id"]);
        @$track_md5_encrypt_full = construct_the_id(QOBUZSERVICE . 'FullLengthMP3', $data["id"]);

        $track_can_buy = false;
        $track_can_buy_at = null;
        if ( !is_null($data_streamable_at) )
        {
            $track_can_buy_at = $data_streamable_at;

            if ( $data_streamable_at <= $current_time )
            {
                $track_can_buy = true;
            }
        }

        $track_can_preview = false;
        $track_hls_preview = null;
        if ( $data_sampleable == 1 )
        {
            $track_can_preview = true;
            $track_hls_preview = STREAMSERVER . 'listening/,' . $track_md5_encrypt . 'b.m4a,' . $track_md5_encrypt . 'd.m4a,.urlset/master.m3u8';
        }

        $track_can_subscribe = false;
        $track_hls_subscribe = null;
        if ( !is_null($data_streamable_at) && ($data_purchasable_at <= $current_time) ) //@TODO: Make a better decision
        {
            $track_can_subscribe = true;
            $track_hls_subscribe = FULLSTREAMSERVER . 'cascade/,' . $track_md5_encrypt_full . 'b.m4a,' . $track_md5_encrypt_full . 'd.m4a,.urlset/master.m3u8';
        }

        $track_can_preview = false;
        $track_hls_preview = null;
        if ( $data_sampleable == 1 )
        {
            $track_can_preview = true;
            $track_hls_preview = STREAMSERVER . 'listening/,' . $track_md5_encrypt . 'b.m4a,' . $track_md5_encrypt . 'd.m4a,.urlset/master.m3u8';
        }
		
		$track_can_buy = false;
		$track_can_buy_at = null;
		if ( !is_null($data_streamable_at) )
		{
			$track_can_buy_at = $data_streamable_at;
				
			if ( $track_can_buy_at < $current_time )
			{
				$track_can_buy = true;
			}
		}
			
			@$data_track_album = $data["album"];
			
			@$album_id = checkSafeValue( construct_the_id(QOBUZSERVICE . 'Album', $data_track_album["id"]), null );
            @$album_is_free = (is_free_album($data_track_album["id"]) == true ? true : false);
			@$album_title = hdryn_change_france($data_track_album["title"]);
			@$album_subtitle = $data_track_album["subtitle"];
			@$data_genre_id_1 = $data_track_album["genre"]["path"][0];
			@$data_genre_id_2 = $data_track_album["genre"]["path"][1];
			@$data_genre_id_3 = $data_track_album["genre"]["path"][2];
			@$data_genre_id_4 = $data_track_album["genre"]["path"][3];
			if ( $data_genre_id_1 )
			{
				$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_1), "name"=>ic_genres($data_genre_id_1), "name_fa"=>ic_genres_fa($data_genre_id_1));
			}
			if ( $data_genre_id_2 )
			{
				$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_2), "name"=>ic_genres($data_genre_id_2), "name_fa"=>ic_genres_fa($data_genre_id_2));
			}
			if ( $data_genre_id_3 )
			{
				$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_3), "name"=>ic_genres($data_genre_id_3), "name_fa"=>ic_genres_fa($data_genre_id_3));
			}
			if ( $data_genre_id_4 )
			{
				$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_4), "name"=>ic_genres($data_genre_id_4), "name_fa"=>ic_genres_fa($data_genre_id_4));
			}
			@$album_genre = $genre_array;
			@$album_popularity = 100 * $data_track_album["popularity"];
			@$album_image = array(
					"50"   => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 50 . ':' . $data_track_album["id"]) . '.jpg',
					"230"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 230 . ':' . $data_track_album["id"]) . '.jpg',
					"600"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 600 . ':' . $data_track_album["id"]) . '.jpg',
				);
			@$album_artist = array(
					"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_track_album["artist"]["id"]), null ),
					"name"  => hdryn_change_france($data_track_album["artist"]["name"]),
					"slug"  => make_slug(hdryn_change_france($data_track_album["artist"]["name"])),
					"albums_count"  => $data_track_album["artist"]["albums_count"]  
				);
			@$album_composer = array(
					"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_track_album["composer"]["id"]), null ),
					"name"  => hdryn_change_france($data_track_album["composer"]["name"]),
					"slug"  => make_slug(hdryn_change_france($data_track_album["composer"]["name"])),
					"albums_count"  => $data_track_album["composer"]["albums_count"] 
				);
			@$album_label = array(
					"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Label', $data_track_album["label"]["id"]), null ),
					"name"  => $data_track_album["label"]["name"],
					"slug"  => make_slug(hdryn_change_france($data_track_album["label"]["name"])),
					"albums_count"  => $data_track_album["label"]["albums_count"] 
				);
			@$album_purchasable = $data_track_album['purchasable'];
			@$album_streamable = $data_track_album['streamable'];
			@$album_previewable = $data_track_album['previewable'];
			@$album_sampleable = $data_track_album['sampleable'];
			@$album_downloadable = $data_track_album['downloadable'];
			@$album_displayable = $data_track_album['displayable'];
			@$album_purchasable_at = $data_track_album['purchasable_at'];
			@$album_streamable_at = $data_track_album['streamable_at'];
			@$album_hires = $data_track_album['hires'];
			
			@$album_parental_warning = $data_track_album['parental_warning'];
			
			@$album_technical_specifications = $data_track_album["maximum_technical_specifications"];
			
			@$album_upc = $data_track_album['upc'];
			
			@$album_sampling_rate = $data_track_album['maximum_sampling_rate'];
			@$album_bit_depth = $data_track_album['maximum_bit_depth'];
			@$album_released_at = $data_track_album["released_at"];
			@$album_duration = $data_track_album["duration"];
			
			@$album_media_count = $data_track_album["media_count"];
			@$album_tracks_count = $data_track_album["tracks_count"];
			
			$album_can_preview = false;
			if ( $album_sampleable == 1 )
			{
				$album_can_preview = true;
			}
				
			$album_can_buy = false;
			$album_can_buy_at = null;
			if ( !is_null($album_streamable_at) )
			{
				$album_can_buy_at = $album_streamable_at;
					
				if ( $album_can_buy_at < $current_time )
				{
					$album_can_buy = true;
				}
			}
			
		$album_array = array(
			"id"		  				   => $album_id,
			"title"						   => $album_title,
			"subtitle"					   => (!empty($album_subtitle) ? $album_subtitle : null),
			"image"						   => $album_image,
			"artist"					   => (!empty($album_artist['name']) ? $album_artist : various_artists()),
			"composer"					   => (!empty($album_composer['name']) ? $album_composer : various_artists()),
			"label"						   => (!empty($album_label['name']) ? $album_label : null),
			"genre"						   => $album_genre,
			"media_count"				   => $album_media_count,
			"tracks_count"				   => $album_tracks_count,
			"content_warning"			   => (!empty($album_parental_warning) ? $album_parental_warning : false),
			"upc"						   => (!empty($album_upc) ? $album_upc : null),
			"duration"					   => $album_duration,
			"popularity"				   => $album_popularity,
			"released_at"				   => $album_released_at,
			"can_preview"				   => $album_can_preview,
			"can_buy"					   => $album_can_buy,
			"can_buy_at"				   => $album_can_buy_at,
			"sampling_rate"				   => $album_sampling_rate,
			"bit_depth"				 	   => $album_bit_depth,
			"technical_specifications"	   => $album_technical_specifications,
			"hires"				 		   => $album_hires
		);
			
		$items = array(
			"id"		  				   => $data_id,
			"title"						   => $data_title,
			"work"						   => (!empty($data_work) ? $data_work : null),
			"composer"					   => (!empty($data_composer['name']) ? $data_composer : various_artists()),
			"artist"					   => (!empty($data_performer['name']) ? $data_performer : null),
            "duration"		   			   => $data_duration,
			"performers"				   => $data_performers,
			"album"						   => $album_array,
			"media_number"				   => $data_media,
			"track_number"				   => $data_track,
			"content_warning"			   => (!empty($data_parental_warning) ? $data_parental_warning : false),
            "isrc"						   => (!empty($data_isrc) ? $data_isrc : null),
            "can_preview"				   => $track_can_preview,
            "is_free"					   => $album_is_free, //@TODO: we just provide this by checking if <album> is free, however we need to check individual tracks later
            "preview_url"				   => $track_hls_preview,
            "preview_duration"             => ($album_is_free == true ? (int)$data_duration : ( (int)$data_duration >= 30 ? 30 : (int)$data_duration ) ), //@TODO: if the album is free, set duration to the original duration, else 30
            "subscription_url"			   => $track_hls_subscribe,
            "subscription_duration"        => $data_duration,
            "start_at"                     => 0,
            "end_at"                       => (int)$data_duration,
            "is_segmentation"              => false,
            "force_segmentation"           => false,
            "copyright"					   => (!empty($data_copyright) ? $data_copyright : null),
			"version"					   => $data_version,
			"can_buy"					   => $track_can_buy,
			"can_buy_at"				   => $track_can_buy_at,
			"sampling_rate"				   => $data_sampling_rate,
			"bit_depth"					   => $data_bit_depth,
			"hires"				 		   => $data_hires
		);
			
		unset($genre_array);
		
	} else { // Nothing returned from the server
		echo status_code(404);
		exit;
	}


	@$op_time = $current_time;
	@$op_results = ( !empty($items) ? $items : [] );
	@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
	@$op_url = '';
	
	$export = response_json($op_time, $op_results, $op_right, $op_url);
	// Creating temporary cache file
	temp_creator_on_server( basename(__FILE__, '_functions.php'), $id_original, $export );
	
	return $export;

}

//
function response_json($op_time, $op_results, $op_right, $op_url = ''){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}

?>