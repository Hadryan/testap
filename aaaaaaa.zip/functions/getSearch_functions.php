<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';

//
function get_search($query, $type, $limit, $offset) {
	
	$query_original = $query;
	$edited_query = preg_replace("/ /", "+", ic_normalize($query_original));
		
	$query = 'http://i-serp.com/fetchSearch.php?q=' . $edited_query . '&l=' . $limit . '&o=' . $offset . '&t=' . $type;
	@$raw_data = stream_open($query, 'http://i-serp.com/', 'i-serp.com');
	@$data = json_decode($raw_data, true);
	
	if ( @$data["status"] == "error" || empty($data) ) 
	{
		$query = 'http://muism.com/v1/fetchSearch.php?q=' . $edited_query . '&l=' . $limit . '&o=' . $offset . '&t=' . $type;
		@$raw_data = stream_open($query, 'http://muism.com/', 'muism.com');
		@$data = json_decode($raw_data, true);
			
			if ( @$data["status"] == "error" || empty($data) ) 
			{
				$query = ORIGINALAPI . 'catalog/search?app_id=' . ORIGINALAPPID . '&type=' . $type . '&limit=' . $limit . '&offset=' . $offset .'&query=' . $edited_query;
				@$raw_data = stream_open($query, 'http://www.qobuz.com/', 'www.qobuz.com');
				@$data = json_decode($raw_data, true);
			}
	}

	if ( isset($data['suggestions']) )
	{
		$suggestions_array = isset($data['suggestions'][0]) ? $data['suggestions'] : array($data['suggestions']);
		foreach($suggestions_array as $suggestion) {
			$search_suggestion[] = $suggestion;
		}
		$search_suggestion = array_unique($search_suggestion);
	}

	if ( $type == 'albums' )
	{
		@$parent_response_offset = $data['albums']['offset'];
		@$parent_response_limit = $data['albums']['limit'];
		@$parent_response_total = $data['albums']['total'];
		@$parent_response_items = $data['albums']['items'];
		$current_time = time();
		$reduced_from_total = 0;
		
		// Foreach correction ! http://stackoverflow.com/a/15150384
		$response_array = isset($parent_response_items[0]) ? $parent_response_items : array($parent_response_items);
		foreach($response_array as $itme_num => $data) {
			if ( !empty($data) && empty($data['status']) )
			{
				if ( filter_unwanted_albums($data["id"]) == 1 )
				{
					$reduced_from_total++;
					continue;
					
				} else {
					
					@$data_image = $data["image"]["large"];
					if ( empty($data_image) )
					{
						$data_image = APIENDPOINT . URLVERSION . '/' . 'dot.png';
					}
					@$data_image = image_corrector($data_image);
					@$data_id = $data["id"];
					@$data_title = $data["title"];
					//@$data_slug = $data["slug"]; // We don't want to use the original slug, provided !
					@$data_slug = make_slug(hdryn_change_france($data_title));
				
					@$data_artist = $data["artist"]["name"];
					@$data_artist_id = $data["artist"]["id"];
					@$data_artist_albums_count = $data["artist"]["albums_count"];
					//@$data_artist_slug = $data["artist"]["slug"];
					@$link_artist_slug = make_slug(hdryn_change_france($data_artist)); // Clean slug for artist
				
					@$data_label = $data["label"]["name"];
					@$data_label_id = $data["label"]["id"];
					@$data_label_albums_count = $data["label"]["albums_count"];
					//@$data_label_slug = $data["label"]["slug"];
					@$data_label_slug = make_slug($data_label); // Clean slug for label
				
					@$data_genre_id_1 = $data["genre"]["path"][0];
					@$data_genre_id_2 = $data["genre"]["path"][1];
					@$data_genre_id_3 = $data["genre"]["path"][2];
					@$data_genre_id_4 = $data["genre"]["path"][3];
				
					@$data_copyright = has_copyright_sign(remove_duplicate_copyright($data["copyright"]));
				
					@$data_released = $data["released_at"];
				
					@$data_duration = $data["duration"];
					@$data_media = $data["media_count"];
					@$data_tracks = $data["tracks_count"];
				
					@$data_sampling = $data["maximum_sampling_rate"];
					@$data_depth = $data["maximum_bit_depth"];
				
					@$data_purchasable_at = $data["purchasable_at"];
					@$data_streamable_at = $data["streamable_at"];
					@$data_purchasable = $data["purchasable"];
					@$data_streamable = $data["streamable"];
					@$data_previewable = $data["previewable"];
					@$data_sampleable = $data["sampleable"];
					@$data_downloadable = $data["downloadable"];
					@$data_displayable = $data["displayable"];
				
					@$data_hires = $data["hires"];
				
					@$data_tracks_offset = $data["tracks"]["offset"];
					@$data_tracks_limit = $data["tracks"]["limit"];
					@$data_tracks_total = $data["tracks"]["total"];
					@$data_items = $data["tracks"]["items"];
				
				
					if ( $data_genre_id_1 )
					{
						$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_1), "name"=>ic_genres($data_genre_id_1), "name_fa"=>ic_genres_fa($data_genre_id_1));
					}
					if ( $data_genre_id_2 )
					{
						$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_2), "name"=>ic_genres($data_genre_id_2), "name_fa"=>ic_genres_fa($data_genre_id_2));
					}
					if ( $data_genre_id_3 )
					{
						$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_3), "name"=>ic_genres($data_genre_id_3), "name_fa"=>ic_genres_fa($data_genre_id_3));
					}
					if ( $data_genre_id_4 )
					{
						$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_4), "name"=>ic_genres($data_genre_id_4), "name_fa"=>ic_genres_fa($data_genre_id_4));
					}
					
					@$album_id = checkSafeValue( construct_the_id(QOBUZSERVICE . 'Album', $data_id), null );
					@$album_title = hdryn_change_france($data_title);
					@$album_genre = $genre_array;
					@$album_image = array(
							"50"   => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 50 . ':' . $data_id) . '.jpg',
							"230"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 230 . ':' . $data_id) . '.jpg',
							"600"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 600 . ':' . $data_id) . '.jpg',
						);
					@$album_composer = array(
							"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_comp_id), null ),
							"name"  => hdryn_change_france($data_composer),
							"slug"  => $link_comp_slug,
							"albums_count"  => $data_comp_albums_count 
						);
					@$album_artist = array(
							"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_artist_id), null ),
							"name"  => hdryn_change_france($data_artist),
							"slug"  => $link_artist_slug,
							"albums_count"  => $data_artist_albums_count 
						);
					@$album_label = array(
							"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Label', $data_label_id), null ),
							"name"  => $data_label,
							"slug"  => $data_label_slug,
							"albums_count"  => $data_label_albums_count 
						);
					@$album_released_at = $data_released;
					@$album_duration = $data_duration;
					@$album_media_count = $data_media;
					@$album_tracks_count = $data_tracks;
					@$album_sampling_rate = $data_sampling;
					@$album_bit_depth = $data_depth;
					@$album_hires = $data_hires;
					@$album_url = SITEURL . 'album' . '/' . $album_id . '-' . $data_slug . ($link_artist_slug ? '-' . $link_artist_slug : '') . ($link_comp_slug ? '-' . $link_comp_slug : '') . '.html';
					
					$album_can_preview = false;
					if ( $data_sampleable == 1 )
					{
						$album_can_preview = true;
					}
					
					$album_can_buy = false;
					$album_can_buy_at = null;
					if ( !is_null($data_streamable_at) )
					{
						$album_can_buy_at = $data_streamable_at;
						
						if ( $album_can_buy_at < $current_time )
						{
							$album_can_buy = true;
						}
					}
				
					@$album_tracks_offset = $data_tracks_offset;
					@$album_tracks_limit = $data_tracks_limit;
					@$album_tracks_total = $data_tracks_total;
				
				
					$items[] = array(
						"id"		  				   => $album_id,
						"title"						   => $album_title,
						"image"						   => $album_image,
						"artist"					   => (!empty($album_artist['name']) ? $album_artist : various_artists()),
						"label"						   => (!empty($album_label['name']) ? $album_label : null),
						"genre"						   => $album_genre,
						"url"				 		   => $album_url,
						"media_count"				   => $album_media_count,
						"tracks_count"				   => $album_tracks_count,
						"duration"					   => $album_duration,
						"released_at"				   => $album_released_at,
						"can_preview"				   => $album_can_preview,
						"can_buy"					   => $album_can_buy,
						"can_buy_at"				   => $album_can_buy_at,
						"sampling_rate"				   => $album_sampling_rate,
						"bit_depth"				 	   => $album_bit_depth,
						"hires"				 		   => $album_hires
					);
				
					unset($genre_array);
					unset($album_genre);
				}
				
			} elseif ( !empty($search_suggestion) ) { // we don't have data but we have search_suggestion
				// Nothing is here, but this gives us the search_suggestion node
				
			} else { // Nothing returned from the server
				echo status_code(404);
				exit;
			}
		}
	
	} elseif ( $type == 'tracks' )
	{
		@$parent_response_offset = $data['tracks']['offset'];
		@$parent_response_limit = $data['tracks']['limit'];
		@$parent_response_total = $data['tracks']['total'];
		@$parent_response_items = $data['tracks']['items'];
		$current_time = time();
		$reduced_from_total = 0;
		
		// Foreach correction ! http://stackoverflow.com/a/15150384
		$response_array = isset($parent_response_items[0]) ? $parent_response_items : array($parent_response_items);
		foreach($response_array as $itme_num => $data) {
			if ( !empty($data) && empty($data['status']) )
			{
				if ( filter_unwanted_albums($data["album"]["id"]) == 1 )
				{
					$reduced_from_total++;
					continue;
					
				} else {
					
					@$data_id = checkSafeValue( construct_the_id(QOBUZSERVICE . 'Track', $data["id"]), null );
					@$data_title = hdryn_change_france($data["title"]);
					
					@$data_composer = array(
							"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data["composer"]["id"]), null ),
							"name"  => hdryn_change_france($data["composer"]["name"])
						);
				
					@$data_performer = array(
							"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data["performer"]["id"]), null ),
							"name"  => hdryn_change_france($data["performer"]["name"])
						);
				
					@$data_performers = hdryn_change_france($data["performers"]);
				
					@$data_version = $data["version"];
					@$data_copyright = has_copyright_sign(remove_duplicate_copyright($data["copyright"]));
				
					@$data_duration = $data["duration"];
					@$data_media = $data["media_number"];
					@$data_track = $data["track_number"];
				
					@$data_sampling_rate = $data["maximum_sampling_rate"];
					@$data_bit_depth = $data["maximum_bit_depth"];
					@$data_hires = $data["hires"];
				
					@$data_hires = $data["hires"];
				
					@$data_purchasable_at = $data["purchasable_at"];
					@$data_streamable_at = $data["streamable_at"];
					@$data_purchasable = $data["purchasable"];
					@$data_streamable = $data["streamable"];
					@$data_previewable = $data["previewable"];
					@$data_sampleable = $data["sampleable"];
					@$data_downloadable = $data["downloadable"];
					@$data_displayable = $data["displayable"];
				
					$track_can_preview = false;
					if ( $data_sampleable == 1 )
					{
						$track_can_preview = true;
					}
				
					$track_can_buy = false;
					$track_can_buy_at = null;
					if ( !is_null($data_streamable_at) )
					{
						$track_can_buy_at = $data_streamable_at;
					
						if ( $track_can_buy_at < $current_time )
						{
							$track_can_buy = true;
						}
					}
					
						@$data_track_album = $data["album"];
						
						@$album_id = checkSafeValue( construct_the_id(QOBUZSERVICE . 'Album', $data_track_album["id"]), null );
						@$album_title = hdryn_change_france($data_track_album["title"]);
						@$data_genre_id_1 = $data_track_album["genre"]["path"][0];
						@$data_genre_id_2 = $data_track_album["genre"]["path"][1];
						@$data_genre_id_3 = $data_track_album["genre"]["path"][2];
						@$data_genre_id_4 = $data_track_album["genre"]["path"][3];
						if ( $data_genre_id_1 )
						{
							$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_1), "name"=>ic_genres($data_genre_id_1), "name_fa"=>ic_genres_fa($data_genre_id_1));
						}
						if ( $data_genre_id_2 )
						{
							$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_2), "name"=>ic_genres($data_genre_id_2), "name_fa"=>ic_genres_fa($data_genre_id_2));
						}
						if ( $data_genre_id_3 )
						{
							$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_3), "name"=>ic_genres($data_genre_id_3), "name_fa"=>ic_genres_fa($data_genre_id_3));
						}
						if ( $data_genre_id_4 )
						{
							$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_4), "name"=>ic_genres($data_genre_id_4), "name_fa"=>ic_genres_fa($data_genre_id_4));
						}
						@$album_genre = $genre_array;
						@$album_popularity = 100 * $data_track_album["popularity"];
						@$album_image = array(
							"50"   => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 50 . ':' . $data_track_album["id"]) . '.jpg',
							"230"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 230 . ':' . $data_track_album["id"]) . '.jpg',
							"600"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 600 . ':' . $data_track_album["id"]) . '.jpg',
						);
						@$album_artist = array(
							"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_track_album["artist"]["id"]), null ),
							"name"  => hdryn_change_france($data_track_album["artist"]["name"]),
							"slug"  => make_slug(hdryn_change_france($data_track_album["artist"]["name"])),
							"albums_count"  => $data_track_album["artist"]["albums_count"]  
						);
						@$album_label = array(
							"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Label', $data_track_album["label"]["id"]), null ),
							"name"  => $data_track_album["label"]["name"],
							"slug"  => make_slug(hdryn_change_france($data_track_album["label"]["name"])),
							"albums_count"  => $data_track_album["label"]["albums_count"] 
						);
						@$album_purchasable = $data_track_album['purchasable'];
						@$album_streamable = $data_track_album['streamable'];
						@$album_previewable = $data_track_album['previewable'];
						@$album_sampleable = $data_track_album['sampleable'];
						@$album_downloadable = $data_track_album['downloadable'];
						@$album_displayable = $data_track_album['displayable'];
						@$album_purchasable_at = $data_track_album['purchasable_at'];
						@$album_streamable_at = $data_track_album['streamable_at'];
						@$album_hires = $data_track_album['hires'];
						
						@$album_sampling_rate = $data_track_album['maximum_sampling_rate'];
						@$album_bit_depth = $data_track_album['maximum_bit_depth'];
						@$album_released_at = $data_track_album["released_at"];
						@$album_duration = $data_track_album["duration"];
						
						@$album_media_count = $data_track_album["media_count"];
						@$album_tracks_count = $data_track_album["tracks_count"];
						
						$album_can_preview = false;
						if ( $album_sampleable == 1 )
						{
							$album_can_preview = true;
						}
						
						$album_can_buy = false;
						$album_can_buy_at = null;
						if ( !is_null($album_streamable_at) )
						{
							$album_can_buy_at = $album_streamable_at;
						
							if ( $album_can_buy_at < $current_time )
							{
								$album_can_buy = true;
							}
						}
				
					$album_array = array(
						"id"		  				   => $album_id,
						"title"						   => $album_title,
						"image"						   => $album_image,
						"artist"					   => (!empty($album_artist['name']) ? $album_artist : various_artists()),
						"label"						   => (!empty($album_label['name']) ? $album_label : null),
						"genre"						   => $album_genre,
						"media_count"				   => $album_media_count,
						"tracks_count"				   => $album_tracks_count,
						"duration"					   => $album_duration,
						"popularity"				   => $album_popularity,
						"released_at"				   => $album_released_at,
						"can_preview"				   => $album_can_preview,
						"can_buy"					   => $album_can_buy,
						"can_buy_at"				   => $album_can_buy_at,
						"sampling_rate"				   => $album_sampling_rate,
						"bit_depth"				 	   => $album_bit_depth,
						"hires"				 		   => $album_hires
					);
				
					$items[] = array(
						"id"		  				   => $data_id,
						"title"						   => $data_title,
						"composer"					   => (!empty($data_composer['name']) ? $data_composer : various_artists()),
						"artist"					   => (!empty($data_performer['name']) ? $data_performer : null),
						"performers"				   => $data_performers,
						"album"						   => $album_array,
						"media_number"				   => $data_media,
						"track_number"				   => $data_track,
						"duration"					   => $data_duration,
						"copyright"					   => $data_copyright,
						"version"					   => $data_version,
						"can_preview"				   => $track_can_preview,
						"can_buy"					   => $track_can_buy,
						"can_buy_at"				   => $track_can_buy_at,
						"sampling_rate"				   => $data_sampling_rate,
						"bit_depth"					   => $data_bit_depth,
						"hires"				 		   => $data_hires
					);
				
					unset($genre_array);
				}
				
			} else { // Nothing returned from the server
				echo status_code(404);
				exit;
			}
		}
		
	} elseif ( $type == 'artists' )
	{
		@$parent_response_offset = $data['artists']['offset'];
		@$parent_response_limit = $data['artists']['limit'];
		@$parent_response_total = $data['artists']['total'];
		@$parent_response_items = $data['artists']['items'];
		$current_time = time();
		$reduced_from_total = 0;
		
		// Foreach correction ! http://stackoverflow.com/a/15150384
		$response_array = isset($parent_response_items[0]) ? $parent_response_items : array($parent_response_items);
		foreach($response_array as $itme_num => $data) {
			if ( !empty($data) && empty($data['status']) )
			{
				@$data_id = $data["id"];
				@$data_name = $data["name"];
				@$data_slug = make_slug($data["name"]);
				@$data_albums_count = $data["albums_count"];
				if ( !empty($data['picture']) )
				{
					$artist_image_small_id = get_artist_image_id(parse_url($data['picture'], PHP_URL_PATH))[1];
					$artist_image_small_ext = get_artist_image_id(parse_url($data['picture'], PHP_URL_PATH))[2];
					$artist_image_medium_id = get_artist_image_id(parse_url($data['picture'], PHP_URL_PATH))[1];
					$artist_image_medium_ext = get_artist_image_id(parse_url($data['picture'], PHP_URL_PATH))[2];
					$artist_image_large_id = get_artist_image_id(parse_url($data['picture'], PHP_URL_PATH))[1];
					$artist_image_large_ext = get_artist_image_id(parse_url($data['picture'], PHP_URL_PATH))[2];
					$_image_small = 'small' . ':' . $artist_image_small_id;
					$_image_medium = 'medium' . ':' . $artist_image_medium_id;
					$_image_large = 'large' . ':' . $artist_image_large_id;
					$dedicated_image = true;
					$the_color = mt_rand(0,360);
					@$response_image = array(
							"34"			 => checkSafeValue(ASSETSSERVER . 'artists/' . construct_the_id(QOBUZSERVICE . 'ArtistsImage', $_image_small) . '.' . $artist_image_small_ext, avatar_generator($data_name, 34, 'false', '0.43', 'true', $the_color)),
							"64"			 => checkSafeValue(ASSETSSERVER . 'artists/' . construct_the_id(QOBUZSERVICE . 'ArtistsImage', $_image_small) . '.' . $artist_image_small_ext, avatar_generator($data_name, 64, 'false', '0.43', 'true', $the_color)),
							"174"			 => checkSafeValue(ASSETSSERVER . 'artists/' . construct_the_id(QOBUZSERVICE . 'ArtistsImage', $_image_medium) . '.' . $artist_image_medium_ext, avatar_generator($data_name, 174, 'false', '0.43', 'true', $the_color)),
							"300"			 => checkSafeValue(ASSETSSERVER . 'artists/' . construct_the_id(QOBUZSERVICE . 'ArtistsImage', $_image_medium) . '.' . $artist_image_medium_ext, avatar_generator($data_name, 300, 'false', '0.43', 'true', $the_color)),
							"600"			 => checkSafeValue(ASSETSSERVER . 'artists/' . construct_the_id(QOBUZSERVICE . 'ArtistsImage', $_image_large) . '.' . $artist_image_large_ext, avatar_generator($data_name, 512, 'false', '0.43', 'true', $the_color)),
							"full"			 => checkSafeValue(ASSETSSERVER . 'artists/' . construct_the_id(QOBUZSERVICE . 'ArtistsImage', $_image_large) . '.' . $artist_image_large_ext, avatar_generator($data_name, 512, 'false', '0.43', 'true', $the_color)),
						);
				} else 
				{
					$dedicated_image = false;
					$the_color = mt_rand(0,360);
					@$response_image = array(
							"34"			 => avatar_generator($data_name, 34, 'false', '0.43', 'true', $the_color),
							"64"			 => avatar_generator($data_name, 64, 'false', '0.43', 'true', $the_color),
							"174"			 => avatar_generator($data_name, 174, 'false', '0.43', 'true', $the_color),
							"300"			 => avatar_generator($data_name, 300, 'false', '0.43', 'true', $the_color),
							"600"			 => avatar_generator($data_name, 512, 'false', '0.43', 'true', $the_color),
							"full"			 => avatar_generator($data_name, 512, 'false', '0.43', 'true', $the_color),
						);
				}
				
				$items[] = array(
					"id"			   => checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_id), null ),
					"name"			   => hdryn_change_france($data_name),
					"slug"			   => $data_slug,
					"albums_count"	   => $data_albums_count,
					"image"			   => $response_image,
					"dedicated_image"  => $dedicated_image
				);
				
			} else { // Nothing returned from the server
				echo status_code(404);
				exit;
			}
		}
		
	} elseif ( $type == 'playlists' ) // TODO: playlists search
	{
		echo status_code(404);
		exit;
	}


	@$op_time = $current_time;
	@$op_query = $query_original;
	@$op_suggestion = $search_suggestion;
	@$op_offset = $parent_response_offset;
	@$op_limit = $parent_response_limit;
	@$op_total = $parent_response_total - $reduced_from_total;
	@$op_more_results = has_more_results($op_offset, $op_limit, $parent_response_total);
	@$op_results = ( !empty($items) ? $items : [] );
	@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
	@$op_url = '';
	
	$export = response_json($op_time, $op_query, $op_suggestion, $op_offset, $op_limit, $op_total, $op_results, $op_right, $op_url, $op_more_results);
	//// Creating temporary cache file
	//temp_creator_on_server( basename(__FILE__, '_functions.php'), $op_service, $op_category, checkSafeValue($build_json['message'], $op_this), $export, $op_id );
	
	return $export;

}

//
function response_json($op_time, $op_query, $op_suggestion = '', $op_offset, $op_limit, $op_total, $op_results, $op_right, $op_url = '', $op_more_results){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'				=> basename(__FILE__, '_functions.php'),
				'timestamp'				=> $op_time,
				'query'					=> $op_query,
				'offset'				=> $op_offset,
				'limit'					=> $op_limit,
				'total'					=> $op_total,
				'more_results'			=> $op_more_results,
				'results'				=> $op_results,
				'copyright'				=> $op_right,
				//'url'					=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}
?>