<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';


//
function do_update( $user_firstname = '', $user_lastname = '', $user_password = '', $user_gender = '', $user_avatar = '', $user_birthday = '', $user_email = '', $user_mobile = '', $app_id, $user_token, $session_id ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			if ( $user_firstname == '' && $user_lastname == '' && $user_password == '' && $user_gender == '' && $user_avatar == '' && $user_birthday == '' && $user_email == '' && $user_mobile == '' )
			{
				echo status_code(402); // everything was empty in the update-request, nothing to update
				exit;
				
			} else {
                $current_time = time();
				$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY_PER_USER . '/users' . '/' . $user_objectId;
				$database_headers = array(
					"Content-Type: application/json",
					"user-token: " . $session_id_decrypted,
				);				
				$data_update = array();
				if ($user_firstname != ''){
					$data_update['user_firstname'] = $user_firstname;
				}
				if ($user_lastname != ''){
					$data_update['user_lastname'] = $user_lastname;
				}
				if ($user_password != ''){
					$data_update['password'] = $user_password;
				}
				if ($user_gender != ''){
					$data_update['user_gender'] = $user_gender;
				}
				if ($user_avatar != ''){
					$data_update['user_avatar'] = $user_avatar;
				}
				if ($user_birthday != ''){
					$data_update['user_birthday'] = $user_birthday;
					$data_update['user_birthday_updated'] = time() * 1000;
				}
				if ($user_email != ''){
					$data_update['user_email'] = $user_email;
				}
				if ($user_mobile != ''){
					$data_update['user_mobile'] = $user_mobile;
				}
					
				try {
					@$database_results = updateBackendlessRequest( $database_url, $database_headers, json_encode($data_update) );
					@$database_results_array = json_decode($database_results, true);
					
				} catch (Exception $ex){
					sendError( 'doUserUpdate', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
				}
				
				if ( !empty($database_results_array) )
				{
					if ( empty($database_results_array['code']) )
					{
						if ( $database_results_array['user_is_active'] == 1  )
						{
							$items = array(
                                'code'		   => ERROR_1000,
                                'message'	   => array(
                                    'en'		   => array(
                                        'content'	   => 'Update was done successfully',
                                    ),
                                    'fa'		   => array(
                                        'content'	   => 'بروزرسانی با موفقیت انجام شد',
                                    ),
                                ),
								'user_login'			  => $database_results_array['user_login'],
								'user_lastseen'			  => floor($database_results_array['lastLogin'] / 1000),
								'user_firstname'		  => $database_results_array['user_firstname'],
								'user_lastname'			  => $database_results_array['user_lastname'],
								'user_email'			  => $database_results_array['user_email'],
								'user_mobile'			  => $database_results_array['user_mobile'],
								'user_gender'			  => $database_results_array['user_gender'],
								'user_avatar'			  => $database_results_array['user_avatar'],
								'user_birthday'			  => $database_results_array['user_birthday'],
								'user_unique_code'		  => convert_small_uuid_with_hash($database_results_array['user_unique_code']),
								'user_download_total'	  => $database_results_array['user_total_spent'],
								'user_download_quota'	  => counter_to_packages($database_results_array['user_total_purchases'], encrypt($database_results_array['objectId']), $database_results_array['user_subscription']),
								'user_is_verified'		  => ($database_results_array['user_is_verified'] == 1) ? true : false,
								'user_token'			  => encrypt($database_results_array['objectId']),
								'created'				  => round($database_results_array['created'] / 1000),
								'updated'				  => round($database_results_array['updated'] / 1000),
							);
							
							
							@$op_user = $items;
							@$op_time = $current_time;
							@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
							
							$export = response_json($op_user, $op_time, $op_right);

                        } else { // We are providing this error by hand to uniform it like other responses

                            @$results = array(
                                'code'		   => ERROR_3090,
                                'message'	   => array(
                                    'en'		   => array(
                                        'content'	   => 'User account is disabled',
                                    ),
                                    'fa'		   => array(
                                        'content'	   => 'کاربر غیرفعال شده است',
                                    ),
                                )
                            );

                            @$op_user = $results;
                            @$op_time = $current_time;
                            @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                            $export = response_json($op_user, $op_time, $op_right);

                        }

                    } elseif ( $database_results_array['code'] == 3000 ) {

                        @$results = array(
                            'code'		   => ERROR_3000,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'User cannot be logged in',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'کاربر نمی‌تواند وارد سیستم شود',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3002 ) {

                        @$results = array(
                            'code'		   => ERROR_3002,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'User is already logged in from another device',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'کاربر با دستگاه دیگری وارد سیستم شده است',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3003 ) {

                        @$results = array(
                            'code'		   => ERROR_3003,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Invalid login or password',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'نام کاربری یا رمز عبور اشتباه است',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3006 ) {

                        @$results = array(
                            'code'		   => ERROR_3006,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Login or password is missing',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'نام کاربری یا رمز عبور وارد نشده است',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3016 ) {

                        @$results = array(
                            'code'		   => ERROR_3016,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Cannot use provided parameters',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'اطلاعات قابل قبول نمی‌باشد',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3017 ) {

                        @$results = array(
                            'code'		   => ERROR_3017,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'User property already exists',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'اطلاعات کاربری وجود دارد',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3018 ) {

                        @$results = array(
                            'code'		   => ERROR_3018,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'User identity already exists',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'کاربری با این شناسه وجود دارد',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3020 ) {

                        @$results = array(
                            'code'		   => ERROR_3020,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to find the user',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'چنین کاربری وجود ندارد',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3021 ) {

                        @$results = array(
                            'code'		   => ERROR_3021,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to register user',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'ثبت نام قابل انجام نیست',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3022 ) {

                        @$results = array(
                            'code'		   => ERROR_3022,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to login user',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'ورود به سیستم قابل انجام نیست',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3023 ) {

                        @$results = array(
                            'code'		   => ERROR_3023,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to logout user',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'خروج از سیستم قابل انجام نیست',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3024 ) {

                        @$results = array(
                            'code'		   => ERROR_3024,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to update user account',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'تغییر اطلاعات کاربری قابل انجام نیست',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3025 ) {

                        @$results = array(
                            'code'		   => ERROR_3025,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to perform password recovery',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'بازیابی رمز عبور قابل انجام نیست',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3026 ) {

                        @$results = array(
                            'code'		   => ERROR_3026,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to retrieve user properties',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'مشخصات کاربری قابل دریافت نیست',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3027 ) {

                        @$results = array(
                            'code'		   => ERROR_3027,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unknown error',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'خطای ناشناخته',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3028 ) {

                        @$results = array(
                            'code'		   => ERROR_3028,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to update user',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'اطلاعات کاربر بروزرسانی نشد',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3029 ) {

                        @$results = array(
                            'code'		   => ERROR_3029,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to update user',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'اطلاعات کاربری بروزرسانی نشد',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3030 ) {

                        @$results = array(
                            'code'		   => ERROR_3030,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to update user',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'اطلاعات کاربری بروزرسانی نشد',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3031 ) {

                        @$results = array(
                            'code'		   => ERROR_3031,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to update user',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'اطلاعات کاربری بروزرسانی نشد',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3032 ) {

                        @$results = array(
                            'code'		   => ERROR_3032,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to update user',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'اطلاعات کاربری بروزرسانی نشد',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3033 ) {

                        @$results = array(
                            'code'		   => ERROR_3033,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'User with the same identity already exists',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'کاربری با این نام در سیستم وجود دارد',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3034 ) {

                        @$results = array(
                            'code'		   => ERROR_3034,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'User login is disabled',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'ورود به سیستم محدود شده است',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3036 ) {

                        @$results = array(
                            'code'		   => ERROR_3036,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'User account is locked out due to too many failed requests',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'حساب کاربری به علت درخواست‌های اشتباه موقتاً مسدود شده است',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3039 ) {

                        @$results = array(
                            'code'		   => ERROR_3039,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'This name cannot be chosen',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'این نام غیرقابل انتخاب است',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3040 ) {

                        @$results = array(
                            'code'		   => ERROR_3040,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Email address is in the wrong format',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'آدرس ایمیل اشتباه است',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3041 ) {

                        @$results = array(
                            'code'		   => ERROR_3041,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Unable to register user',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'ثبت نام غیرقابل انجام است',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3044 ) {

                        @$results = array(
                            'code'		   => ERROR_3044,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Multiple login limit for the user account',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'ورود کاربر موقتاً غیرفعال گردید',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3048 ) {

                        @$results = array(
                            'code'		   => ERROR_3048,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Session timeout',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'ورود منقضی شده است',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3050 ) {

                        @$results = array(
                            'code'		   => ERROR_3050,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Password should be string',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'رمز عبور فقط باید شامل حروف و علائم باشد',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3055 ) {

                        @$results = array(
                            'code'		   => ERROR_3055,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Incorrect password',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'رمز عبور اشتباه است',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3057 ) {

                        @$results = array(
                            'code'		   => ERROR_3057,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'Could not find user',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'کاربری با این مشخصات یافت نشد',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } elseif ( $database_results_array['code'] == 3090 ) {

                        @$results = array(
                            'code'		   => ERROR_3090,
                            'message'	   => array(
                                'en'		   => array(
                                    'content'	   => 'User account is disabled',
                                ),
                                'fa'		   => array(
                                    'content'	   => 'کاربر غیرفعال شده است',
                                ),
                            )
                        );

                        @$op_user = $results;
                        @$op_time = $current_time;
                        @$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';

                        $export = response_json($op_user, $op_time, $op_right);

                    } else {
                        //$reason = $database_results_array['code']; // TODO: Change in production
                        //echo status_code(400, $reason);
                        $reason = $database_results_array['message'];
                        echo status_code(400, $reason);
                        exit;
                    }

                    return $export;

                } else {
					echo status_code(412);
					exit;
				}
				
			}
		
		} else {
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_user, $op_time, $op_right){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'results'		=> $op_user,
				'copyright'		=> $op_right,
			)
		)
	);
	
	return json_encode($output);
}

?>