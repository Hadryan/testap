<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';


//
function delete_favorites_by_id( $favorite_id, $favorite_type, $app_id, $user_token, $session_id ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$id_original = $id;
			$decrypted_favorite_id = remove_non_utf8(md5_decrypt($favorite_id, MD5_ID_MASTERKEY));
			$constructed_favorite_id = explode(':', $decrypted_favorite_id);
			$favorite_id = $constructed_favorite_id[1];
			
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY_PER_USER . '/data/bulk/Users_Favorites';
			$database_headers = array(
				"Content-Type: application/json",
				"user-token: " . $session_id_decrypted,
			);
			$database_where = '?where=favorite_id' . urlencode("='" . $provided_user_id . '_' . $favorite_id . "'") . urlencode(" AND favorite_type='" . $favorite_type . "'") . '&sortBy=created%20desc';
			
			try {
				@$database_results = deleteBackendlessRequest( $database_url . $database_where, $database_headers);
				@$database_results_array = json_decode($database_results, true);
			
			} catch (Exception $ex){
				sendError( 'unsetUserFavorites', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , favorite_id: ' . @$favorite_id . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}	
			
			if ( !empty($database_results_array) )
			{
				if ( empty($database_results_array['code']) )
				{
					return status_code(201);
					
				} else {
					echo status_code(412);
					exit;
				}
			
			} else { // Nothing returned from the server [@MINWANG: Changed the status code from 404 to 200, even if the result is empty 12.07.17 04:11 AM ]
				echo status_code(200, 'successfully processed');
				exit;
			}
		
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function delete_favorites_by_object( $object_id, $app_id, $user_token, $session_id ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		@$object_id_decrypted = decrypt($object_id);
		
		if ( $user_objectId == $provided_user_id )
		{
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY_PER_USER . '/data/Users_Favorites' . '/' . $object_id_decrypted;
			$database_headers = array(
				"Content-Type: application/json",
				"user-token: " . $session_id_decrypted,
			);
			
			try {
				@$database_results = deleteBackendlessRequest( $database_url, $database_headers);
				@$database_results_array = json_decode($database_results, true);
			
			} catch (Exception $ex){
				sendError( 'unsetUserFavorites', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , data_objectId: ' . @$object_id_decrypted . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}		
			
			if ( !empty($database_results_array) )
			{
				if ( empty($database_results_array['code']) )
				{
					return status_code(201);
					
				} else {
					echo status_code(412);
					exit;
				}
			
			} else { // Nothing returned from the server
				echo status_code(404);
				exit;
			}
		
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json(){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'success',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> json_decode('{}')
		)
	);
	
	return json_encode($output);
}

?>