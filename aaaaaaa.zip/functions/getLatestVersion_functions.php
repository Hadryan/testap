<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';

//
function get_latest_version( $app_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		$apk_built_date = DateTime::createFromFormat('d.m.y h:i a', APKBUILTDATE);
		$apk_built_time = $apk_built_date->getTimestamp();
		
		$items[] = array(
			'timestamp'		=> 		$apk_built_time,
			'token'			=> 		IPINFOTOKEN, // token for ipinfo.io token
			'may_update'	=> 		APKMAYUPDATE,
			'version'		=> 		APKVERSION,
			'code'			=> 		APKCODE,
			'hash'			=> 		strtolower(APKHASH),
			'url'			=> 		APKANDROIDURL . 'diginava-' . APKVERSION . '.apk', // real APK package
			'zip'			=> 		APKANDROIDURL . 'diginava-' . APKVERSION . '.zip', // fake APK package with zip extension
			'platform'		=> 		APKANDROID,
		);

        $custom_button = array(
            'id'                        => construct_the_id(DIGINAVASERVICE . 'InternalId', custom_button_types('Login') . ':' . '00000000-0000-0000-0000-000000000000'), // Service_id:System_id:User_token
            'layout_id'                 => (int) 1, // App layout
            'action'                    => 'Login',
            'type'                      => 'Login',
            'is_expandable'             => (bool) true,
            'can_view'                  => (bool) true,
            'can_view_after'            => null,
            'can_view_before'           => null,
            'view_count'                => 100000,
            'gradient_start'            => '#' . '1E31A1',
            'gradient_end'              => '#' . '2A4DB8',
            'gradient_degree'           => (int) 45,
            'gradient_opacity'          => (int) 89 / 100,
            'text_color'                => '#' . 'FFFFFF',
            'name'                      => array(
                'en'		                => array(
                    'content'	                => 'Login / Register',
                ),
                'fa'		                => array(
                    'content'	                => 'ورود / ثبت نام',
                ),
            ),
            'description'                      => array(
                'en'		                => array(
                    'content'	                => 'Please login to your account or register for a new account',
                ),
                'fa'		                => array(
                    'content'	                => 'لطفاً به سیستم وارد شوید و یا ثبت نام نمایید.',
                ),
            ),
            'small_image' 			   => 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg',
            'large_image' 			   => 'https://assets.s3.ir-thr-at1.arvanstorage.com/button1.jpg',
        );

        $listening_plans[] = array(
            'plan_id'                 => (int) 1, // Streaming
            'name'                      => array(
                'en'		                => array(
                    'content'	                => 'Streaming',
                ),
                'fa'		                => array(
                    'content'	                => 'استریم',
                ),
            ),
            'description'                      => array(
                'en'		                => array(
                    'content'	                => 'This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan.',
                ),
                'fa'		                => array(
                    'content'	                => 'این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است.',
                ),
            ),
        );
        $listening_plans[] = array(
            'plan_id'                 => (int) 2, // Local
            'name'                      => array(
                'en'		                => array(
                    'content'	                => 'Diginava',
                ),
                'fa'		                => array(
                    'content'	                => 'دیجی‌نوا',
                ),
            ),
            'description'                      => array(
                'en'		                => array(
                    'content'	                => 'This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan.',
                ),
                'fa'		                => array(
                    'content'	                => 'این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است.',
                ),
            ),
        );
        $listening_plans[] = array(
            'plan_id'                 => (int) 3, // Previewing
            'name'                      => array(
                'en'		                => array(
                    'content'	                => 'Preview',
                ),
                'fa'		                => array(
                    'content'	                => 'نمونه',
                ),
            ),
            'description'                      => array(
                'en'		                => array(
                    'content'	                => 'This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan.',
                ),
                'fa'		                => array(
                    'content'	                => 'این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است.',
                ),
            ),
        );
        $listening_plans[] = array(
            'plan_id'                 => (int) 4, // Free
            'name'                      => array(
                'en'		                => array(
                    'content'	                => 'Free',
                ),
                'fa'		                => array(
                    'content'	                => 'رایگان',
                ),
            ),
            'description'                      => array(
                'en'		                => array(
                    'content'	                => 'This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan.',
                ),
                'fa'		                => array(
                    'content'	                => 'این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است.',
                ),
            ),
        );
        $listening_plans[] = array(
            'plan_id'                 => (int) 5, // Expired
            'name'                      => array(
                'en'		                => array(
                    'content'	                => 'Expired',
                ),
                'fa'		                => array(
                    'content'	                => 'منقضی',
                ),
            ),
            'description'                      => array(
                'en'		                => array(
                    'content'	                => 'This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan.',
                ),
                'fa'		                => array(
                    'content'	                => 'این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است.',
                ),
            ),
        );
        $listening_plans[] = array(
            'plan_id'                 => (int) 6, // System
            'name'                      => array(
                'en'		                => array(
                    'content'	                => 'System',
                ),
                'fa'		                => array(
                    'content'	                => 'سیستم',
                ),
            ),
            'description'                      => array(
                'en'		                => array(
                    'content'	                => 'This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan.',
                ),
                'fa'		                => array(
                    'content'	                => 'این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است.',
                ),
            ),
        );
        $listening_plans[] = array(
            'plan_id'                 => (int) 7, // Preparing
            'name'                      => array(
                'en'		                => array(
                    'content'	                => 'Preparing',
                ),
                'fa'		                => array(
                    'content'	                => 'به‌زودی',
                ),
            ),
            'description'                      => array(
                'en'		                => array(
                    'content'	                => 'This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan. This is the streaming listening plan.',
                ),
                'fa'		                => array(
                    'content'	                => 'این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است. این طرح شنیداری استریم است.',
                ),
            ),
        );

        $bubble_genres[] = array(
            'id'                 => '33b24cc8f02281d29af7d85c9c43b357',
            'weight'             => 0.5,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Folk',
                ),
                'fa'		          => array(
                    'content'	           => 'فولک',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/79sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '9810a57ad75374f37b424fa4a27fb345',
            'weight'             => 2,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Electronic Music',
                ),
                'fa'		          => array(
                    'content'	           => 'موسیقی الکترونیک',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/80sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '1a145c024570dde4ad7c34935b4d31cb',
            'weight'             => 1.421,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Minimal Music',
                ),
                'fa'		          => array(
                    'content'	           => 'موسیقی مینیمال',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/82sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => 'ee1825b303657529fc2f0d7ed0d2df13',
            'weight'             => 1,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Lieder',
                ),
                'fa'		          => array(
                    'content'	           => 'لید',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/83sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '9a3a598b7bfa8cd1b11eae472e0355af',
            'weight'             => 1.37,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Art Songs',
                ),
                'fa'		          => array(
                    'content'	           => 'آواز‌های هنری',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/85sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => 'bd3fa378cf916398da0c3de7d2e383e5',
            'weight'             => 0.75,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Concertos',
                ),
                'fa'		          => array(
                    'content'	           => 'کنسرتو',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/88sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '99adcce8ab0567688fa3ea894c0a09dc',
            'weight'             => 1.23,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Chamber Music',
                ),
                'fa'		          => array(
                    'content'	           => 'موسیقی مجلسی',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/90sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '1ade931f19e30af9721a6ec346bded49',
            'weight'             => 1,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Quartets',
                ),
                'fa'		          => array(
                    'content'	           => 'کوارتت',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/105sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '5fee3f28c69a7c37b3c29ad6c84d4e96',
            'weight'             => 1,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Choral Music',
                ),
                'fa'		          => array(
                    'content'	           => 'موسیقی کُرال',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/107sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '32149dacbafeb30cf4708a6e44e00b37',
            'weight'             => 1.25,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Sacred Cantatas',
                ),
                'fa'		          => array(
                    'content'	           => 'کانتات مذهبی',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/107sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '9564e4ac9e614b8890b8bbc60dcdb960',
            'weight'             => 1.56,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Downtempo',
                ),
                'fa'		          => array(
                    'content'	           => 'موسیقی آرام',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/108sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '754f59369e9220ceb27673d4483b745f',
            'weight'             => 0.6,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Relaxation',
                ),
                'fa'		          => array(
                    'content'	           => 'آرامش بخش',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/111sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => 'edb9a6d3e9176c447b2730cfc822354b',
            'weight'             => 0.8,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Jazz',
                ),
                'fa'		          => array(
                    'content'	           => 'جَز',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/112sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '76646b51af1830200b566ff37950c31f',
            'weight'             => 0.75,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Classical Music',
                ),
                'fa'		          => array(
                    'content'	           => 'موسیقی کلاسیک',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/113sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '77982b809e77d7de87f51b46e3c22b34',
            'weight'             => 0.89,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Quintets',
                ),
                'fa'		          => array(
                    'content'	           => 'کوئینتت',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/114sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => 'e51fce6f3226ed521e5a60c45326873f',
            'weight'             => 1,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Duets',
                ),
                'fa'		          => array(
                    'content'	           => 'دوئت',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/115sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '4e1fdd6a01803ab1c0b254ac3e089861',
            'weight'             => 0.78,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Trios',
                ),
                'fa'		          => array(
                    'content'	           => 'تریو',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/116sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '1b04049e16559acd485fa08a34fc09e2',
            'weight'             => 1.16,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Solo Violin',
                ),
                'fa'		          => array(
                    'content'	           => 'ویولن',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/128sz5.jpg'
        );
        $bubble_genres[] = array(
            'id'                 => '9150c80bd4e52d62a5b26b30f9c4b386',
            'weight'             => 1.42,
            'name'               => array(
                'en'		          => array(
                    'content'	           => 'Symphonies',
                ),
                'fa'		          => array(
                    'content'	           => 'سمفونی',
                ),
            ),
            'image'               => 'https://audio.s3.ir-thr-at1.arvanstorage.com/134sz5.jpg'
        );

        // Dummy track @TODO: change it to diginava presentation album/track
        $album_genre[] = array('id' => '76646b51af1830200b566ff37950c31f', 'name' => 'Classical Music', 'name_fa' => 'موسیقی کلاسیک');
        $album_image = array(
            '50' => 'https://assets.diginava.site/covers/20ac07092ad0fa8d0a772717696508887c34332907d81d8e4fca2d6d4e35b5f5.jpg',
            '230' => 'https://assets.diginava.site/covers/1ad034d181ac39234c22a3cff014271798c9690e25734c7c9d964158543a462b.jpg',
            '600' => 'https://assets.diginava.site/covers/9c5aef864fdcac21296ccf083ade0c54b5764b9d6c15caca9268b87b2e97d339.jpg',
        );
        $album_array = array(
            "id"		  				   => 'ed3c5c0c35351a01e32fbe7516aaf5a0',
            "title"						   => 'Mountains',
            "subtitle"					   => 'Sten Erland Hermundstad',
            "image"						   => $album_image,
            "color"						   => '#A0A0A0',
            "artist"					   => array('id' => 'b9f6499202f6cbe96b4906e0ba6b9172', 'name' => 'Sten Erland Hermundstad', 'slug' => 'sten-erland-hermundstad', 'albums_count' => 8),
            "composer"					   => array('id' => 'b9f6499202f6cbe96b4906e0ba6b9172', 'name' => 'Sten Erland Hermundstad', 'slug' => 'sten-erland-hermundstad', 'albums_count' => 8),
            "label"						   => array('id' => '143e412d6cfbce0454b540a74343057e', 'name' => '1631 Recordings', 'slug' => '1631-recordings', 'albums_count' => 361),
            "genre"						   => $album_genre,
            "media_count"				   => 1,
            "tracks_count"				   => 10,
            "content_warning"			   => false,
            "upc"						   => '0002894815376',
            "duration"					   => 1860,
            "popularity"				   => 0,
            "released_at"				   => 1457650800,
            "can_preview"				   => true,
            "can_buy"					   => true,
            "can_buy_at"				   => 1584313200,
            "sampling_rate"				   => 44.1,
            "bit_depth"				 	   => 16,
            "technical_specifications"	   => null,
            "hires"				 		   => false
        );

        $track_item = array(
            "id"		  				   => '98198675adee4721b8d3294c04e86fba',
            "title"						   => 'Hermundstad: Family\'s Song',
            "work"						   => null,
            "composer"					   => array('id' => 'b9f6499202f6cbe96b4906e0ba6b9172', 'name' => 'Sten Erland Hermundstad'),
            "artist"					   => array('id' => 'b9f6499202f6cbe96b4906e0ba6b9172', 'name' => 'Sten Erland Hermundstad'),
            "duration"		   			   => 181,
            "performers"				   => 'Sten Erland Hermundstad, Piano, MainArtist, AssociatedPerformer, ComposerLyricist',
            "album"						   => $album_array,
            "media_number"				   => 1,
            "track_number"				   => 3,
            "content_warning"			   => false,
            "isrc"						   => 'SEYTP1606103',
            "can_preview"				   => true,
            "is_free"					   => true, //@TODO: we just provide this by checking if <album> is free, however we need to check individual tracks later
            "preview_url"				   => 'http://previewing.diginava.site/listening/,98198675adee4721b8d3294c04e86fbab.m4a,98198675adee4721b8d3294c04e86fbad.m4a,.urlset/master.m3u8',
            "preview_duration"             => 181,
            "subscription_url"			   => 'http://previewing.diginava.site/listening/,98198675adee4721b8d3294c04e86fbab.m4a,98198675adee4721b8d3294c04e86fbad.m4a,.urlset/master.m3u8',
            "subscription_duration"        => 181,
            "start_at"                     => 0,
            "end_at"                       => 181,
            "is_segmentation"              => false,
            "force_segmentation"           => false,
            "copyright"					   => '©℗ 2017 1631 Recordings AB',
            "version"					   => null,
            "can_buy"					   => true,
            "can_buy_at"				   => 1584313200,
            "sampling_rate"				   => 44.1,
            "bit_depth"					   => 16,
            "hires"				 		   => false
        );
		
		@$op_time = $current_time;
		@$op_custom_button = $custom_button;
		@$op_listening_plans = $listening_plans;
		@$op_track_item = $track_item;
		@$op_bubble_genres = $bubble_genres;
		@$op_results = $items;
		@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
			
		$export = response_json($op_time, $op_results, $op_custom_button, $op_track_item, $op_bubble_genres, $op_listening_plans, $op_right);
		// Creating temporary cache file
		temp_creator_on_server( basename(__FILE__, '_functions.php'), 'latestversion', $export );
		
		
		return $export;
	
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_time, $op_results, $op_custom_button, $op_track_item, $op_bubble_genres, $op_listening_plans, $op_right){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		        => basename(__FILE__, '_functions.php'),
				'timestamp'		        => $op_time,
				'results'		        => $op_results,
				//'whats_diginava'		=> json_decode('{"en":{"title":"What\'s diginava","description":"this is description","text1":"Lorem Ipsum is simply dummy text of the printing and  typesetting industry. Lorem Ipsum has been the industry\'s standard dummy  text ever since the 1500s, when an unknown printer took a galley of  type and scrambled it to make a type specimen book.\n only five centuries, but also the leap into electronic typesetting,  remaining essentially unchanged. It was popularised in the 1960s with  the release of Letraset sheets containing Lorem Ipsum passages, and more  recently with desktop publishing software like Aldus PageMaker  including versions of Lorem Ipsum.","image1":"https://i.picsum.photos/id/1/750/300.jpg","text2":"Contrary to popular belief, Lorem Ipsum is not simply random text. It  has roots in a piece of classical Latin literature from 45 BC, making  it over 2000 years old. Richard McClintock, a Latin professor at  Hampden-Sydney College in Virginia, looked up one of the more obscure  Latin words, consectetur, from a Lorem Ipsum passage, and going through  the cites of the word in classical literature, discovered the  undoubtable source. <em>Lorem Ipsum</em> comes from sections 1.10.32 and 1.10.33  of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by  Cicero, written in 45 BC. This book is a treatise on the theory of  ethics, very popular during the Renaissance. The first line of Lorem  Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section  1.10.32. The standard chunk of Lorem Ipsum used since the 1500s is  reproduced below for those interested. <i>Sections 1.10.32</i> and 1.10.33  from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in  their exact original form, accompanied by English versions from the 1914  translation by H. Rackham.","image2":"https://i.picsum.photos/id/3/500/500.jpg","text3":"","image3":"","text4":"There are many variations of passages of Lorem Ipsum available, but the  majority have suffered alteration in some form, by injected humour, or  randomised words which don\'t look even slightly believable. If you are  going to use a passage of Lorem Ipsum, you need to be sure there isn\'t  anything embarrassing hidden in the middle of text. All the Lorem Ipsum  generators on the Internet tend to repeat predefined chunks as  necessary, making this the first true generator on the Internet. It uses  a dictionary of over 200 Latin words, combined with a handful of model  sentence structures, to generate Lorem Ipsum which looks reasonable. The  generated Lorem Ipsum is therefore always free from repetition,  injected humour, or non-characteristic words etc.","image4":"","text5":"It is a long established fact that a reader will be distracted  by the readable content of a page when looking at its layout. The point  of using Lorem Ipsum is that it has a more-or-less normal distribution  of letters, as opposed to using \'Content here, content here\', making it  look like readable English. Many desktop publishing packages and web  page editors now use Lorem Ipsum as their default model text, and a  search for \'lorem ipsum\' will uncover many web sites still in their  infancy. Various versions have evolved over the years, sometimes by  accident, sometimes on purpose (injected humour and the like).  ","image5":"https://i.picsum.photos/id/5/300/750.jpg"},"fa":{"title":"دیجی‌نوا چیست؟","description":"توضیحات","text1":"لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت بیشتری را برای <i>طراحان رایانه</i> ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها و شرایط سخت تایپ به پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.","image1":"https://i.picsum.photos/id/1/750/300.jpg","text2":"لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی </b> و فرهنگ پیشرو در <b>زبان فارسی ایجاد کرد. در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها و شرایط سخت تایپ به پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد. \n لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها و شرایط سخت تایپ به پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.","image2":"https://i.picsum.photos/id/3/500/500.jpg","text3":"","image3":"","text4":"لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت بیشتری را برای <em>طراحان رایانه</em> ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها و شرایط سخت تایپ به پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.","image4":"","text5":"لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها و شرایط سخت تایپ به پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.","image5":"https://i.picsum.photos/id/5/300/750.jpg"}}'),
				'whats_diginava'		=> json_decode('{"en":{"title":"What\'s diginava","description":"this is description","text1":"Text will be available soon!","image1":"","text2":"","image2":"","text3":"","image3":"","text4":"","image4":"","text5":"","image5":""},"fa":{"title":"دیجی‌نوا چیست؟","description":"توضیحات","text1":"متن به زودی افزوده خواهد شد!","image1":"","text2":"","image2":"","text3":"","image3":"","text4":"","image4":"","text5":"","image5":""}}'),
				'main_custom_button'	=> $op_custom_button,
				'listening_plans'       => $op_listening_plans,
				'presentation_track'	=> $op_track_item,
				'bubble_genres'	        => $op_bubble_genres,
				'copyright'		        => $op_right,
				//'url'		            => $op_url,
			)
		)
	);
	
	return json_encode($output);
}

?>