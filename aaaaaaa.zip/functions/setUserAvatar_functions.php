<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';

define("AWS_ACCESS_KEY_ID",				"AKIAWLALLVYRND4DDZ5O");
define("AWS_SECRET_ACCESS_KEY",			"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");
define("BUCKET_ASSETS",					"assets.diginava.com");

use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;

//
function send_user_avatar( $user_image, $app_id, $user_token, $session_id ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			if( preg_match("/^data:image\/(?<extension>(?:png|gif|bmp|jpg|jpeg));base64,(?<image>.+)$/", $user_image, $matchings) )
			{
				$image_data = base64_decode($matchings['image']);
				$extension = $matchings['extension'];
				$filename = md5_encrypt(strtolower(preg_replace('/-/', '', $user_objectId)), MD5_ID_MASTERKEY);
			
				if($extension == 'jpeg') $extension = 'jpeg';
				if($extension == 'JPEG') $extension = 'jpeg';
				if($extension == 'JPG') $extension = 'jpg';
				if($extension == 'GIF') $extension = 'gif';
				if($extension == 'BMP') $extension = 'bmp';
				if($extension == 'PNG') $extension = 'png';
				
				switch($extension){
					case 'bmp': $content_type = "image/bmp"; break;
					case 'gif':  $content_type = "image/gif"; break;
					case 'jpg':  $content_type = "image/jpeg"; break;
					case 'jpeg':  $content_type = "image/jpeg"; break;
					case 'png':  $content_type = "image/png"; break;
					default   : $content_type = "image/jpeg";
				}
				
				$upload_name = "users/avatars/" . $filename . '.' . $extension;
					
				$s3 = new Aws\S3\S3Client([
					'version' => 'latest',
					'region'  => 'eu-west-3',
					"signature"=> 'v4',
					'credentials' => [
						'key' => AWS_ACCESS_KEY_ID,
						'secret' => AWS_SECRET_ACCESS_KEY
					]
				]);
				
				$options = array('ContentType' => $content_type, 'CacheControl' => 'public,max-age=604800', 'StorageClass' => 'INTELLIGENT_TIERING');
				try {
					$upload = $s3->upload(BUCKET_ASSETS, $upload_name, $image_data, 'public-read', array('params' => $options) );
					$avatar_url = $upload->get('ObjectURL');
					
				} catch (Exception $ex) {
					
					echo status_code(422);
					exit;
				}
				
				if ( !empty($avatar_url) )
				{
					$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY_PER_USER . '/users' . '/' . $user_objectId;
					$database_headers = array(
						"Content-Type: application/json",
						"user-token: " . $session_id_decrypted,
					);				
					$data_update = array();
					$avatar_url = preg_replace('/s3.eu-west-3.amazonaws.com\//', '', $avatar_url);
					$data_update['user_avatar'] = $avatar_url . '?t=' . time(); // We need this for refreshing cached images
					
					try {
						@$database_results = updateBackendlessRequest( $database_url, $database_headers, json_encode($data_update) );
						@$database_results_array = json_decode($database_results, true);
						
					} catch (Exception $ex){
						sendError( 'setUserAvatar', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
					}
					
					
					if ( !empty($database_results_array) )
					{
						if ( empty($database_results_array['code']) )
						{
							if ( $database_results_array['user_is_active'] == 1  )
							{
								$object_ids = explode_unique_id($database_results_array['objectId']);
								$items = array(
									'user_login'			  => $database_results_array['user_login'],
									'user_lastseen'			  => floor($database_results_array['lastLogin'] / 1000),
									'user_firstname'		  => $database_results_array['user_firstname'],
									'user_lastname'			  => $database_results_array['user_lastname'],
									'user_email'			  => $database_results_array['user_email'],
									'user_mobile'			  => $database_results_array['user_mobile'],
									'user_gender'			  => $database_results_array['user_gender'],
									'user_avatar'			  => $database_results_array['user_avatar'],
									'user_birthday'			  => $database_results_array['user_birthday'],
									'user_unique_code'		  => convert_small_uuid_with_hash($database_results_array['user_unique_code']),
									'user_download_total'	  => $database_results_array['user_total_spent'],
									'user_download_quota'	  => counter_to_packages($database_results_array['user_total_purchases'], encrypt($database_results_array['objectId']), $database_results_array['user_subscription']),
									'user_is_verified'		  => ($database_results_array['user_is_verified'] == 1) ? true : false,
									'user_token'			  => encrypt($database_results_array['objectId']),
									'created'				  => round($database_results_array['created'] / 1000),
									'updated'				  => round($database_results_array['updated'] / 1000),
								);
								
								
								@$op_user = $items;
								@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
								
								$export = response_json($op_user, $op_right);			
								return $export;
							
							} else {
								echo status_code(403, 'user is disabled!');
								exit;
							}
						
						} else {
							$reason = $database_results_array['code'];
							echo status_code(400, $reason);
							exit;
						}
							
					} else {
						echo status_code(412);
						exit;
					}
					
				}
				
			}
		
		} else {
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_user, $op_right){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> time(),
				'results'		=> $op_user,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}
?>