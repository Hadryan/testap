<?php

// General
define("ERROR_1000", 					1000); // Operation was done successfully!

// Registration Errors
define("ERROR_3000", 					3000); // User cannot be logged in
define("ERROR_3002", 					3002); // User is already logged in from another device
define("ERROR_3003", 					3003); // Invalid login or password
define("ERROR_3004", 					3004); // Wrong social identity for user account
define("ERROR_3005", 					3005); // Missing parameter
define("ERROR_3006", 					3006); // Login or password is missing
define("ERROR_3007", 					3007); // Unable to logout
define("ERROR_3009", 					3009); // User registration is disabled for the application
define("ERROR_3010", 					3010); // User registration has an unknown property and dynamic properties are disabled!
define("ERROR_3011", 					3011); // Missing "password" property
define("ERROR_3012", 					3012); // Required property is missing
define("ERROR_3013", 					3013); // Missing value for the identity property
define("ERROR_3014", 					3014); // External registration failed with an error.
define("ERROR_3015", 					3015); // Missing parameter
define("ERROR_3016", 					3016); // Cannot use provided parameters
define("ERROR_3017", 					3017); // User property already exists
define("ERROR_3018", 					3018); // User identity already exists
define("ERROR_3019", 					3019); // Missing parameter
define("ERROR_3020", 					3020); // Cannot perform password recovery. Unable to find the user
define("ERROR_3021", 					3021); // Unable to register user
define("ERROR_3022", 					3022); // Unable to login user
define("ERROR_3023", 					3023); // Unable to logout user
define("ERROR_3024", 					3024); // Unable to update user account
define("ERROR_3025", 					3025); // Unable to perform password recovery
define("ERROR_3026", 					3026); // Unable to retrieve user properties
define("ERROR_3027", 					3027); // Unknown error
define("ERROR_3028", 					3028); // Unable to update user. User should be logged in
define("ERROR_3029", 					3029); // Unable to update user
define("ERROR_3030", 					3030); // Unable to update user
define("ERROR_3031", 					3031); // Unable to update user
define("ERROR_3032", 					3032); // Unable to update user
define("ERROR_3033", 					3033); // User with the same identity already exists
define("ERROR_3034", 					3034); // User login is disabled
define("ERROR_3036", 					3036); // User account is locked out due to too many failed requests
define("ERROR_3038", 					3038); // Missing application-id or collection of properties for the registering user
define("ERROR_3039", 					3039); // Property "id" cannot be used in the registration call
define("ERROR_3040", 					3040); // Email address is in the wrong format
define("ERROR_3041", 					3041); // Unable to register user. Missing required
define("ERROR_3043", 					3043); // Duplicate properties in the registration request
define("ERROR_3044", 					3044); // Unable to login. Multiple login limit for the user account
define("ERROR_3045", 					3045); // Unable to update user. Required fields are empty
define("ERROR_3048", 					3048); // Session timeout
define("ERROR_3050", 					3050); // Password should be string
define("ERROR_3051", 					3051); // Confirmation failed
define("ERROR_3052", 					3052); // External authentication failed
define("ERROR_3053", 					3053); // External authentication failed
define("ERROR_3054", 					3054); // Unable to register user. External registration failed
define("ERROR_3055", 					3055); // Incorrect password
define("ERROR_3057", 					3057); // Could not find user
define("ERROR_3060", 					3060); // Could not approve social account
define("ERROR_3063", 					3063); // The number of characters exceeds the limit
define("ERROR_3064", 					3064); // Could not get user properties
define("ERROR_3071", 					3071); // Could not create
define("ERROR_3072", 					3072); // Social user cannot use password
define("ERROR_3073", 					3073); // Could not change user property
define("ERROR_3075", 					3075); // Cannot request password restoration for social account user
define("ERROR_3080", 					3080); // Wrong or unsupported authorized user redirect URL
define("ERROR_3082", 					3082); // You must confirm email address
define("ERROR_3087", 					3087); // Unable to login. User email is not confirmed
define("ERROR_3090", 					3090); // User account is disabled
define("ERROR_3091", 					3091); // Session timeout
define("ERROR_3092", 					3092); // User already activated
define("ERROR_3096", 					3096); // Identity for social user cannot be changed
define("ERROR_3097", 					3097); // First login by social user
define("ERROR_3101", 					3101); // Password recovery is disabled
define("ERROR_3102", 					3102); // User has already confirmed the email address
define("ERROR_3104", 					3104); // Unable to send email confirmation

// SMS Related
define("ERROR_4001", 					4001); // Maximum number of SMS verification codes already sent during last 30 minutes, Please take a break!
define("ERROR_4002", 					4002); // Verification code is incorrect!
define("ERROR_4003", 					4003); // Mobile number is changed during verification process!
define("ERROR_4004", 					4004); // Mobile number already in use!

// Promotion Errors
define("ERROR_5001", 					5001); // Promotion code is not active
define("ERROR_5002", 					5002); // Promotion code is no longer available
define("ERROR_5003", 					5003); // Promotion code is expired
define("ERROR_5004", 					5004); // You don't have permission to access the resource
define("ERROR_5005", 					5005); // Invalid promotion code
define("ERROR_5006", 					5006); // You already used this promotion

// Reference Errors
define("ERROR_6001", 					6001); // Invalid reference code

define("ERROR_8000", 					8000); // Property value exceeds the length limit

define("ERROR_9000", 					9000); // Session Expired, please login again
define("ERROR_9001", 					9001); // Error adding to database!

// https://stackoverflow.com/a/42845201 Can be used for dynamic error handling




	
		
	
		
	
		









?>