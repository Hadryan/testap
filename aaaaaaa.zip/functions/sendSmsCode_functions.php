<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';
// Asynchronous request
require dirname(__FILE__) . '/library/vendor/autoload.php';
use mpyw\Co\Co;
use mpyw\Co\CURLException;

//
function curl_async_put($url, array $options = [], $user_token = '')
{
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	}

	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "PUT",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_post($url, array $headers = [], array $data = [], array $options = [])
{
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => json_encode($data),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_get($url, array $options = [], $user_token = '')
{
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	};
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function get_sms_for_current_user( $mobile, $user_token, $session_id, $request_ts, $now ) {

	if ( defined('AllowToAccessGetAudioFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$sms_verification_code = mt_rand(10001, 99999);
			$sms_maximum_retry = 6;
			$sms_allowed_retry = $sms_maximum_retry - 1;
			$sms_headers = array(
				"Content-Type: application/json",
			);
			
			$data_previous_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/SMS_Codes';
			$data_previous_headers = array(
				"Content-Type: application/json",
				"Accept: application/json"
			);
			$data_previous_where = '?where=ownerId' . urlencode("='" . $user_objectId . "'") . rawurlencode(' AND mobile_id LIKE \'%') . $mobile . rawurlencode('%\' AND try_id < ') . $sms_maximum_retry . rawurlencode(' AND created > ') . (( $now * 1000 ) - (30 * 60 * 1000 /*30 mins*/)) . '&pageSize=1' . '&sortBy=created%20desc';
			
			try {
				@$data_previous_results = getBackendlessResponse( $data_previous_url, $data_previous_headers, $data_previous_where );
				@$data_previous_results_array = json_decode($data_previous_results, true);
					
			} catch (Exception $ex){
				sendError( 'SMS_Codes_Previous', 'error', (string)$ex->getCode(), $ex->getMessage(), 'mobile_id: ' . $mobile . ' , app_id: ' . $app_id . ' and time: ' . time() );
			}
			
			
			if ( empty(json_decode($data_previous_results, true)['code']) )
			{
				$try_id = $data_previous_results_array[0]['try_id'];
				if ( $try_id == $sms_allowed_retry ) // Already sent maximum verification codes during last 30 minutes !
				{
					@$results = array(
						'code'		   => ERROR_4001,
						'message'	   => 'Maximum number of SMS verification codes already sent.',
					);
					
					@$op_time = $now;
					@$op_results = $results;
					@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
					@$op_url = '';
					
					$export = response_json($op_url, $op_time, $op_right, $op_results);
					
				} elseif ( $try_id && is_numeric($try_id) ) {
					
					$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users'; // If there is any one else with the same mobile, the process should be halted!
					$database_headers = array(
						"Content-Type: application/json",
					);
					$database_where = '?where=user_mobile' . rawurlencode(" LIKE '%" . $mobile . "' AND user_is_verified=1") . '&pageSize=1'; // Special query arrangement: user_mobile LIKE '%9125556677' AND user_is_verified=1
					
					try {
						@$database_results = getBackendlessResponse( $database_url, $database_headers, $database_where );
						@$database_results_array = json_decode($database_results, true);
						
					} catch (Exception $ex){
						sendError( 'snedSmsCode_mobileExists', 'error', (string)$ex->getCode(), $ex->getMessage(), 'object_id: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
					}
					
					if ( empty($database_results_array) )
					{
						$from = sms_send_number();
						$app_name = APP_FARSI_NAME;
						@$code_id = $data_previous_results_array[0]['code_id'];
						$sms_headers = array(
							"Content-Type: application/json",
						);
						$sms_text = '2K7ZiNi0INii2YXYr9uM2K8gOgraqdivINiq2KfbjNuM2K8g2LTZhdinINiv2LEg2KfZvtmE24zaqduM2LTZhiDYr9uM2KzbjCDZhtmI2KcgOgo='; // Welcome to Diginava
						$sms_message = urlencode(base64_decode($sms_text)) . $code_id;
						
						@$send_operation = Co::wait([
								
							"0" => function () use ($code_id, $mobile, $from, $sms_headers, $app_name, $sms_message) {
								$input_data = array(
									'verification-code'	=> $code_id,
								);
								//$content = (yield send_sms_with_pattern( 'fbat9pf80q', $from, $mobile, $input_data ));
								$content = (yield send_sms_with_rayganSMS( $mobile, $sms_message ));
								//yield Co::RETURN_WITH =>$content; // PHP 5.6
								return $content; // PHP 7+
							},
								
							"1" => function () use ($try_id, $code_id, $mobile, $from, $sms_headers, $user_objectId) {
								$post_data = array(
									'ownerId'		=>		$user_objectId,
									'mobile_id'		=>		$mobile,
									'code_id'		=>		(int)$code_id,
									'try_id'		=>		(int)$try_id + 1,
								);
								$content = (yield curl_async_post('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/SMS_Codes', $sms_headers, $post_data, []));
								//yield Co::RETURN_WITH =>$content; // PHP 5.6
								return $content; // PHP 7+
							},
								
						]);
							
						@$send_operation_array = json_decode($send_operation[1], true);
							
						if ( !empty($send_operation_array) && empty($send_operation_array['code']) )
						{
							$created_try_id = $send_operation_array['try_id'];
							$created_from = $from;
								
							@$results = array(
								'line'			=> $from,
								'try'			=> $created_try_id,
								'code'			=> ERROR_1000,
								'message'		=> 'Verification code is issued',
								'user_token'	=> encrypt($user_objectId),
							);
							
							@$op_time = $now;
							@$op_results = $results;
							@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
							@$op_url = '';
								
							$export = response_json($op_url, $op_time, $op_right, $op_results);
							
						}
					
					} else { // Number already exists in the database
						
						@$results = array(
							'code'			=> ERROR_4004,
							'message'		=> 'Mobile number already in use',
						);
						
						@$op_time = $now;
						@$op_results = $results;
						@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
						@$op_url = '';
							
						$export = response_json($op_url, $op_time, $op_right, $op_results);
					}
					
				} else {
					
					$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users'; // If there is any one else with the same mobile, the process should be halted!
					$database_headers = array(
						"Content-Type: application/json",
					);
					$database_where = '?where=user_mobile' . rawurlencode(" LIKE '%" . $mobile . "' AND user_is_verified=1") . '&pageSize=1'; // Special query arrangement: user_mobile LIKE '%9125556677' AND user_is_verified=1
					
					try {
						@$database_results = getBackendlessResponse( $database_url, $database_headers, $database_where );
						@$database_results_array = json_decode($database_results, true);
						
					} catch (Exception $ex){
						sendError( 'snedSmsCode_mobileExists', 'error', (string)$ex->getCode(), $ex->getMessage(), 'object_id: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
					}
					
					if ( empty($database_results_array) )
					{
						$from = sms_send_number();
						$app_name = APP_FARSI_NAME;
						$sms_headers = array(
							"Content-Type: application/json",
						);
						$sms_text = '2K7ZiNi0INii2YXYr9uM2K8gOgraqdivINiq2KfbjNuM2K8g2LTZhdinINiv2LEg2KfZvtmE24zaqduM2LTZhiDYr9uM2KzbjCDZhtmI2KcgOgo='; // Welcome to Diginava
						$sms_message = urlencode(base64_decode($sms_text)) . $sms_verification_code;
							
						@$send_operation = Co::wait([
								
							"0" => function () use ($sms_verification_code, $mobile, $from, $sms_headers, $app_name, $sms_message) {
								$input_data = array(
									'verification-code'	=> $sms_verification_code,
								);
								//$content = (yield send_sms_with_pattern( 'fbat9pf80q', $from, $mobile, $input_data ));
								$content = (yield send_sms_with_rayganSMS( $mobile, $sms_message ));
								//yield Co::RETURN_WITH =>$content; // PHP 5.6
								return $content; // PHP 7+
							},
								
							"1" => function () use ($try_id, $sms_verification_code, $mobile, $from, $sms_headers, $user_objectId) {
								$post_data = array(
									'ownerId'		=>		$user_objectId,
									'mobile_id'		=>		$mobile,
									'code_id'		=>		(int)$sms_verification_code,
									'try_id'		=>		(int)$try_id + 1,
								);
								$content = (yield curl_async_post('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/SMS_Codes', $sms_headers, $post_data, []));
								//yield Co::RETURN_WITH =>$content; // PHP 5.6
								return $content; // PHP 7+
							},
								
						]);
							
						@$send_operation_array = json_decode($send_operation[1], true);
									
						if ( !empty($send_operation_array) && empty($send_operation_array['code']) )
						{
							$created_try_id = $send_operation_array['try_id'];
							$created_from = $from;
								
							@$results = array(
								'line'			=> $from,
								'try'	 		=> $created_try_id,
								'code'			=> ERROR_1000,
								'message'		=> 'Verification code is issued',
								'user_token'	=>	encrypt($user_objectId),
							);
							
							@$op_time = $now;
							@$op_results = $results;
							@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
							@$op_url = '';
								
							$export = response_json($op_url, $op_time, $op_right, $op_results);
							
						}
						
					} else { // Number already exists in the database
						
						@$results = array(
							'code'			=> ERROR_4004,
							'message'		=> 'Mobile number already in use',
						);
							
						@$op_time = $now;
						@$op_results = $results;
						@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
						@$op_url = '';
						
						$export = response_json($op_url, $op_time, $op_right, $op_results);
					}
				}
				
				return $export;
				
			} else { // There is an error updating database
				echo status_code(403);
				exit;
			}
		
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
	
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_url, $op_time, $op_right, $op_results){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}

?>