function upsertAlbum (message) {
    const url = `https://api.diginava.com/${message.version}/getAlbum/${message.id}`
    return url
}

module.exports = {
    upsertAlbum
}
