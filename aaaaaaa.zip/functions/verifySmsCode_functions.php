<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';
// Asynchronous request
require dirname(__FILE__) . '/library/vendor/autoload.php';
use mpyw\Co\Co;
use mpyw\Co\CURLException;

//
function curl_async_put($url, array $options = [], $user_token = '') {
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	}

	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "PUT",
		CURLOPT_POSTFIELDS => json_encode($options),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_post($url, array $headers = [], array $data = [], array $options = []){
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => json_encode($data),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_patch($url, array $headers = [], array $data = [], array $options = []){
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "PATCH",
		CURLOPT_POSTFIELDS => json_encode($data),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_get($url, array $options = [], $user_token = ''){
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	};
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function verify_sms_for_current_user( $mobile, $code, $user_token, $session_id, $app_id, $now ) {

	if ( defined('AllowToAccessGetAudioFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$data_previous_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/SMS_Codes';
			$data_previous_headers = array(
				"Content-Type: application/json",
				"Accept: application/json"
			);
			$data_previous_where = '?where=' . rawurlencode('ownerId=\'') . $user_objectId . rawurlencode('\' AND created > ') . (( $now * 1000 ) - (30 * 60 * 1000 /*30 mins*/)) . '&pageSize=1' . '&sortBy=created%20desc';
			
			try {
				@$data_previous_results = getBackendlessResponse( $data_previous_url, $data_previous_headers, $data_previous_where );
				@$data_previous_results_array = json_decode($data_previous_results, true);
				
			} catch (Exception $ex){
				sendError( 'SMS_Codes_Verify', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' code_id: ' . @$code . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}
			
			
			if ( empty(json_decode($data_previous_results, true)['code']) )
			{
				@$code_id = $data_previous_results_array[0]['code_id'];
				@$mobile_id = $data_previous_results_array[0]['mobile_id'];
				similar_text($mobile_id, $mobile, $percentage); // Similarity check
				
				if ( $code_id && $mobile_id && ($code_id == $code) )
				{
					if ( $percentage > 80 )
					{
						$database_headers = array(
							"Content-Type: application/json",
							"user-token: " . $session_id_decrypted,
						);
						
						@$send_operation = Co::wait([
						
							"0" => function () use ($mobile, $database_headers, $user_objectId) {
								$post_data = array(
									'user_mobile'			=>		$mobile,
									'user_is_verified'		=>		(bool)TRUE,
								);
								$content = (yield updateBackendlessRequest('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $user_objectId, $database_headers, json_encode($post_data), []));
								//yield Co::RETURN_WITH =>$content; // PHP 5.6
								return $content; // PHP 7+
							},
							
						]);
						
						@$send_operation_array = json_decode($send_operation[0], true);
						
						if ( !empty($send_operation_array) && empty($send_operation_array['code']) )
						{
							@$results = array(
								'message'	   	=> 'User successfully verified.',
								'code'			=> ERROR_1000,
								'user_token'	=> encrypt($user_objectId),
							);
							
							@$op_time = $now;
							@$op_results = $results;
							@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
							@$op_url = '';
							
							$export = response_json($op_url, $op_time, $op_right, $op_results);
							
							if ( !empty($send_operation_array['referenced_code']) )
							{
								// We check to see if the referenced user is active and valid
								$reference_code_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users';
								$reference_code_headers = array(
									"Content-Type: application/json",
								);
								$reference_code_where = '?where=' . rawurlencode('user_unique_code=\'') . $send_operation_array['referenced_code'] .  rawurlencode('\' AND user_is_active=\'') . 1 . rawurlencode('\' AND user_is_verified=\'') . 1 . rawurlencode('\' AND lastLogin > ') . (( (float)$now * 1000 ) - (3 * 31 * 24 * 60 * 60 * 1000 /*3 months*/)) . '&pageSize=1' . '&sortBy=created%20desc';
								
								try {
									@$reference_results = getBackendlessResponse( $reference_code_url, $reference_code_headers, $reference_code_where );
									@$reference_results_array = json_decode($reference_results, true);
								
								} catch (Exception $ex){
									sendError( 'verifySmsCode_Reference', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_unique_code: ' . @$send_operation_array['referenced_code'] . ' , app_id: ' . @$app_id . ' and time: ' . time() );
								}
								
								if ( !empty($reference_results_array) )
								{
									if ( empty($reference_results_array['code']) )
									{
										// Send the referee a gift
										$referee_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users_Promotions';
										$referee_promotion_code = convert_small_uuid_with_hash('dgr' . substr(time(), 2, strlen(time())) . substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, 2), 2, 6);
										$reference_object_id = $reference_results_array[0]['objectId'];
										$reference_mobile = '0' . $reference_results_array[0]['user_mobile'];
										$referee_promotion_data = array(
											'promotion_quota'		=> (int) 1,
											'promotion_usage'		=> (int) 0,
											'promotion_code'		=> strtolower($referee_promotion_code),
											'promotion_type'		=> 'Reference',
											'promotion_name'		=> 'Reference Promo',
											'promotion_value_id'	=> 'DN_Promo_3_7',
											'promotion_is_active'	=> (bool) true,
											'promotion_is_public'	=> (bool) false,
											'promotion_is_used'		=> (bool) false,
											'promotion_end_date'	=> (($now * 1000) + (31 * 24 * 60 * 60 * 1000)),
											'ownerId'				=> $reference_object_id, // The referenced person Id
										);
										$referee_sms_text = '2KrYqNix24zaqSEK2K/ZiNiz2Kog2LTZhdinINio2Ycg2KzZhdi5INqp2KfYsdio2LHYp9mGINiv24zYrNuM4oCM2YbZiNinINin2LbYp9mB2Ycg2LTYry4g2KjZhyDYp9uM2YYg2K/ZhNuM2YQg2qnZj9ivINmH2K/bjNmH4oCM2KfbjCDYqNix2KfbjNiq2KfZhiDYp9ix2LPYp9mEINqp2LHYr9uM2YUg2KrYpyDYqNuM2LQg2KfYsiDZvtuM2LQg2KfYsiDZhdmI2LPbjNmC24wg2YTYsNiqINio2KjYsduM2K8gOy0pCgrYqNinINiq2LTaqdixIC0g2KrbjNmFINiv24zYrNuM4oCM2YbZiNinCtqp2Y/YryDZh9iv24zZhyDYtNmF2Kc6Cg=='; // Thanks for being reference
										$referee_sms_message = urlencode(base64_decode($referee_sms_text)) . strtoupper($referee_promotion_code);
										
										
										// Process to add Promo Code if the user has a referenced from Diginava members
										$new_user_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users_Promotions';
										$new_user_promotion_code = convert_small_uuid_with_hash('dgr' . substr(time(), 2, strlen(time())) . substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, 2), 2, 6);
										$new_user_object_id = $send_operation_array['objectId'];
										$new_user_mobile = '0' . $mobile;
										$new_user_promotion_data = array(
											'promotion_quota'		=> (int) 1,
											'promotion_usage'		=> (int) 0,
											'promotion_code'		=> strtolower($new_user_promotion_code),
											'promotion_type'		=> 'Invited',
											'promotion_name'		=> 'Reference Promo',
											'promotion_value_id'	=> 'DN_Promo_1_10',
											'promotion_is_active'	=> (bool) true,
											'promotion_is_public'	=> (bool) false,
											'promotion_is_used'		=> (bool) false,
											'promotion_end_date'	=> (($now * 1000) + (31 * 24 * 60 * 60 * 1000)),
											'ownerId'				=> $new_user_object_id, // New user object Id
										);
										$new_user_sms_text = '2KrYqNix24zaqSEK2KfYstii2YbYrNinINqp2Ycg2KrZiNiz2Lcg2K/ZiNiz2Kog2K7ZiNivINio2Ycg2K/bjNis24zigIzZhtmI2Kcg2K/YudmI2Kog2LTYr9mH4oCM2KfbjNivINio2LHYp9uMINi02YXYpyDZiCDYqNix2KfbjCDYp9uM2LTYp9mGINqp2Y/YryDZh9iv24zZh+KAjNin24wg2K/YsSDZhti42LEg2q/YsdmB2KrbjNmFIDotKQrYtNmF2Kcg2YfZhSDZhduM4oCM2KrZiNin2YbbjNivINio2Kcg2YXYsdin2KzYudmHINio2Ycg2LXZgdit2Ycg2b7YsdmI2YHYp9uM2YQg2Ygg2KfYsdiz2KfZhCDaqdivINi02YbYp9iz2Ycg2K7ZiNivINio2Ycg2K/ZiNiz2KrYp9mG2KrYp9mG2Iwg2KLZhtmH2Kcg2LHYpyDYqNmHINix2KfbjNqv2KfZhiDYqNmHINmF2YjYs9uM2YLbjCDYr9i52YjYqiDaqdmG24zYry4KCtio2Kcg2KrYtNqp2LEgLSDYqtuM2YUg2K/bjNis24zigIzZhtmI2KcK2qnZj9ivINmH2K/bjNmHINi02YXYpzoK'; // Thanks for being invited
										$new_user_sms_message = urlencode(base64_decode($new_user_sms_text)) . strtoupper($new_user_promotion_code);
										
										$process_request = Co::wait([
											
											"0" => function () use ($new_user_url, $new_user_promotion_data) {
												$content = (yield curl_async_put($new_user_url, $new_user_promotion_data ));
												//yield Co::RETURN_WITH =>$content; // PHP 5.6
												return $content; // PHP 7+
											},
											
											"1" => function () use ($new_user_mobile, $new_user_sms_message) {
												$content = (yield send_sms_with_rayganSMS($new_user_mobile, $new_user_sms_message ));
												//yield Co::RETURN_WITH =>$content; // PHP 5.6
												return $content; // PHP 7+
											},
											
											"2" => function () use ($referee_url, $referee_promotion_data) {
												$content = (yield curl_async_put($referee_url, $referee_promotion_data ));
												//yield Co::RETURN_WITH =>$content; // PHP 5.6
												return $content; // PHP 7+
											},
											
											"3" => function () use ($reference_mobile, $referee_sms_message) {
												$content = (yield send_sms_with_rayganSMS($reference_mobile, $referee_sms_message ));
												//yield Co::RETURN_WITH =>$content; // PHP 5.6
												return $content; // PHP 7+
											},
											
										]);
									}
								}
								
							}
							
						} else { // There is error (duplicated mobile number?) updating database
							
							@$results = array(
								'code'			=> $send_operation_array['code'],
								'message'		=> $send_operation_array['code'],
								'user_token'	=> encrypt($user_objectId),
							);
							
							@$op_time = $now;
							@$op_results = $results;
							@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
							@$op_url = '';
							
							$export = response_json($op_url, $op_time, $op_right, $op_results);
							
						}
						
					} else {
						
						@$results = array(
							'code'		   => ERROR_4003,
							'message'	   => 'Mobile number is changed during verification process!',
						);
						
						@$op_time = $now;
						@$op_results = $results;
						@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
						@$op_url = '';
						
						$export = response_json($op_url, $op_time, $op_right, $op_results);
						
					}
					
				} else { // Verification code is incorrect
					
					@$results = array(
						'code'		   => ERROR_4002,
						'message'	   => 'Verification code is incorrect!',
					);
					
					@$op_time = $now;
					@$op_results = $results;
					@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
					@$op_url = '';
					
					$export = response_json($op_url, $op_time, $op_right, $op_results);
					
				}
				
				return $export;
				
			} else { // There is an error updating database
				echo status_code(403);
				exit;
			}
		
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
	
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_url, $op_time, $op_right, $op_results){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}


?>