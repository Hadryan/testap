<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(144);

	define("URLVERSION", "v2");
	
	define("ALBUM",  	 "album");
	define("ARTIST", 	 "artist");
	define("TRACK",  	 "track");
	define("LABEL",  	 "label");
	define("GENRE", 	 "genre");
	define("FEATURED", 	 "featured");
	define("SIMILAR", 	 "similar");
	define("SEARCH", 	 "search");
	define("TEMPFOLDER", "temp");

	if ( isset($_GET['p']) && $_GET['p'] == 'gsdfi764837t5g' ) // password to access
	{
		ob_start();
		@$range = $_GET['r'];
		@$start_time = $_GET['s'];
		@$end_time = $_GET['e'];
		@$folder = $_GET['f'];
		@$mode = $_GET['mode'];
		
		if ( empty($range) )
		{
			$range = 'jHY_'; // 60 seconds ! 
		}
		
		if ( empty($start_time) )
		{
			$start_time = time(); // now !
		}
		
		if( $folder == ALBUM )
		{
			define("TODELETE", ALBUM);
			
		} elseif ( $folder == ARTIST )
		{
			define("TODELETE", ARTIST);
			
		} elseif ( $folder == TRACK )
		{
			define("TODELETE", TRACK);
			
		} elseif ( $folder == LABEL )
		{
			define("TODELETE", LABEL);
			
		} elseif ( $folder == GENRE )
		{
			define("TODELETE", GENRE);
				
		} elseif ( $folder == FEATURED )
		{
			define("TODELETE", FEATURED);
			
		} elseif ( $folder == SIMILAR )
		{
			define("TODELETE", SIMILAR);
			
		} elseif ( $folder == SEARCH )
		{
			define("TODELETE", SEARCH);
			
		} else {
			
			define("TODELETE", TEMPFOLDER);
		}
		
		@$range = decrypt($range);
		
		$tmp_folder = $_SERVER['DOCUMENT_ROOT'] . '/' . URLVERSION . '/' . TODELETE . '/';
		
		$files = glob($tmp_folder . '*');
		
		
		if ( $mode == 'small' ) // Delete small files and go out
		{
			foreach ($files as $file) {
				if (is_file($file)) {
					if ( filesize($file) < 1000 ) { // size of the file, 1KB
						unlink($file);
					}
				}
			}
		} elseif (is_numeric($range)) { // Range is defined
			foreach ($files as $file) {
				if (is_file($file)) {
					if ( ($start_time - filemtime($file)) > $range  ) {
						unlink($file);
					}
				}
			}
		} else { // Delete Old files
			foreach ($files as $file) {
				if (is_file($file)) {
					if ( ($start_time >= filemtime($file)) && (filemtime($file) >= (!empty($end_time) ? $end_time : ($start_time - filemtime($file)))) ) {
						unlink($file);
					}
				}
			}
		}
		
		ob_end_clean();


		//=================================================================
			$dummy = '';
			$dummy .= '<table border="1" cellpadding="1" cellspacing="1" style="width: 500px;">';
			$dummy .= '<tbody>';
			$dummy .= '<tr>';
			$dummy .= '<td>' . basename(__FILE__, '.php') . '</td>';
			$dummy .= '<td>' . date("d M Y H:i:s") . '</td>';
			$dummy .= '</tr>';
			$dummy .= '</tbody>';
			$dummy .= '</table>';
					
			echo $dummy;
			
		//=================================================================
			

	}
//
function encrypt($str){
  $key = "F2avHrF62o8jLZFREEEEN65zs7otsXV";
  $result = '';
  for($i=0; $i<strlen($str); $i++) {
     $char = substr($str, $i, 1);
     $keychar = substr($key, ($i % strlen($key))-1, 1);
     $char = chr(ord($char)+ord($keychar));
     $result.=$char;
  }
  return safe_b64encode($result);
}

//
function decrypt($str){
  $str = safe_b64decode($str);
  $result = '';
  $key = "F2avHrF62o8jLZFREEEEN65zs7otsXV";
  for($i=0; $i<strlen($str); $i++) {
    $char = substr($str, $i, 1);
    $keychar = substr($key, ($i % strlen($key))-1, 1);
    $char = chr(ord($char)-ord($keychar));
    $result.=$char;
  }
return $result;
}

//
function safe_b64encode($string) {
	$data = base64_encode($string);
	$data = str_replace(array('+','/','='),array('-','~','_'),$data);
	return $data;
}

//
function safe_b64decode($string) {
	$data = str_replace(array('-','~','_'),array('+','/','='),$string);
	$mod4 = strlen($data) % 4;
	if ($mod4) {
			$data .= substr('====', $mod4);
	}
	return base64_decode($data);
}

?>