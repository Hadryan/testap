<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(144);


include dirname(__FILE__) . '/' . basename(__FILE__, '.php') . '_functions.php';

	@$id = $_GET['id'];

	if ( $id )
	{
		if (strpos( $id , '/') !== false) {
			// if the id is came from NginX config $request_uri, we need to find the appropriate id 
			preg_match('/(\/|)(.*?)([a-zA-Z0-9]*)([a-zA-Z0-9].)([a-e])((\.m4a)|$)(.*)(\/(index|master)(\.m3u8)|$)/', $id, $ids_array);
			$id = $ids_array[3] . $ids_array[4];
		}
		
		$export = export_audio_preview( $id, '512M' );
		echo $export;
	
	} else // $id is not provided
	{
		echo status_code(417);
	}

?>
