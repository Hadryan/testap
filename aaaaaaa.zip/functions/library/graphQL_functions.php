<?php

//
function getFeaturedToDefaultModel ($data_original, $limit, $offset, $service = '1') {
    if ($service == '1') { // Online API
        return $data_original;

    } elseif ($service == '2') { // Graphql service

        if ( ($data_original["data"]["albums_count"]["aggregate"]["count"]) > 0 ) {
            @$data_limit = $limit;
            @$data_offset = $offset;
            @$data = array();
            @$data["albums"]["offset"] = (int)$data_offset;
            @$data["albums"]["limit"] = (int)$data_limit;
            @$data["albums"]["total"] = (int)$data_original["data"]["albums_count"]["aggregate"]["count"];
            @$data_items = $data_original["data"]["albums"];

            foreach ($data_items as $data_item) {
                $album_genres = $data_item["albums_genres"];
                foreach ($album_genres as $_genre) {
                    $data_genre[] = $_genre["genre"]["id"];
                }
                $album_genre["path"] = $data_genre;

                $album_image["large"] = $data_item["image_url"];

                $album_artist["id"] = $data_item["artist"]["artist_id"];
                $album_artist["name"] = $data_item["artist"]["title"];

                $album_label["id"] = $data_item["label"]["id"];
                $album_label["name"] = $data_item["label"]["title"];

                $items[] = array(
                    "artist"                => $album_artist,
                    "displayable"           => $data_item['displayable'],
                    "downloadable"          => $data_item['downloadable'],
                    "duration"              => $data_item['duration'],
                    "hires"                 => $data_item['hires'],
                    "hires_streamable"      => $data_item['hires_streamable'],
                    "id"                    => $data_item['id'],
                    "label"                 => $album_label,
                    "maximum_bit_depth"     => $data_item['maximum_bit_depth'],
                    "maximum_channel_count" => $data_item['maximum_channel_count'],
                    "maximum_sampling_rate" => $data_item['maximum_sampling_rate'],
                    "media_count"           => $data_item['media_count'],
                    "parental_warning"      => $data_item['parental_warning'],
                    "previewable"           => $data_item['previewable'],
                    "purchasable"           => $data_item['purchasable'],
                    "purchasable_at"        => $data_item['purchasable_at'],
                    "released_at"           => $data_item['released_at'],
                    "sampleable"            => $data_item['sampleable'],
                    "streamable"            => $data_item['streamable'],
                    "streamable_at"         => $data_item['streamable_at'],
                    "title"                 => $data_item['title'],
                    "tracks_count"          => $data_item['tracks_count'],
                    "upc"                   => $data_item['upc'],
                    "genre"                 => $album_genre,
                    "image"                 => $album_image,
                    "is_free"               => $data_item["is_free"],
                    "product_type"          => $data_item["product_type"],
                );

                unset($genre_array);
                unset($data_genre);
                unset($album_genre);
                unset($album_image);

            }

            @$data["albums"]["items"] = $items;

            return $data;

        }
    }
}

//
function getFeatured_FreeAlbums_WithGenres ($limit, $offset, $genre) {
    $genre_ids = (array)explode(',', $genre );

// GraphQl query begins
$album_part = <<<ALBUM
query getFreeAlbums(\$limit: Int!, \$offset: Int!, \$genre: [String!]!) {
  albums_count: music_albums_aggregate(
    where: {
      is_free: { _eq: true }
      _and: {
        albums_genres: { genre: { id: { _in: \$genre } } }
        _isActive: { _eq: true }
      }
    }
  ) {
    aggregate {
      count
    }
  }
  albums: music_albums(
    where: {
      is_free: { _eq: true }
      _and: {
        albums_genres: { genre: { id: { _in: \$genre } } }
        _isActive: { _eq: true }
      }
    }
    limit: \$limit
    offset: \$offset
    order_by: { _updatedAt: desc, _createdAt: desc }
  ) {
    id
    _createdAt
    _updatedAt
    _isActive
    albums_genres {
      genre {
        id
        title
        _isActive
      }
    }
    albums_tags {
      tag {
        title
        id
        _isActive
      }
    }
    artist {
      title
      artist_id
      service_id
      _isActive
    }
    composer {
      _isActive
      composer_id
      service_id
      title
    }
    copyright
    created_at
    displayable
    downloadable
    duration
    hires
    hires_streamable
    image_url
    is_free
    label {
      id
      _isActive
      service_id
      title
    }
    maximum_bit_depth
    maximum_channel_count
    maximum_sampling_rate
    media_count
    parental_warning
    previewable
    product_type
    purchasable
    purchasable_at
    released_at
    sampleable
    service_id
    streamable
    streamable_at
    subtitle
    title
    tracks_count
    upc
  }
}
ALBUM;

    $graphql = $album_part;
    $query = graphql_query(MUSIC_GRAPHQL_ENDPOINT, $graphql, MUSIC_GRAPHQL_ADMINPASS, ["limit" => $limit, "offset" => $offset, "genre" => $genre_ids], null);
    return $query;
}

//
function getFeatured_FreeAlbums ($limit, $offset) {

// GraphQl query begins
    $album_part = <<<ALBUM
query getFreeAlbums(\$limit: Int!, \$offset: Int!) {
  albums_count: music_albums_aggregate(
    where: { is_free: { _eq: true }, _and: { _isActive: { _eq: true } } }
  ) {
    aggregate {
      count
    }
  }
  albums: music_albums(
    where: { is_free: { _eq: true }, _and: { _isActive: { _eq: true } } }
    limit: \$limit
    offset: \$offset
    order_by: { _updatedAt: desc, _createdAt: desc }
  ) {
    id
    _createdAt
    _updatedAt
    _isActive
    albums_genres {
      genre {
        id
        title
        _isActive
      }
    }
    albums_tags {
      tag {
        title
        id
        _isActive
      }
    }
    artist {
      title
      artist_id
      service_id
      _isActive
    }
    composer {
      _isActive
      composer_id
      service_id
      title
    }
    copyright
    created_at
    displayable
    downloadable
    duration
    hires
    hires_streamable
    image_url
    is_free
    label {
      id
      _isActive
      service_id
      title
    }
    maximum_bit_depth
    maximum_channel_count
    maximum_sampling_rate
    media_count
    parental_warning
    previewable
    product_type
    purchasable
    purchasable_at
    released_at
    sampleable
    service_id
    streamable
    streamable_at
    subtitle
    title
    tracks_count
    upc
  }
}
ALBUM;

    $graphql = $album_part;
    $query = graphql_query(MUSIC_GRAPHQL_ENDPOINT, $graphql, MUSIC_GRAPHQL_ADMINPASS, ["limit" => $limit, "offset" => $offset], null);
    return $query;
}

//
function getFeatured_NewReleasesAlbums_WithGenres ($limit, $offset, $genre, $days = 30) {
    $genre_ids = (array)explode(',', $genre );
    $range = time() - (60 * 60 * 24 * $days);

// GraphQl query begins
    $album_part = <<<ALBUM
query getNewReleasesAlbums(\$limit: Int!, \$offset: Int!, \$genre: [String!]!) {
  albums_count: music_albums_aggregate(
    where: {
      created_at: { _gte: $range }
      _and: {
        albums_genres: { genre: { id: { _in: \$genre } } }
        _isActive: { _eq: true }
      }
    }
  ) {
    aggregate {
      count
    }
  }
  albums: music_albums(
    where: {
      created_at: { _gte: $range }
      _and: {
        albums_genres: { genre: { id: { _in: \$genre } } }
        _isActive: { _eq: true }
      }
    }
    limit: \$limit
    offset: \$offset
    order_by: { created_at: desc }
  ) {
    id
    _createdAt
    _updatedAt
    _isActive
    albums_genres {
      genre {
        id
        title
        _isActive
      }
    }
    albums_tags {
      tag {
        title
        id
        _isActive
      }
    }
    artist {
      title
      artist_id
      service_id
      _isActive
    }
    composer {
      _isActive
      composer_id
      service_id
      title
    }
    copyright
    created_at
    displayable
    downloadable
    duration
    hires
    hires_streamable
    image_url
    is_free
    label {
      id
      _isActive
      service_id
      title
    }
    maximum_bit_depth
    maximum_channel_count
    maximum_sampling_rate
    media_count
    parental_warning
    previewable
    product_type
    purchasable
    purchasable_at
    released_at
    sampleable
    service_id
    streamable
    streamable_at
    subtitle
    title
    tracks_count
    upc
  }
}
ALBUM;

    $graphql = $album_part;
    $query = graphql_query(MUSIC_GRAPHQL_ENDPOINT, $graphql, MUSIC_GRAPHQL_ADMINPASS, ["limit" => $limit, "offset" => $offset, "genre" => $genre_ids], null);
    return $query;
}

//
function getFeatured_NewReleasesAlbums ($limit, $offset, $days = 30) {
    $range = time() - (60 * 60 * 24 * $days);
// GraphQl query begins
    $album_part = <<<ALBUM
query getNewReleasesAlbums(\$limit: Int!, \$offset: Int!) {
  albums_count: music_albums_aggregate(
    where: {
      created_at: { _gte: $range }
      _and: { _isActive: { _eq: true } }
    }
  ) {
    aggregate {
      count
    }
  }
  albums: music_albums(
    where: {
      created_at: { _gte: $range }
      _and: { _isActive: { _eq: true } }
    }
    limit: \$limit
    offset: \$offset
    order_by: { created_at: desc }
  ) {
    id
    _createdAt
    _updatedAt
    _isActive
    albums_genres {
      genre {
        id
        title
        _isActive
      }
    }
    albums_tags {
      tag {
        title
        id
        _isActive
      }
    }
    artist {
      title
      artist_id
      service_id
      _isActive
    }
    composer {
      _isActive
      composer_id
      service_id
      title
    }
    copyright
    created_at
    displayable
    downloadable
    duration
    hires
    hires_streamable
    image_url
    is_free
    label {
      id
      _isActive
      service_id
      title
    }
    maximum_bit_depth
    maximum_channel_count
    maximum_sampling_rate
    media_count
    parental_warning
    previewable
    product_type
    purchasable
    purchasable_at
    released_at
    sampleable
    service_id
    streamable
    streamable_at
    subtitle
    title
    tracks_count
    upc
  }
}
ALBUM;

    $graphql = $album_part;
    $query = graphql_query(MUSIC_GRAPHQL_ENDPOINT, $graphql, MUSIC_GRAPHQL_ADMINPASS, ["limit" => $limit, "offset" => $offset], null);
    return $query;
}

?>