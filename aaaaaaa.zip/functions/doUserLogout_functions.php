<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';


//
function do_logout( $app_id, $user_token, $session_id ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY_PER_USER . '/users/logout';
			$database_headers = array(
				"Content-Type: application/json",
				"user-token: " . $session_id_decrypted,
			);
			
			try {
				@$database_results = getBackendlessResponse( $database_url, $database_headers, '' );
				@$database_results_array = json_decode($database_results, true);
			
			} catch (Exception $ex){
				sendError( 'doUserLogout', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}
			
			if ( empty($database_results_array['code']) )
			{
				return status_code(200, 'bye-bye!');
			
			} else {
				$reason = $database_results_array['code'];
				echo status_code(400, $reason);
				exit;
			}
		
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json(){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'success',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> json_decode('{}')
		)
	);
	
	return json_encode($output);
}

?>