<?php
error_reporting(-1);
ini_set('display_errors', 1);
@set_time_limit(233);


include dirname(__FILE__) . '/' . basename(__FILE__, '.php') . '_functions.php';

	@$track_id = $_POST['track_id'];
	@$track_format = $_POST['track_format'];
	@$track_origin = $_POST['track_origin'];
	@$request_ts = $_GET['request_ts'];
	@$request_sig = $_GET['request_sig'];

	$now = time();
	@$endpoint = 'internalFullAudioProcess';
	$fetch_secret = 'gmStjs6f!Fj~fU*-Q*ttqx#hBu$a8T@~G0D#*%wb2k<}.)<,tt_dyH/4#H_4G~,ZVH+!NJKOr5';

//	if ( $track_id && $request_ts && $request_sig && ($request_ts > $now - 1800 /*30 min*/) && ($request_ts < $now + 900 /*15 min*/) )
        if (1==1) 
	{
		@$string = $endpoint . $track_id . $request_ts . $fetch_secret;
		
//		if ( verify_hmac_signature($string, $fetch_secret, $request_sig) === TRUE )
                if (1==1)
		{
			define('AllowToAccessInternalFullAudioProcessFunctions', TRUE);
			$export = process_full_audio( $track_id, $track_origin, '512M',  $now );
			echo $export;
			
		} else {
			echo status_code(401);
			exit;
		}
		
	} else // parameter are not provided
	{
		echo status_code(417);
	}

?>
