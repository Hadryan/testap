<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(180);

include dirname(__FILE__) . '/functions_general.php';

	define("APPLICATION_ID", 			"2D4AB967-891A-3618-FF46-7FE166657400");
	// REST API key
	define("SECRET_KEY", 				"1A841EFB-3429-1E45-FF9D-B6C6D5247A00");
	// User defined key
	//define("SECRET_KEY_PER_USER",		"C95CE401-9425-46BF-FF13-4C67EA08F300");
	define("SECRET_KEY_PER_USER",		"995083C4-8B50-4C83-80BF-990C25F41049");
	define("VERSION_NO", 				URLVERSION);
	

//
function getBackendlessResponse( $url, $headers, $where = '' ){
	$rest = curl_init();

	curl_setopt($rest, CURLOPT_URL, $url . $where);
	curl_setopt($rest, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($rest, CURLOPT_CUSTOMREQUEST, "GET");
	curl_setopt($rest, CURLOPT_CAINFO, dirname(__FILE__)."/cacert.pem");
	curl_setopt($rest, CURLOPT_FRESH_CONNECT, false);
	curl_setopt($rest, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($rest, CURLOPT_RETURNTRANSFER, true);

	$response = curl_exec($rest);

	curl_close($rest);
		
return $response;
}

//
function updateBackendlessRequest( $url, $headers, $object_data ){
	$rest = curl_init();

	curl_setopt($rest, CURLOPT_URL, $url);
	curl_setopt($rest, CURLOPT_CUSTOMREQUEST, "PUT");
	curl_setopt($rest, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($rest, CURLOPT_POSTFIELDS, $object_data);
	curl_setopt($rest, CURLOPT_FRESH_CONNECT, false);
	curl_setopt($rest, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($rest, CURLOPT_RETURNTRANSFER, true);

	$response = curl_exec($rest);

	curl_close($rest);
		
return $response;
}

//
function patchBackendlessRequest( $url, $headers, $object_data ){
	$rest = curl_init();

	curl_setopt($rest, CURLOPT_URL, $url);
	curl_setopt($rest, CURLOPT_CUSTOMREQUEST, "PATCH");
	curl_setopt($rest, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($rest, CURLOPT_POSTFIELDS, $object_data);
	curl_setopt($rest, CURLOPT_FRESH_CONNECT, false);
	curl_setopt($rest, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($rest, CURLOPT_RETURNTRANSFER, true);

	$response = curl_exec($rest);

	curl_close($rest);
		
return $response;
}

//
function sendBackendlessRequest( $url, $headers, $object_data ){
	$rest = curl_init();

	curl_setopt($rest, CURLOPT_URL, $url);
	//curl_setopt($rest, CURLOPT_POST, 1);
	curl_setopt($rest, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($rest, CURLOPT_POSTFIELDS, $object_data);
	curl_setopt($rest, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($rest, CURLOPT_FRESH_CONNECT, false);
	curl_setopt($rest, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($rest, CURLOPT_RETURNTRANSFER, true);

	$response = curl_exec($rest);

	curl_close($rest);
		
return $response;
}
	
//
function deleteBackendlessRequest( $url, $headers ){
	$rest = curl_init();
	
	curl_setopt($rest, CURLOPT_URL, $url);
	curl_setopt($rest, CURLOPT_CUSTOMREQUEST, "DELETE");
	curl_setopt($rest, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($rest, CURLOPT_FRESH_CONNECT, false);
	curl_setopt($rest, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($rest, CURLOPT_RETURNTRANSFER, true);
	
	$response = curl_exec($rest);
	
	curl_close($rest);
			
return $response;
}

//
function getBackendlessLogin($username, $password){
	
	$url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users_Advanced';
	
	$headers = array(
		"Content-Type: application/json",
	);
	
	$where = '?where=user_name' . urlencode("='" . $username . "'") . '&pageSize=1';


	try {
		$results = getBackendlessResponse( $url, $headers, $where );

	} catch (Exception $ex){
		sendError('getBackendlessLogin', 'error', (string)$ex->getCode(), $ex->getMessage(), 'username: ' . @$username . ' and password: ' . @$password);
	}

	return $results;
}

//
function getBackendlessNumbered( $service, $build ){
	
	$url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Builds';
	
	$headers = array(
		"Content-Type: application/json",
	);
	
	$where = '?pageSize=1&sortBy=latest%20desc%2Cupdated%20desc%2Ccreated%20desc&where=' . urlencode( $service . '=' . $build );


	try {
		$results = getBackendlessResponse( $url, $headers, $where );

	} catch (Exception $ex){
		sendError('getBackendlessNumbered', 'error', (string)$ex->getCode(), $ex->getMessage(), 'service: ' . @$service . ' and build: ' . @$build);
	}

	return $results;
}

//
function getBackendlessLatest(){
	
	$url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Builds';
	
	$headers = array(
		"Content-Type: application/json",
	);
	
	$where = '?sortBy=latest%20desc%2Cupdated%20desc%2Ccreated%20desc' . '&pageSize=1';


	try {
		$results = getBackendlessResponse( $url, $headers, $where );

	} catch (Exception $ex){
		sendError('getBackendlessLatest', 'error', (string)$ex->getCode(), $ex->getMessage(), 'Error in fetching ');
	}

	return $results;
}

//
function sendError($function_name, $what, $how, $note, $other = ''){

	$url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/System_Error';

	$headers = array(
		"Content-Type: application/json",
	);

	$data = '{' .
		'"function_name":"' . $function_name . '",' .
		'"' . $what . '":"' . $how . '",' .
		'"note":"' . $note . '",' .
		'"other":"' . $other . '"' .
	'}';
	
	try {
		sendBackendlessRequest( $url, $headers, $data );

	} catch (Exception $ex) {  
		//
	}
}

//
function updateCustomInfo($class, $object_id, $field, $value){
	
	$url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/' . $class . '/' . $object_id . '';

	$headers = array(
		"Content-Type: application/json",
	);

	$data = '{' .
		'"' . $field . '":"' . $value . '"' .
	'}';

	try {
		updateBackendlessRequest( $url, $headers, $data );
		echo customResponse(true, "DONE");
						
	} catch (Exception $ex) {  
		sendError('updateCustomInfo', 'error', (string)$ex->getCode(), $ex->getMessage(), 'objectId: ' . @$object_id . ' and field: ' . @$field . ' and value: ' . @$value);
		echo customResponse(false, "ERROR");
	}
}

//
function sendDataToParse($url, $headers, $object_data){
	$rest = curl_init();
	curl_setopt($rest, CURLOPT_URL, $url);
	curl_setopt($rest, CURLOPT_POST, 1);
	curl_setopt($rest, CURLOPT_POSTFIELDS, $object_data);
	curl_setopt($rest, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($rest, CURLOPT_FRESH_CONNECT, false);
	curl_setopt($rest, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($rest, CURLOPT_RETURNTRANSFER, true);
	$response = curl_exec($rest);
	curl_close($rest);
	
return $response;
}

//
function customResponse($boolean, $data){

	return '{"success":' . json_encode($boolean) . ', "message":' . json_encode($data)  . '}';
}

//
function randomStringGenerator(){
	return substr( "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" ,mt_rand( 0 ,50 ) ,1 ) .substr( md5( time() ), 1);
}

?>