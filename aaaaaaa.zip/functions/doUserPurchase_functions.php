<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';
// Asynchronous request
require dirname(__FILE__) . '/library/vendor/autoload.php';
use mpyw\Co\Co;
use mpyw\Co\CURLException;

//
function curl_async_put($url, array $options = [], $user_token = '')
{
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	}

	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "PUT",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function curl_async_get($url, array $options = [], $user_token = '')
{
	if ( $user_token == '' )
	{
		$headers = array(
			"Content-Type: application/json",
		);
	} else
	{
		$headers = array(
			"Content-Type: application/json",
			"user-token: " . $user_token,
		);
	};
	
	$ch = curl_init();
	$options = array_replace([
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_HTTPHEADER => $headers,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_POSTFIELDS => json_encode(''),
	], $options);
	curl_setopt_array($ch, $options);
	return $ch;
}

//
function process_purchase( $data_signature, $purchase_data, $app_id, $user_token, $session_id, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		$purchase_original = $purchase_data;
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];

var_dump($data_signature); echo "__";
var_dump($purchase_data); echo "__";
		
		if ( $user_objectId == $provided_user_id )
		{
			$original_purchase_data = $purchase_data;
			@$purchase_data = base64_decode($purchase_data);
			@$purchase_array = json_decode($purchase_data, true);
			
			@$purchase_order_id = $purchase_array['orderId'];
			@$purchase_product_id = $purchase_array['productId'];
			@$purchase_package_name = $purchase_array['packageName'];
			@$purchase_current_time = $purchase_array['purchaseTime'];
			@$purchase_state = $purchase_array['purchaseState'];
			@$purchase_payload = $purchase_array['developerPayload'];
			
			@$payload_data = base64_decode($purchase_payload);
			@$payload_array = json_decode($payload_data, true);
			
			@$payload_session_response = json_decode(decrypt($payload_array['s']), true); // session_id changes to s because of 250 characters payload limitations
			@$payload_provided_user_id = $payload_session_response[0];
			@$payload_product_id = $payload_array['p']; // product_id changes to p because of 250 characters payload limitations
			@$payload_current_time = $payload_array['t']; // current_time changes to t because of 250 characters payload limitations
			
			if ( ($payload_product_id != $purchase_product_id) )
			{
echo $payload_provided_user_id; echo "__";
echo $user_objectId; echo "__";
echo $payload_product_id; echo "__";
echo $purchase_product_id; echo "__";
echo $payload_current_time; echo "__";
echo $purchase_current_time; echo "__";
				echo status_code(403); // Faking the payload !
				exit;
			
			}
			
			$key =	"-----BEGIN PUBLIC KEY-----\n" . chunk_split(MYKET_PUBLIC_KEY_BASE64, 64,"\n") . '-----END PUBLIC KEY-----';
			// using PHP to create an RSA key
			$key = openssl_get_publickey($key);
			
			// $data_signature should be in binary format, but it comes as BASE64. So, I'll convert it.
			$data_signature = base64_decode($data_signature);
			
			// using PHP native support to verify the signature
			$result = openssl_verify(
						$purchase_data,
						$data_signature,
						$key,
			OPENSSL_ALGO_SHA1);
var_dump($result);
		
			if ( $result === 1 )
			// if ( $result !== 1 ) // TODO : in production, delete this completely!
			{
				$package_to_value_array = package_to_value($purchase_product_id);
				$package_to_value_json = json_decode($package_to_value_array, true);
				$package_value = $package_to_value_json[0];
				$package_time_to_live = $package_to_value_json[1];
				/*
				14-digit number 
					timestamp : 1506369011 --> 150636 + controlIfTimePackage[0,1] + package value + packageValueNormalPoints
					150636 + 1 + 003 + 0005 = 15063610030005
				*/
				
				$previous_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY_PER_USER . '/counters/' . $user_objectId . '__' . 'user_total_purchases';
				$previous_headers = array(
					"Content-Type: application/json",
					"user-token: " . $session_id_decrypted,
				);
				
				try {
					@$previous_results = getBackendlessResponse( $previous_url, $previous_headers, '' );
					
				} catch (Exception $ex){
					sendError( 'doUserPurchase_countersGet', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
				}
				
				if ( empty(json_decode($previous_results, true)['code']) )
				{
					if ( $previous_results == 0 ) // Previous results was empty, means new user
					{
						$genorous_time = time() + 86400; // until tomorrow
						$construction_time = substr($genorous_time + $package_time_to_live, 0, 6);
						
						if ( !is_null($package_time_to_live) ) // Time-based Packages
						{
							$construction_control_digit = 1;
							$construction_subscription_value = $package_value;
							$construction_normal_value = 0;
							
						} else // Normal Packages
						{
							$construction_control_digit = 0;
							$construction_subscription_value = 0;
							$construction_normal_value = $package_value;
						}
						
						$construction_count = $construction_time . $construction_control_digit . prepareLength($construction_subscription_value, 3, 0) . prepareLength($construction_normal_value, 4, 0);
						
					} else // We had purchases before
					{
						$previous_time = substr($previous_results, 0, 6);
						$previous_control_digit = substr($previous_results, 6, 1);
						$previous_subscription_value = substr($previous_results, 7, 3);
						$previous_normal_value = substr($previous_results, 10, 4);
						
						$genorous_time = time() + 86400; // until tomorrow
						$construction_time = substr($genorous_time + $package_time_to_live, 0, 6);
						
						if ( !is_null($package_time_to_live) ) // Time-based Packages [new package also time-based]
						{
							$construction_control_digit = 1;
							$construction_subscription_value = $package_value + $previous_subscription_value;
							$construction_normal_value = $previous_normal_value;
							$construction_time = max($previous_time, $construction_time);
							
						} else // Normal Packages
						{
							$construction_control_digit = 0;
							$construction_subscription_value = 0;
							$construction_normal_value = $package_value;
							
							if ( ($construction_control_digit == 1) || ($previous_control_digit == 1) ) // We check to see if the Previous buy is time-based or not [if it was time-based, we'll keep that information again]
							{							
								if ( substr($genorous_time, 0, 6) >= $previous_time ) // The previous package time is already expired! && [We are also generous here!, could be time() instead of $genorous_time]
								{
									$construction_control_digit = 0;
									$construction_subscription_value = 0;
									$construction_normal_value = $package_value + $previous_normal_value;
									$construction_time = $construction_time;
									
								} else // We still have time from previous package
								{
									$construction_control_digit = 1;
									$construction_subscription_value = $previous_subscription_value;
									$construction_normal_value = $package_value + $previous_normal_value;
									$construction_time = max($previous_time, $construction_time);
								}
								
							} else // The previous buy, wasn't time-based
							{
								$construction_control_digit = 0;
								$construction_subscription_value = 0;
								$construction_normal_value = $package_value + $previous_normal_value;
								$construction_time = $construction_time;
							}
							
						}
						
						$construction_count = $construction_time . $construction_control_digit . prepareLength($construction_subscription_value, 3, 0) . prepareLength($construction_normal_value, 4, 0);
						
					}
					
					$difference_value = $construction_count - $previous_results;
					
					$purchase_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users_Purchases';
					$set_purchase = array(
						'purchase_id'			  => $user_objectId . '_' . $purchase_product_id . '-' . $purchase_current_time,
						'purchase_name'			  => $purchase_product_id,
						'purchase_order_id'		  => $purchase_order_id,
						'purchase_response'		  => $original_purchase_data,
						'purchase_state'		  => $purchase_state,
					);
					$database_headers = array(
						"Content-Type: application/json",
					);
					$purchase_headers = array(
						"Content-Type: application/json",
						"user-token: " . $session_id_decrypted,
					);
						
					try {
						@$purchase_results = updateBackendlessRequest( $purchase_url, $purchase_headers, json_encode($set_purchase) );
						@$purchase_results_array = json_decode($purchase_results, true);
						
					} catch (Exception $ex){
						sendError( 'setPurchase', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , purchase_response: ' . @$original_purchase_data . ' , app_id: ' . @$app_id . ' and time: ' . time() );
					}
					
					if ( !empty($purchase_results_array) )
					{
						if ( empty($purchase_results_array['code']) )
						{
							$purchase_owner_id = $purchase_results_array['ownerId'];
							$purchase_object_id = $purchase_results_array['objectId'];
							
							$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $purchase_owner_id . '/user_purchases';
							$relation_data = array(
								'objectId' 	 => $purchase_object_id
							);
							
							try {
								updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
							
							} catch (Exception $ex){
								sendError( 'setPurchase_relationUpdate', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , purchase_objectId: ' . @$purchase_object_id . ' , app_id: ' . @$app_id . ' and time: ' . time() );
							}
							
							$get_counters = Co::wait([
							
								"0" => function () use ($user_objectId, $package_value, $difference_value) {
									$content = (yield curl_async_put('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/counters/' . $user_objectId . '__' . 'user_total_purchases' . '/incrementby/get?value=' . $difference_value ));
									//yield Co::RETURN_WITH =>$content; // PHP 5.6
									return $content; // PHP 7+
								},
								
								"1" => function () use ($user_objectId) {
									$content = (yield curl_async_get('https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $user_objectId . '?where=ownerId' . urlencode("='" . $user_objectId . "'")));
									//yield Co::RETURN_WITH =>$content; // PHP 5.6
									return $content; // PHP 7+
								},
								
							]);
							
							@$user_total_spent = json_decode($get_counters[1], true);
							
							$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $user_objectId;
							$relation_data = array(
								'user_total_purchases'		=> (double)checkSafeValue($get_counters[0], 0),
								'user_total_spent'			=> (double)checkSafeValue($user_total_spent["user_total_spent"], 0),
							);
							
							try {
								updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
								
							} catch (Exception $ex){
								sendError( 'doUserPurchase', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , purchase_data: ' . @$purchase_data . ' , app_id: ' . @$app_id . ' and time: ' . time() );
							}
							
							return status_code(201);
							
						} else {
							$reason = $database_results_array['message'];
							echo status_code(401, $reason);
							exit;
						}
					
					} else { // Nothing returned from the server
						echo status_code(412, 'error adding to database!');
						exit;
					}
				
				} else { // Expired session_id
					echo status_code(401);
					exit;
				}
				
			} else { // Problem in validating
				echo status_code(403, 'validating terekmun');
				exit;
			}
			
		} else { // Invalid login
			echo status_code(403, 'login ridemun');
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_user, $op_time, $op_right){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'results'		=> $op_user,
				'copyright'		=> $op_right,
			)
		)
	);
	
	return json_encode($output);
}

?>