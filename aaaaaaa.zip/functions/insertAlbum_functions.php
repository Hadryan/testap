<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';


//
function insert_album( $id, $url ) {

	if ( defined('AllowToAccessDataBaseFunctions') )
	{
		$current_time = time();
		$service_id = json_encode('1');
		
		@$fetch_url = stream_open($url, parse_url($url, PHP_URL_HOST), parse_url($url, PHP_URL_HOST), $accept = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', USERAGENT, true, false );
		@$data = json_decode($fetch_url, true);
		
		if ( !empty($data["id"]) && ($id == $data["id"]) )
		{
			@$data_image = json_encode($data["image"]["large"]);
			@$data_id = json_encode((string)$data["id"]);
			@$data_title = json_encode($data["title"]);
			@$data_subtitle = json_encode($data["subtitle"]);
			@$data_description = (isset($data["description"]) ? json_encode($data["description"]) : json_encode(null));
			@$data_description_language = (isset($data["description_language"]) ? json_encode($data["description_language"]) : json_encode(null));
			@$data_url = json_encode($data["url"]);
		
			@$data_composer = json_encode($data["composer"]["name"]);
			@$data_comp_id = json_encode((string)$data["composer"]["id"]);
			@$data_comp_albums_count = json_encode($data["composer"]["albums_count"]);
		
			@$data_artist = json_encode($data["artist"]["name"]);
			@$data_artist_id = json_encode((string)$data["artist"]["id"]);
			@$data_artist_albums_count = json_encode($data["artist"]["albums_count"]);

			if ( !is_null($data["artist"]["name"]) ) // [QUICK_FIX]: APP doesn't download if the artist is null ! 11/11/2017 5:55:04 AM
			{
				$track_artist_correction_id = (string)$data["artist"]["id"];
				$track_artist_correction_title = $data["artist"]["name"];
				
			} elseif ( !is_null($data["composer"]["name"]) )
			{
				$track_artist_correction_id = (string)$data["composer"]["id"];
				$track_artist_correction_title = $data["composer"]["name"];
				
			} else
			{
				$track_artist_correction_id = "573076";
				$track_artist_correction_title = "Various Artists";
			}
			
			if ( !is_null($data["artist"]["name"]) )
			{
				$album_artist_correction_id = $data_artist_id;
				$album_artist_correction_title = $data_artist;
			} else {
				$album_artist_correction_id = json_encode("573076");
				$album_artist_correction_title = json_encode("Various Artists");
			}
			
			if ( !is_null($data["composer"]["name"]) )
			{
				$album_composer_correction_id = $data_comp_id;
				$album_composer_correction_title = $data_composer;
			} else {
				$album_composer_correction_id = json_encode("573076");
				$album_composer_correction_title = json_encode("Various Artists");
			}
		
			@$data_label = json_encode($data["label"]["name"]);
			@$data_label_id = json_encode((string)$data["label"]["id"]);
			@$data_label_albums_count = json_encode($data["label"]["albums_count"]);
			
			// Maybe use later
			@$data_period = json_encode($data["period"]["name"]);
			@$data_period_id = json_encode($data["period"]["id"]);
		
			@$data_instrument = json_encode($data["instrument"]["name"]);
			@$data_instrument_id = json_encode((string)$data["instrument"]["id"]);
		
			@$data_area = json_encode($data["area"]["name"]);
			@$data_area_id = json_encode((string)$data["area"]["id"]);
			//
			
			@$data_qobuz_id = json_encode((string)$data["qobuz_id"]);
		
			@$data_pdf = json_encode($data["goodies"][0]["description"]);
			@$data_pdf_url = json_encode($data["goodies"][0]["original_url"]);
			@$data_swf_url = json_encode($data["goodies"][0]["url"]);
			if ( $data_pdf_url )
			{
				$path = $data_pdf_url;
				$pdf_id = basename($path);
				preg_match('/\/goodies(\/([^\/]*)?|$)\/(.*).pdf/', $path, $pdf_array);
				$pdf_url_id = $pdf_array[2] . ':' . $pdf_array[3];
				$pdf_id = construct_the_id(QOBUZSERVICE . 'Booklet', $pdf_url_id);
				$pdf_time = time() + (60 * 60 * 24 * 21); // 21 days
				$pdf_secret = generate_booklet_link($pdf_id, $pdf_time );
				$pdf_link = ASSETSSERVER_SSL . BOOKLETS_LOCATION . '/' . $pdf_id . '.pdf' . '?expires=' . $pdf_time . '&signature=' . $pdf_secret;
			}
			
			@$data_genre_id_1 = json_encode((string)$data["genre"]["path"][0]);
			@$data_genre_id_1_title = json_encode(ic_genres($data["genre"]["path"][0]));
			@$data_genre_id_2 = json_encode((string)$data["genre"]["path"][1]);
			@$data_genre_id_2_title = json_encode(ic_genres($data["genre"]["path"][1]));
			@$data_genre_id_3 = json_encode((string)$data["genre"]["path"][2]);
			@$data_genre_id_3_title = json_encode(ic_genres($data["genre"]["path"][2]));
			@$data_genre_id_4 = json_encode((string)$data["genre"]["path"][3]);
			@$data_genre_id_4_title = json_encode(ic_genres($data["genre"]["path"][3]));
		
			@$data_copyright = json_encode($data["copyright"]);
			@$data_recording_information = json_encode($data["recording_information"]);
		
			@$data_program = json_encode($data["program"]); // We don't use this for now
			
			@$data_technical_specifications = json_encode($data["maximum_technical_specifications"]);
		
			@$data_created = json_encode($data["created_at"]);
			@$data_released = json_encode($data["released_at"]);
			
			@$data_duration = json_encode($data["duration"]);
			@$data_media = json_encode($data["media_count"]);
			@$data_tracks_count = json_encode($data["tracks_count"]);
		
			@$data_popularity = json_encode($data["popularity"]);
			@$data_product_sales_weekly = json_encode($data["product_sales_factors_weekly"]);
			@$data_product_sales_monthly = json_encode($data["product_sales_factors_monthly"]);
			@$data_product_sales_yearly = json_encode($data["product_sales_factors_yearly"]);
		
			@$data_product_type = json_encode($data["product_type"]);
		
			@$data_recording_information = json_encode($data["recording_information"]);
		
			@$data_sampling = json_encode($data["maximum_sampling_rate"]);
			@$data_depth = json_encode($data["maximum_bit_depth"]);
			@$data_channel = json_encode($data["maximum_channel_count"]);
		
			@$data_purchasable_at = json_encode($data["purchasable_at"]);
			@$data_streamable_at = json_encode($data["streamable_at"]);
			@$data_purchasable = json_encode($data["purchasable"]);
			@$data_streamable = json_encode($data["streamable"]);
			@$data_previewable = json_encode($data["previewable"]);
			@$data_sampleable = json_encode($data["sampleable"]);
			@$data_downloadable = json_encode($data["downloadable"]);
			@$data_displayable = json_encode($data["displayable"]);
		
			@$data_hires = json_encode($data["hires"]);
			@$data_hires_streamable = json_encode($data["hires_streamable"]);
			
			@$data_parental_warning = json_encode($data['parental_warning']);
			
			@$data_upc = json_encode($data['upc']);
			
			@$data_awards = json_encode($data["awards"]); // Will use later
			
			@$data_items = $data["tracks"]["items"];
		
			$current_time = time();
			
			
// GraphQl query begins		
$album_part = <<<ALBUM
mutation insertAlbum {
  insert_music_Albums(
	objects: [
	  {
		artist: {
		  data: {
			artist_id: $album_artist_correction_id
			composer_id: $album_artist_correction_id
			title: $album_artist_correction_title
			service_id: $service_id
		  }
		  on_conflict: { constraint: Artists_pkey, update_columns: title }
		}
		composer: {
		  data: {
			composer_id: $album_composer_correction_id
			artist_id: $album_composer_correction_id
			title: $album_composer_correction_title
			service_id: $service_id
		  }
		  on_conflict: { constraint: Artists_pkey, update_columns: title }
		}
		booklet_url: $data_pdf_url
		copyright: $data_copyright
		created_at: $data_created
		description: $data_description
		description_language: $data_description_language
		displayable: $data_displayable
		downloadable: $data_downloadable
		duration: $data_duration
		external_id: $data_qobuz_id
		hires: $data_hires
		hires_streamable: $data_hires_streamable
		id: $data_id
		image_url: $data_image
		label: {
		  data: { id: $data_label_id, title: $data_label, service_id: $service_id }
		  on_conflict: { constraint: labels_pkey, update_columns: title }
		}
		maximum_bit_depth: $data_depth
		maximum_channel_count: $data_channel
		maximum_sampling_rate: $data_sampling
		media_count: $data_media
		parental_warning: $data_parental_warning
		previewable: $data_previewable
		product_type: $data_product_type
		purchasable: $data_purchasable
		purchasable_at: $data_purchasable_at
		released_at: $data_released
		sampleable: $data_sampleable
		service_id: $service_id
		streamable: $data_streamable
		streamable_at: $data_streamable_at
		subtitle: $data_subtitle
		title: $data_title
		tracks_count: $data_tracks_count
		upc: $data_upc
		original_url: $data_url
		_updatedAt: $current_time
ALBUM;
		
$genre_part = <<<GENRE
		genres: {
		  data: [
GENRE;

		if ( $data["genre"]["path"][0] != '' )
		{
$genre_part .= <<<GENRE
			{
			  genre: {
				data: { id: $data_genre_id_1, title: $data_genre_id_1_title }
				on_conflict: {
					constraint: genres_pkey
					update_columns: [title]
				}
			  }
			}
GENRE;
		}
		if ( $data["genre"]["path"][1] != '' )
		{
$genre_part .= <<<GENRE
			{
			  genre: {
				data: { id: $data_genre_id_2, title: $data_genre_id_2_title }
				on_conflict: {
					constraint: genres_pkey
					update_columns: [title]
				}
			  }
			}
GENRE;
		}
		if ( $data["genre"]["path"][2] != '' )
		{
$genre_part .= <<<GENRE
			{
			  genre: {
				data: { id: $data_genre_id_3, title: $data_genre_id_3_title }
				on_conflict: {
					constraint: genres_pkey
					update_columns: [title]
				}
			  }
			}
GENRE;
		}
		if ( $data["genre"]["path"][3] != '' )
		{
$genre_part .= <<<GENRE
			{
			  genre: {
				data: { id: $data_genre_id_4, title: $data_genre_id_4_title }
				on_conflict: {
					constraint: genres_pkey
					update_columns: [title]
				}
			  }
			}
GENRE;
		}

$genre_part .= <<<GENRE
		  ]
		    on_conflict: {
		    	constraint: albums_genres_pkey
		    	update_columns: [album_id, genre_id]
		    }
		}
GENRE;
		
$track_part = <<<TRACK
		tracks: {
		  on_conflict: { constraint: tracks_pkey, update_columns: [album_id, _updatedAt, replaygain_peak, replaygain_gain] }
		  data: [
TRACK;
		
		$tracks_array = isset($data_items[0]) ? $data_items : array($data_items);
		foreach($tracks_array as $num => $track){
			
			@$track_id = json_encode((string)$track['id']);
			@$track_title = json_encode($track['title']);
			@$track_composer_id = isset($track['composer']['id']) ? json_encode((string)$track['composer']['id']) : json_encode($track_artist_correction_id);
			@$track_composer = isset($track['composer']['name']) ? json_encode((string)$track['composer']['name']) : json_encode($track_artist_correction_title);
			@$track_artist_id = isset($track['performer']['id']) ? json_encode((string)$track['performer']['id']) : json_encode($track_artist_correction_id);
			@$track_artist = isset($track['performer']['name']) ? json_encode((string)$track['performer']['name']) : json_encode($track_artist_correction_title);
			@$track_duration = json_encode($track['duration']);
			@$track_performers = json_encode($track['performers']);
			@$track_media_number = json_encode($track['media_number']);
			@$track_copyright = json_encode($track['copyright']);
			@$track_track_number = json_encode($track['track_number']);
			@$track_version = json_encode($track['version']);
			@$track_parental_warning = json_encode($track['parental_warning']);
			@$track_isrc = json_encode($track['isrc']);
			@$track_work = json_encode($track['work']);
			@$track_replaygain_peak = json_encode($track['audio_info']['replaygain_track_peak']);
			@$track_replaygain_gain = json_encode($track['audio_info']['replaygain_track_gain']);
			@$track_purchasable = json_encode($track['purchasable']);
			@$track_streamable = json_encode($track['streamable']);
			@$track_previewable = json_encode($track['previewable']);
			@$track_sampleable = json_encode($track['sampleable']);
			@$track_downloadable = json_encode($track['downloadable']);
			@$track_displayable = json_encode($track['displayable']);
			@$track_purchasable_at = json_encode($track['purchasable_at']);
			@$track_streamable_at = json_encode($track['streamable_at']);
				
			@$track_maximum_sampling_rate = json_encode($track['maximum_sampling_rate']);
			@$track_maximum_channel_count = json_encode($track['maximum_channel_count']);
			@$track_maximum_bit_depth = json_encode($track['maximum_bit_depth']);
			@$track_hires = json_encode($track['hires']);
			@$track_hires_streamable = json_encode($track['hires_streamable']);
			
$track_part .= <<<TRACK
			{
				copyright: $track_copyright
				displayable: $track_displayable
				downloadable: $track_downloadable
				duration: $track_duration
				hires: $track_hires
				hires_streamable: $track_hires_streamable
				id: $track_id
				isrc: $track_isrc
				maximum_bit_depth: $track_maximum_bit_depth
				maximum_channel_count: $track_maximum_channel_count
				maximum_sampling_rate: $track_maximum_sampling_rate
				media_number: $track_media_number
				parental_warning: $track_parental_warning
				performers: $track_performers
				previewable: $track_previewable
				purchasable: $track_purchasable
				purchasable_at: $track_purchasable_at
				sampleable: $track_sampleable
				service_id: $service_id
				streamable: $track_streamable
				replaygain_peak: $track_replaygain_peak
				replaygain_gain: $track_replaygain_gain
				streamable_at: $track_streamable_at
				title: $track_title
				track_number: $track_track_number
				version: $track_version
				work: $track_work
				_updatedAt: $current_time
				artist: {
				data: {
					artist_id: $track_artist_id
					composer_id: $track_artist_id
					title: $track_artist
					service_id: $service_id
				}
				on_conflict: { constraint: Artists_pkey, update_columns: title }
				}
				composer: {
				data: {
					composer_id: $track_composer_id
					artist_id: $track_composer_id
					title: $track_composer
					service_id: $service_id
				}
				on_conflict: { constraint: Artists_pkey, update_columns: title }
				}
			}
TRACK;
		}
		
$track_part .= <<<TRACK
		  ]
		}
TRACK;
	
$query_part = <<<ALBUM
				}
			  ]
ALBUM;
	
	if ( POSTGRES_ALBUM_ONCONFLICT == 1 )
	{
$query_part .= <<<ALBUM
			on_conflict: {
			  constraint: albums_pkey
			  update_columns: [
				booklet_url
				copyright
				created_at
				description
				displayable
				downloadable
				duration
				external_id
				hires
				hires_streamable
				image_url
				maximum_bit_depth
				maximum_channel_count
				maximum_sampling_rate
				media_count
				original_url
				parental_warning
				previewable
				product_type
				purchasable
				purchasable_at
				released_at
				sampleable
				service_id
				streamable
				streamable_at
				subtitle
				title
				tracks_count
				upc
				_updatedAt
			  ]
			}
ALBUM;
	}
	
$query_part .= <<<ALBUM
			) {
			  affected_rows
			  returning {
				id
			  }
			}
		  }
ALBUM;
		
		$graphql = $album_part . $genre_part . $track_part . $query_part;
		
		$query = graphql_query(MUSIC_GRAPHQL_ENDPOINT, $graphql, MUSIC_GRAPHQL_ADMINPASS, [], null);
		
			if ( $data["id"] == $query["data"]["insert_music_Albums"]["returning"][0]["id"])
			{
				echo status_code(201);
			
			} else {
				sendError( 'insertAlbum', 'error', '', 'database update failed', 'album_id: ' . $id . ' url_id: ' . $url . ' and time: ' . time() );
				exit;
			}
		
		} else {
			echo status_code(412);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

?>