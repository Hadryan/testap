<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';

//
function change_ad_type($number) {
	
	$name_array = array(
		1		=>		'full-screen',
		2		=>		'vertical-1',
		3		=>		'leaderboard-1',
		4		=>		'square-1',
		5		=>		'mobile-1',
		6		=>		'horizontal-1',
		7		=>		'leaderboard-2',
		
	);
	return strtr($number, $name_array);
}

//
function change_image_type($number) {
	
	$name_array = array(
		1		=>		'["1080","1920"]',
		2		=>		'["300","1050"]',
		3		=>		'["300","50"]',
		4		=>		'["300","300"]',
		5		=>		'["320","100"]',
		6		=>		'["970","250"]',
		7		=>		'["970","90"]',
		
	);
	return strtr($number, $name_array);
}

//
function change_age_group($number) {
	
	$name_array = array(
		1		=>		'3-99',
		2		=>		'7-15',
		3		=>		'15-20',
		4		=>		'20-26',
		5		=>		'26-31',
		6		=>		'31-35',
		7		=>		'35-42',
		8		=>		'42-60',
		9		=>		'60-80',
		10		=>		'80-99',
		
	);
	return strtr($number, $name_array);
}

//
function get_system_ads( $app_id, $zone, $type, $limit, $offset, $current_time ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		$coordinations = geocode_coordinations($zone);
		$latitude = $coordinations['latitude'];
 		$longitude = $coordinations['longitude'];
		
		$type = (int)$type;
		
		$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Platform_Ads';
		$database_headers = array(
			"Content-Type: application/json",
		);
		
		if ( $type == 1 )
		{
			$database_where = '?relationsDepth=1&where=' . urlencode("ad_valid_until > " . $current_time * 1000 . ' AND distance(' . $latitude . ', ' . $longitude . ', ad_geo_place.latitude, ad_geo_place.longitude) < km(' . ADS_SYSTEM_SEARCH_RADIUS . ")") . '&pageSize=' . $limit . '&offset=' . $offset . '&sortBy=' . urlencode('ad_priority_level asc,created desc');
		} else {
			$database_where = '?relationsDepth=1&where=' . urlencode("ad_valid_until > " . $current_time * 1000 . ' AND distance(' . $latitude . ', ' . $longitude . ', ad_geo_place.latitude, ad_geo_place.longitude) < km(' . ADS_SYSTEM_SEARCH_RADIUS . ")" . " AND ad_type='" . $type . "'") . '&pageSize=' . $limit . '&offset=' . $offset . '&sortBy=' . urlencode('ad_priority_level asc,created desc');
		}
		
		try {
			@$database_results = getBackendlessResponse( $database_url, $database_headers, $database_where );
			@$database_results_array = json_decode($database_results, true);
			
		} catch (Exception $ex){
			sendError( 'getSystemAds', 'error', (string)$ex->getCode(), $ex->getMessage(), 'zone: ' . @$zone . ' , type: ' . @$type . ' , app_id: ' . @$app_id . ' and time: ' . time() );
		}
		
		
		if ( !empty($database_results_array) )
		{
			if ( empty($database_results_array['code']) )
			{
				$database_results_array = isset($database_results_array[0]) ? $database_results_array : array($database_results_array);
				foreach($database_results_array as $num => $data) {
					
					preg_match('/(.*)\.([0-9a-zA-Z]+)/', $data['ad_internal_id'], $id_array);
					$internal = explode('_', $id_array[1]);
					$image_service = $internal[0];
					$image_id = $internal[1];
					$image_dimentions = $internal[2];
					$image_size = json_decode(change_image_type($image_dimentions), true);
					$image_width = $image_size[0];
					$image_height = $image_size[1];
					
					@$ad_image = array(
						$image_width   =>	ADMEDIASERVER . 'getSystemCover.php?size=' . $image_width . '&id=' . md5_encrypt($data['ad_internal_id'], MD5KEY) . '.jpg'
					);
					
					$items[] = array(
						'name'						   => (!empty($data['ad_name']) ? $data['ad_name'] : null),
						'address'					   => (!empty($data['ad_address']) ? $data['ad_address'] : null),
						'age_group'					   => change_age_group((int)$data['ad_age_group']),
						'image'						   => $ad_image,						
						'image_size'				   => $image_width . 'x' . $image_height,
						'type'						   => change_ad_type((int)$data['ad_type']),
						'distance'					   => $data['ad_geo_place']['distance'],
						'latitude'					   => $data['ad_geo_place']['latitude'],
						'longitude'					   => $data['ad_geo_place']['longitude'],
						'valid_until'				   => round($data['ad_valid_until'] / 1000),
						'is_remote'					   => (bool)$data['ad_is_remote'],
						'priority_level'			   => (int)$data['ad_priority_level'],
						'target'					   => $data['ad_target'],
						'publisher'					   => (!empty($data['ownerId']) ? encrypt($data['ownerId']) : null),
						'object_id'					   => encrypt($data['objectId']),
						'created'					   => round($data['created'] / 1000),
					);
				}
				
				@$op_time = $current_time;
				@$op_limit = (int)$limit;
				@$op_offset = (int)$offset;
				@$op_results = $items;
				@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
					
				$export = response_json($op_time, $op_limit, $op_offset, $op_results, $op_right);
				// Creating temporary cache file
				temp_creator_on_server( basename(__FILE__, '_functions.php'), 'systemads' . $zone . $type . $limit . $offset, $export );
				
				
				return $export;
					
			} else {
				//$reason = $database_results_array['code']; // TODO: Change in production
				//echo status_code(400, $reason);
				$reason = $database_results_array['message'];
				echo status_code(400, $reason);
				exit;
			}
				
		} else { // Nothing returned from the server [@MINWANG: Changed the status code from 404 to 200, even if the result is empty 12.07.17 04:11 AM ]
			echo status_code(200, 'successfully processed');
			exit;
		}
	
	} else {
		die(status_code(401));
		
	}
}

//
function response_json($op_time, $op_limit, $op_offset, $op_results, $op_right){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'offset'		=> $op_offset,
				'limit'			=> $op_limit,
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}

?>