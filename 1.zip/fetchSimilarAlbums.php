<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(30);
header("Access-Control-Allow-Origin: *");
header("Content-Type:application/json");

include dirname(__FILE__) . '/functions.php';

	@$limit = $_GET['l'];
	@$offset = $_GET['o'];
	@$genre_ids = $_GET['g'];
	@$app_id = $_GET['app_id'];
	@$app_secret = $_GET['app_secret'];
	if ( empty($app_id) )
	{
		$app_id = QOBUZAPPID;
	}
	if ( empty($app_secret) )
	{
		$app_secret = QOBUZAPPSECRET;
	}

	if ( !empty($genre_ids) )
	{
		$parameters = array(
			"app_id"		=> $app_id,
			"limit" 		=> $limit,
			"offset" 		=> $offset,
			"t" 			=> '-526898600',
			"type" 			=> 'best-sellers',
			"genre_ids" 	=> $genre_ids,
		);
	} else {
		$parameters = array(
			"app_id"		=> $app_id,
			"limit" 		=> $limit,
			"offset" 		=> $offset,
			"t" 			=> '-526898600',
			"type" 			=> 'best-sellers',
		);
	}
	$request = alphabeticalQuery($parameters);
		
	$query = 'http://www.qobuz.com/api.json/0.2/album/getFeatured?' . $request;
		
	@$raw_data = stream_open($query, "http://www.qobuz.com/", 'www.qobuz.com', false);
	//var_dump($raw_data);
			
		try {
			if (substr($raw_data, 0, 15) == "<methodResponse" || substr($raw_data, 0, 5) == "<?xml")
				{
					$xml = simplexml_load_string($raw_data);
					$json = json_encode($xml);
					//echo $json;
				}
			else
				{
					$json = $raw_data;
				}
		} catch(Exception $ex){
			$json = 'Error while retrieving tracks, try again in few moments..';
				
		}
			
	echo $json;
		
?>