
# from waitress import serve
from typing import Optional
import json
import os
import numpy as np
from pydantic.networks import HttpUrl
from pydantic.types import FilePath

from fastapi import FastAPI
from fastapi.openapi.utils import get_openapi
import  pydantic
from pydantic import BaseModel
import   _documentaions as docz
from cls_NNS_SCANN import cls_NNS_SCANN
import ast
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="A DigiNava Api",
        version="399.10.0",
        description="An API to search for top N songs similar to a provided one.",
        routes=app.routes,
    )
    openapi_schema["info"]["x-logo"] = {
        "url": "http://www.diginava.com/asstes/img/basic/favicon.ico"
    }
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app = FastAPI(title = "a DigiNava Api." ,openapi_tags=docz.tags_metadata)

app.openapi = custom_openapi



# from fastapi.responses import HTMLResponse
# @app.get("/intro/", response_class=HTMLResponse)
# async def read_items():
#     return """
#     <html>
#         <head>
#             <title>Some HTML in here</title>
#         </head>
#         <body>
#             <h1>Look ma! HTML!</h1>
#         </body>
#     </html>
#     """

@app.get("/", tags=["root"])
def read_root():
    return {"state": "Up and running."}


@app.get("/info",  tags=["info"])
def get_info():
    return {"DB":"you need to provide a path to database file. It could be in json or a zipped json file formats."}

@app.get("/head",  tags=["head"])
def get_head():
    if not cls_scann.db.empty:
        return cls_scann.gethead()
    else:
        return {'message':"Data Base is Empty."}



def numpy_encoder(object):
    if isinstance(object, np.generic):
        return object.item()


@app.get("/id/{a_dina_ID}/{topnid}",  tags=["id"])
def get_id(a_dina_ID:str, topnid:int):
 
    return ast.literal_eval(json.dumps(cls_scann.recommend_by_id(a_dina_ID, topnid), default=numpy_encoder))
import ast
@app.get("/isrc/{an_isrc}/{topnisrc}",  tags=["isrc"])
def get_isrc(an_isrc:str, topnisrc:int):
   
    return ast.literal_eval(json.dumps(cls_scann.recommend_by_isrc(an_isrc, topnisrc), default= numpy_encoder))

# @app.get("/similar/{n}/{a_vector}",  tags=["similar"])
# def get_id(n:int, a_vector:str):
#     return {}


@app.post("/reindex/",  tags=["reindex"])
def get_reindex():#aurl: FilePath,  ):    
    
    cls_scann.reloadandreindex(cls_scann.URIdb, cls_scann.jmespath_to_idisrcvec, 
                               cls_scann.idx_id, cls_scann.idx_isrc, cls_scann.idx_vec)
    return {}#"url":aurl}





# if __name__ == '__main__':    
if 'DB_NAME' in os.environ:
    _dbname = os.environ.get('DB_NAME')
else:
    _dbname =   'db/db.json'

if 'JMESPATH_TO_IDISRCVEC' in os.environ:
    _jmespath = str(os.environ.get('JMESPATH_TO_IDISRCVEC'))
else:
    _jmespath = "[].[id,isrc,vec]"

if 'DIGINAVA_NN_IDX_ID' in os.environ:
    _idx_id = os.environ.get('DIGINAVA_NN_IDX_ID')
else:
    _idx_id = 0
            
if 'DIGINAVA_NN_IDX_ISRC' in os.environ:
    _idx_isrc = os.environ.get('DIGINAVA_NN_IDX_ISRC')
else:
    _idx_isrc = 1

if 'DIGINAVA_NN_IDX_VEC' in os.environ:
    _idx_vec = os.environ.get('DIGINAVA_NN_IDX_VEC')
else:
    _idx_vec = 2

print(_dbname)
print(_jmespath)
print(_idx_id)
print(_idx_isrc)
print(_idx_vec)




cls_scann = cls_NNS_SCANN(  _dbname, 
                            jmespath_to_idisrcvec= _jmespath, 
                            idx_id= _idx_id, 
                            idx_isrc=_idx_isrc,
                            idx_vec= _idx_vec)




