<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';
// Asynchronous request
require dirname(__FILE__) . '/library/vendor/autoload.php';
use mpyw\Co\Co;
use mpyw\Co\CURLException;

//
function curl_async_put($url, array $options = [], $user_token = ''){
    if ( $user_token == '' )
    {
        $headers = array(
            "Content-Type: application/json",
        );
    } else
    {
        $headers = array(
            "Content-Type: application/json",
            "user-token: " . $user_token,
        );
    }


    $ch = curl_init();
    $options = array_replace([
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_CUSTOMREQUEST => "PUT",
        CURLOPT_POSTFIELDS => json_encode(''),
    ], $options);
    curl_setopt_array($ch, $options);
    return $ch;
}

//
function curl_async_post($url, array $headers = [], array $data = [], array $options = []){

    $ch = curl_init();
    $options = array_replace([
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode($data),
    ], $options);
    curl_setopt_array($ch, $options);
    return $ch;
}

//
function curl_async_get($url, array $options = [], $user_token = ''){
    if ( $user_token == '' )
    {
        $headers = array(
            "Content-Type: application/json",
        );
    } else
    {
        $headers = array(
            "Content-Type: application/json",
            "user-token: " . $user_token,
        );
    };

    $ch = curl_init();
    $options = array_replace([
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_POSTFIELDS => json_encode(''),
    ], $options);
    curl_setopt_array($ch, $options);
    return $ch;
}

//
function set_geo_devices( $uuid, $device_name = '', $device_model = '', $device_brand = '', $device_size = '', $device_os = '', $device_api = '', $device_abis = '', $device_id = '', $device_token = '',  $geo_lat, $geo_lon, $geo_country = '', $geo_city = '', $network_type = '', $sim_operator = '', $is_tablet = '', $app_id, $app_name, $user_token, $session_id ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		$geo_devices = 'geo_devices';
		
		if ( $user_objectId == $provided_user_id )
		{
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/geo/points';
            $database_device_registration_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/messaging/registrations';
			$database_headers = array(
				"Content-Type: application/json",
				"user-token: " . $session_id_decrypted,
			);
			$data_geo_meta_devices = array(
				'___class'					=> 'Users_Devices',
				'uuid'						=> $uuid,
				'device_name'				=> $device_name,
				'device_model'				=> $device_model,
				'device_brand'				=> $device_brand,
				'device_size'				=> $device_size,
				'device_os'					=> $device_os,
				'device_api'				=> $device_api,
				'device_abis'				=> $device_abis,
				'device_id'					=> $device_id,
				'device_token'				=> $device_token,
				'network_type'				=> $network_type,
				'sim_operator'				=> $sim_operator,
				'is_tablet'					=> (bool)$is_tablet,
			);
			$data_geo_meta_info = array(
				'uuid'			  			=> $uuid,
				'city'						=> $geo_city,
				'country'					=> $geo_country,
				'brand'						=> $device_brand,
				'size'						=> $device_size,
				'api'						=> $device_api,
				'sim'						=> $sim_operator,
				'is_tablet'					=> (bool)$is_tablet,
				$geo_devices				=> $data_geo_meta_devices,
			);
			$data_set_geo_devices = array(
				'latitude'					=> (double)$geo_lat,
				'longitude'					=> (double)$geo_lon,
				'categories'				=> array(APP_PRETTY_NAME, APP_ENV_MOBILE_V1),
				'metadata'					=> $data_geo_meta_info,
			);
			$data_device_registration = array(
				'deviceToken'				=> $device_token,
				'deviceId'					=> $device_id,
				'os'				        => "ANDROID", // Change if multiple apps or Os
				'osVersion'					=> $device_api,
				//'channels'					=> ["default", "private", "promotions", "news", "gifts"], // List of channels to be registered
				'channels'					=> ["default"], // List of channels to be registered
			);

            $set_device_registration = Co::wait([

                "0" => function () use ($database_device_registration_url, $database_headers, $data_device_registration) {
                    $content = (yield curl_async_post( $database_device_registration_url, $database_headers, $data_device_registration ));
                    //yield Co::RETURN_WITH =>$content; // PHP 5.6
                    return $content; // PHP 7+
                },

            ]);
			
			try {
				@$database_results = sendBackendlessRequest( $database_url, $database_headers, json_encode($data_set_geo_devices) );
				@$database_results_array = json_decode($database_results, true);
			
			} catch (Exception $ex){
				sendError( 'setUserGeoDevices', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , uuid: ' . @$uuid . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}
			
			if ( !empty($database_results_array) )
			{
				if ( empty($database_results_array['code']) )
				{			
					$created_owner_id = $database_results_array['geopoint']['metadata'][$geo_devices]['ownerId'];
					$created_object_id = $database_results_array['geopoint']['metadata'][$geo_devices]['objectId'];
						
					$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $created_owner_id . '/user_devices';
					$relation_data = array(
						'objectId' 	 => $created_object_id
					);
						
					try {
						updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
						
					} catch (Exception $ex){
						sendError( 'setUserGeoDevices_relationUpdate', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , geo_objectId: ' . @$created_object_id . ' , app_id: ' . @$app_id . ' and time: ' . time() );
					}
						
					return status_code(201);
					
				} else {
					echo status_code(412);
					exit;
				}
				
			} else { // Nothing returned from the server
				echo status_code(404);
				exit;
			}
		
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function set_devices( $uuid, $device_name = '', $device_model = '', $device_brand = '', $device_size = '', $device_os = '', $device_api = '', $device_abis = '', $device_id = '', $device_token = '', $network_type = '', $sim_operator = '', $is_tablet = '', $app_id, $app_name, $user_token, $session_id ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users_Devices';
            $database_device_registration_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/messaging/registrations';
            $database_headers = array(
                "Content-Type: application/json",
                "user-token: " . $session_id_decrypted,
            );
			$data_set_devices = array(
				'uuid'		  			   	=> $uuid,
				'device_name'				=> $device_name,
				'device_model'	 			=> $device_model,
				'device_brand' 	  			=> $device_brand,
				'device_size'  	  			=> $device_size,
				'device_os'	   	  			=> $device_os,
				'device_api'				=> $device_api,
				'device_abis'				=> $device_abis,
				'device_id'					=> $device_id,
				'device_token'				=> $device_token,
				'network_type'				=> $network_type,
				'sim_operator'				=> $sim_operator,
				'is_tablet'					=> (bool)$is_tablet,
			);
            $data_device_registration = array(
                'deviceToken'				=> $device_token,
                'deviceId'					=> $device_id,
                'os'				        => "ANDROID", // Change if multiple apps or Os
                'osVersion'					=> $device_api,
                //'channels'					=> ["default", "private", "promotions", "news", "gifts"], // List of channels to be registered
                'channels'					=> ["default"], // List of channels to be registered
            );

            $set_device_registration = Co::wait([

                "0" => function () use ($database_device_registration_url, $database_headers, $data_device_registration) {
                    $content = (yield curl_async_post( $database_device_registration_url, $database_headers, $data_device_registration ));
                    //yield Co::RETURN_WITH =>$content; // PHP 5.6
                    return $content; // PHP 7+
                },

            ]);
			
			try {
				@$database_results = updateBackendlessRequest( $database_url, $database_headers, json_encode($data_set_devices) );
				@$database_results_array = json_decode($database_results, true);
			
			} catch (Exception $ex){
				sendError( 'setUserDevices', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , uuid: ' . @$uuid . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}
			
			if ( !empty($database_results_array) )
			{
				if ( empty($database_results_array['code']) )
				{			
					$created_owner_id = $database_results_array['ownerId'];
					$created_object_id = $database_results_array['objectId'];
						
					$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $created_owner_id . '/user_devices';
					$relation_data = array(
						'objectId' 	 => $created_object_id
					);
						
					try {
						updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
						
					} catch (Exception $ex){
						sendError( 'setUserDevices_relationUpdate', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , devices_objectId: ' . @$created_object_id . ' , app_id: ' . @$app_id . ' and time: ' . time() );
					}
						
					return status_code(201);
					
				} else {
					echo status_code(412);
					exit;
				}
				
			} else { // Nothing returned from the server
				echo status_code(404);
				exit;
			}
		
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json(){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'success',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> json_decode('{}')
		)
	);
	
	return json_encode($output);
}

?>