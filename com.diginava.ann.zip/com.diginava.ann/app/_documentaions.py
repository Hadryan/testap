tags_metadata = [
    {
        "name": "root",
        "description": "Simple health check.",
    },
    {
        "name": "info",
        "description": "Returns Information about the current loaded data.",
    },
    {
        "name": "head",
        "description": "Returns head of the indexed database to show a glimpse of it.",
    },
    {
        "name": "id",
        "description": "return vector of a given id (DINAID)",
    },
    {
        "name": "isrc",
        "description": "return vector of a given isrc",
    },

    {
        "name": "similar",
        "description": "Takes N and VECTOR as parameters and returns top N vectors that are similar to VEC.",
    },
        {
        "name": "reindex",
        "description": "Takes an optional file uri as input (or assume 'db/db.json' be default) and reindex it to be used for future calls.",
    },

    # {
    #     "name": "items",
    #     "description": "Manage items. So _fancy_ they have their own docs.",
    #     "externalDocs": {
    #         "description": "Items external docs",
    #         "url": "https://fastapi.tiangolo.com/",
    #     },
    # },
]