<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';

function temp_md5_decrypt($id){
	$decrypted_id = remove_non_utf8(md5_decrypt($id, MD5_ID_MASTERKEY));
	$constructed_id = explode(':', $decrypted_id);
	return $constructed_id[1];
}

//
function get_charts( $type, $limit, $offset, $genre_ids = '') {

	$genre_ids_original = $genre_ids;
	if ( !empty($genre_ids) )
	{
		$genre_ids = implode(",", array_map('temp_md5_decrypt', explode(',', $genre_ids )));
	}
		
	$query = 'http://i-serp.com/fetchFeatured.php?q=' . $type . '&l=' . $limit . '&o=' . $offset . ( $genre_ids ? '&g=' . $genre_ids : '');
	@$raw_data = stream_open($query, 'http://i-serp.com/', 'i-serp.com');
	@$data = json_decode($raw_data, true);
	
	if ( @$data["status"] == "error" || empty($data) ) 
	{
		$query = 'http://muism.com/v1/fetchFeatured.php?q=' . $type . '&l=' . $limit . '&o=' . $offset . ( $genre_ids ? '&g=' . $genre_ids : '');
		@$raw_data = stream_open($query, 'http://muism.com/', 'muism.com');
		@$data = json_decode($raw_data, true);
			
			if ( @$data["status"] == "error" || empty($data) ) 
			{
				$query = ORIGINALAPI . 'album/getFeatured?app_id=' . ORIGINALAPPID . '&type=' . $type . '&limit=' . $limit . '&offset=' . $offset . ( $genre_ids ? '&genre_ids=' . $genre_ids : '');
				@$raw_data = stream_open($query, 'http://www.qobuz.com/', 'www.qobuz.com');
				@$data = json_decode($raw_data, true);
			}
	}
	
	@$parent_response_offset = $data['albums']['offset'];
	@$parent_response_limit = $data['albums']['limit'];
	@$parent_response_total = $data['albums']['total'];
	@$parent_response_items = $data['albums']['items'];
	$current_time = time();
	$reduced_from_total = 0;
	
	// Foreach correction ! http://stackoverflow.com/a/15150384
	$response_array = isset($parent_response_items[0]) ? $parent_response_items : array($parent_response_items);
	foreach($response_array as $itme_num => $data) {
		if ( !empty($data) && empty($data['status']) )
		{
			if ( filter_unwanted_albums($data["id"]) == 1 )
			{
				$reduced_from_total++;
				continue;
				
			} else {
				
				@$data_image = $data["image"]["large"];
				if ( empty($data_image) )
				{
					$data_image = APIENDPOINT . URLVERSION . '/' . 'dot.png';
				}
				@$data_image = image_corrector($data_image);
				@$data_id = $data["id"];
				@$data_title = $data["title"];
				//@$data_slug = $data["slug"]; // We don't want to use the original slug, provided !
				@$data_slug = make_slug(hdryn_change_france($data_title));
				@$data_description = $data["description"];
				
				@$data_composer = $data["composer"]["name"];
				@$data_comp_id = $data["composer"]["id"];
				@$data_comp_albums_count = $data["composer"]["albums_count"];
				@$data_comp_slug = $data["composer"]["slug"];
				@$link_comp_slug = make_slug(hdryn_change_france($data_composer)); // Clean slug for composer
				
				@$data_artist = $data["artist"]["name"];
				@$data_artist_id = $data["artist"]["id"];
				@$data_artist_albums_count = $data["artist"]["albums_count"];
				@$data_artist_slug = $data["artist"]["slug"];
				@$link_artist_slug = make_slug(hdryn_change_france($data_artist)); // Clean slug for artist
				
				@$data_label = $data["label"]["name"];
				@$data_label_id = $data["label"]["id"];
				@$data_label_albums_count = $data["label"]["albums_count"];
				@$data_label_slug = $data["label"]["slug"];
				@$data_label_slug = make_slug($data_label); // Clean slug for label
				
				// Maybe use later
				@$data_period = $data["period"]["name"];
				@$data_period_id = $data["period"]["id"];
				
				@$data_instrument = $data["instrument"]["name"];
				@$data_instrument_id = $data["instrument"]["id"];
				
				@$data_area = $data["area"]["name"];
				@$data_area_id = $data["area"]["id"];
				//
				
				@$data_pdf = $data["goodies"][0]["description"];
				@$data_pdf_url = $data["goodies"][0]["original_url"];
				@$data_swf_url = $data["goodies"][0]["url"];
				if ( $data_pdf_url )
				{
					$path = $data_pdf_url;
					$pdf_id = basename($path); 
					$pdf_link = SAMPLESERVER . 'pdf.php?id=' . $pdf_id ; // TODO: make this file !
				}
				
				@$data_genre_id_1 = $data["genre"]["path"][0];
				@$data_genre_id_2 = $data["genre"]["path"][1];
				@$data_genre_id_3 = $data["genre"]["path"][2];
				@$data_genre_id_4 = $data["genre"]["path"][3];
				
				@$data_copyright = has_copyright_sign(remove_duplicate_copyright($data["copyright"]));
				@$data_recording_information = $data["recording_information"];
				
				@$data_released = $data["released_at"];
				
				@$data_duration = $data["duration"];
				@$data_media = $data["media_count"];
				@$data_tracks = $data["tracks_count"];
				
				@$data_popularity = $data["popularity"];
				@$data_product_sales_weekly = $data["product_sales_factors_weekly"];
				@$data_product_sales_monthly = $data["product_sales_factors_monthly"];
				@$data_product_sales_yearly = $data["product_sales_factors_yearly"];
				
				@$data_product_type = $data["product_type"];
				
				@$data_recording_information = $data["recording_information"];
				
				@$data_sampling = $data["maximum_sampling_rate"];
				@$data_depth = $data["maximum_bit_depth"];
			
				@$data_purchasable_at = $data["purchasable_at"];
				@$data_streamable_at = $data["streamable_at"];
				@$data_purchasable = $data["purchasable"];
				@$data_streamable = $data["streamable"];
				@$data_previewable = $data["previewable"];
				@$data_sampleable = $data["sampleable"];
				@$data_downloadable = $data["downloadable"];
				@$data_displayable = $data["displayable"];
			
				@$data_hires = $data["hires"];
			
				@$data_awards = $data["awards"]; // Will use later
			
				@$data_tracks_offset = $data["tracks"]["offset"];
				@$data_tracks_limit = $data["tracks"]["limit"];
				@$data_tracks_total = $data["tracks"]["total"];
				@$data_items = $data["tracks"]["items"];
				
			
					if ( $data_genre_id_1 )
					{
						$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_1), "name"=>ic_genres($data_genre_id_1), "name_fa"=>ic_genres_fa($data_genre_id_1));
					}
					if ( $data_genre_id_2 )
					{
						$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_2), "name"=>ic_genres($data_genre_id_2), "name_fa"=>ic_genres_fa($data_genre_id_2));
					}
					if ( $data_genre_id_3 )
					{
						$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_3), "name"=>ic_genres($data_genre_id_3), "name_fa"=>ic_genres_fa($data_genre_id_3));
					}
					if ( $data_genre_id_4 )
					{
						$genre_array[] = array("id"=>construct_the_id(QOBUZSERVICE . 'Genre', $data_genre_id_4), "name"=>ic_genres($data_genre_id_4), "name_fa"=>ic_genres_fa($data_genre_id_4));
					}
					
					@$album_id = checkSafeValue( construct_the_id(QOBUZSERVICE . 'Album', $data_id), null );
					@$album_title = hdryn_change_france($data_title);
					@$album_genre = $genre_array;
					@$album_image = array(
						"50"   => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 50 . ':' . $data_id) . '.jpg',
						"230"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 230 . ':' . $data_id) . '.jpg',
						"600"  => ASSETSSERVER . 'covers/' . construct_the_id(QOBUZSERVICE . 'Cover', 600 . ':' . $data_id) . '.jpg',
					);
					@$album_composer = array(
						"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_comp_id), null ),
						"name"  => hdryn_change_france($data_composer),
						"slug"  => make_slug(hdryn_change_france($data["composer"]["name"])),
						"albums_count"  => $data_comp_albums_count 
					);
					@$album_artist = array(
						"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Artist', $data_artist_id), null ),
						"name"  => hdryn_change_france($data_artist),
						"slug"  => make_slug(hdryn_change_france($data["artist"]["name"])),
						"albums_count"  => $data_artist_albums_count 
					);
					@$album_label = array(
						"id"  	=> checkSafeValue( construct_the_id(QOBUZSERVICE . 'Label', $data_label_id), null ),
						"name"  => $data_label,
						"slug"  => make_slug(hdryn_change_france($data["label"]["name"])),
						"albums_count"  => $data_label_albums_count 
					);
				@$album_booklet = $pdf_link;
				@$album_copyright = $data_copyright;
				@$album_program = $data_program;
				@$album_released_at = $data_released;
				@$album_duration = $data_duration;
				@$album_media_count = $data_media;
				@$album_tracks_count = $data_tracks;
				@$album_sampling_rate = $data_sampling;
				@$album_bit_depth = $data_depth;
				@$album_hires = $data_hires;
				@$album_url = SITEURL . 'album' . '/' . $album_id . '-' . $data_slug . ($link_artist_slug ? '-' . $link_artist_slug : '') . ($link_comp_slug ? '-' . $link_comp_slug : '') . '.html';
				
				$album_can_preview = false;
				if ( $data_sampleable == 1 )
				{
					$album_can_preview = true;
				}
				
				$album_can_buy = false;
				$album_can_buy_at = null;
				if ( !is_null($data_streamable_at) )
				{
					$album_can_buy_at = $data_streamable_at;
					
					if ( $album_can_buy_at < $current_time )
					{
						$album_can_buy = true;
					}
				}
			
				@$album_tracks_offset = $data_tracks_offset;
				@$album_tracks_limit = $data_tracks_limit;
				@$album_tracks_total = $data_tracks_total;
			
			
				// Foreach correction ! http://stackoverflow.com/a/15150384
				$awards_array = isset($data_awards[0]) ? $data_awards : array($data_awards);
				foreach($awards_array as $num => $award){
					$album_awards[] = array("id"=>checkSafeValue( construct_the_id(QOBUZSERVICE . 'Award', $award['award_id']), null ), "name"=>$award['name'], "name_fa"=>'', "awarded_at"=>$award['awarded_at']);
				}
				
				$items[] = array(
					"id"		  				   => $album_id,
					"title"						   => $album_title,
					"image"						   => $album_image,
					//"composer"					   => (!empty($album_composer['name']) ? $album_composer : null),
					"artist"					   => (!empty($album_artist['name']) ? $album_artist : various_artists()),
					"label"						   => (!empty($album_label['name']) ? $album_label : null),
					//"awards"					   => (!empty($album_awards[0]['name']) ? $album_awards : null),
					"genre"						   => $album_genre,
					//"copyright"					   => (!empty($album_copyright) ? $album_copyright : null),
					"url"				 		   => $album_url,
					"media_count"				   => $album_media_count,
					"tracks_count"				   => $album_tracks_count,
					"duration"					   => $album_duration,
					"released_at"				   => $album_released_at,
					"can_preview"				   => $album_can_preview,
					"can_buy"					   => $album_can_buy,
					"can_buy_at"				   => $album_can_buy_at,
					"sampling_rate"				   => $album_sampling_rate,
					"bit_depth"				 	   => $album_bit_depth,
					"hires"				 		   => $album_hires
				);
			
				unset($album_awards);
				unset($genre_array);
				unset($album_genre);
			}
			
		} else { // Nothing returned from the server
			echo status_code(404);
			exit;
		}
	}
	

	@$op_time = $current_time;
	@$op_offset = $parent_response_offset;
	@$op_limit = $parent_response_limit;
	@$op_total = $parent_response_total - $reduced_from_total;
	@$op_more_results = has_more_results($op_offset, $op_limit, $parent_response_total);
	@$op_results = ( !empty($items) ? $items : [] );
	@$op_right = 'Copyright ' . html_entity_decode('&copy;') . ' ' . date("Y") . ', ' . APINAME . '. All Rights Reserved.';
	@$op_url = '';
	
	$export = response_json($op_time, $op_offset, $op_limit, $op_total, $op_results, $op_right, $op_url, $op_more_results);
	// Creating temporary cache file
	temp_creator_on_server( basename(__FILE__, '_functions.php'), 'charts' . back_category_type($type) . $limit . $offset . $genre_ids_original, $export );
	
	return $export;

}

//
function response_json($op_time, $op_offset, $op_limit, $op_total, $op_results, $op_right, $op_url = '', $op_more_results){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'ok',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> array(
				'endpoint'		=> basename(__FILE__, '_functions.php'),
				'timestamp'		=> $op_time,
				'offset'		=> $op_offset,
				'limit'			=> $op_limit,
				'total'			=> $op_total,
				'more_results'	=> $op_more_results,
				'results'		=> $op_results,
				'copyright'		=> $op_right,
				//'url'		=> $op_url,
			)
		)
	);
	
	return json_encode($output);
}

?>