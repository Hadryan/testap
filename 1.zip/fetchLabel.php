<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(30);
header("Access-Control-Allow-Origin: *");
header("Content-Type:application/json");

include dirname(__FILE__) . '/functions.php';

	$q = $_GET['q'];
	$limit = $_GET['l'];
	$offset = $_GET['o'];
	@$app_id = $_GET['app_id'];
	@$app_secret = $_GET['app_secret'];
	if ( empty($app_id) )
	{
		$app_id = QOBUZAPPID;
	}
	if ( empty($app_secret) )
	{
		$app_secret = QOBUZAPPSECRET;
	}

	if ( $q  )
	{
		$parameters = array(
			"label_id" 		=> $q,
			"app_id"		=> $app_id,
			"limit" 		=> $limit,
			"offset" 		=> $offset,
			"t" 			=> '-526898600',
			"extra" 		=> 'albums'
		);
		
		$request = alphabeticalQuery($parameters);
		$query = 'http://www.qobuz.com/api.json/0.2/label/get?' . $request;
		
		$info = new SPLFileInfo($query);
		$file = $info->openFile('r');
		
		$buffer = '';
		while (!$file->eof()) {
			$buffer .= $file->fgets();
		}
		$info = null;
		$raw_data = $buffer;
			
			try {
				if (substr($raw_data, 0, 15) == "<methodResponse" || substr($raw_data, 0, 5) == "<?xml")
					{
						$xml = simplexml_load_string($raw_data);
						$json = json_encode($xml);
						//echo $json;
					}
				else
					{
						$json = $raw_data;
					}
			} catch(Exception $ex){
				$json = 'Error while retrieving tracks, try again in few moments..';
				
			}
			
		echo $json;

	}
?>