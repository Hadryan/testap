<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(13);

define("APIVERSION", 					"2.0");

//
function status_code($status = 200, $message = ''){
	if ( $status == '200' )
	{
		http_response_code(200);
		header("Status: 200 OK");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"ok","code":200,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the api works perfectly.')) . ',"data":{}}}';
	} elseif ( $status == '201' )
	{
		http_response_code(201);
		header("Status: 201 Created");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"created","code":201,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the request has been fulfilled successfully.')) . ',"data":{}}}';
	} elseif ( $status == '400' )
	{
		http_response_code(400);
		header("Status: 400 Bad Request");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"bad request","code":400,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('there was a problem with your request.')) . ',"data":{}}}';
	} elseif ( $status == '401' )
	{
		http_response_code(401);
		header("Status: 401 Unauthorized");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"unauthorized","code":401,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('access is denied due to invalid credentials.')) . ',"data":{}}}';
	} elseif ( $status == '402' )
	{
		http_response_code(402);
		header("Status: 402 Request Failed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"request failed","code":402,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('parameters were valid but request failed.')) . ',"data":{}}}';
	} elseif ( $status == '403' )
	{
		http_response_code(403);
		header("Status: 403 Forbidden");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"forbidden","code":403,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('no permission to access the resource.')) . ',"data":{}}}';
	} elseif ( $status == '404' )
	{
		http_response_code(404);
		header("Status: 404 Not Found");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"not found","code":404,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('no result is matched for given arguments.')) . ',"data":{}}}';
	} elseif ( $status == '405' )
	{
		http_response_code(405);
		header("Status: 405 Method Not Allowed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"method not allowed","code":405,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the method is not supported by the server.')) . ',"data":{}}}';
	} elseif ( $status == '408' )
	{
		http_response_code(408);
		header("Status: 408 Request Timeout");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"request timeout","code":408,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server did not receive a complete request message within the time.')) . ',"data":{}}}';
	} elseif ( $status == '409' )
	{
		http_response_code(409);
		header("Status: 409 Conflict");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"conflict","code":409,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the request could not be completed due to a conflict.')) . ',"data":{}}}';
	} elseif ( $status == '410' )
	{
		http_response_code(410);
		header("Status: 410 Gone");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"gone","code":410,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the resource is no longer available.')) . ',"data":{}}}';
	} elseif ( $status == '412' )
	{
		http_response_code(412);
		header("Status: 412 Precondition Failed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"precondition failed","code":412,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server does not meet one of the preconditions.')) . ',"data":{}}}';
	} elseif ( $status == '417' )
	{
		http_response_code(417);
		header("Status: 417 Expectation Failed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"expectation failed","code":417,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server cannot meet the requirements.')) . ',"data":{}}}';
	} elseif ( $status == '422' )
	{
		http_response_code(422);
		header("Status: 422 Unprocessable Entity");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"unprocessable entity","code":422,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the request was well-formed but was unable to be followed')) . ',"data":{}}}';
	} elseif ( $status == '428' )
	{
		http_response_code(428);
		header("Status: 428 Precondition Required");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"precondition required","code":428,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server requires preconditions.')) . ',"data":{}}}';
	} elseif ( $status == '500' )
	{
		http_response_code(500);
		header("Status: 500 Internal Server Error");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"internal server error","code":500,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server encountered an unexpected condition.')) . ',"data":{}}}';
	} elseif ( $status == '501' )
	{
		http_response_code(501);
		header("Status: 501 Not Implemented");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"not implemented","code":501,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server does not support required functionality to fulfill the request.')) . ',"data":{}}}';
	} elseif ( $status == '502' )
	{
		http_response_code(502);
		header("Status: 502 Bad Gateway");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"bad gateway","code":502,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server got an invalid response.')) . ',"data":{}}}';
	} elseif ( $status == '503' )
	{
		http_response_code(503);
		header("Status: 503 Service Unavailable");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"service unavailable","code":503,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server is currently unable to handle the request.')) . ',"data":{}}}';
	} elseif ( $status == '504' )
	{
		http_response_code(504);
		header("Status: 504 Gateway Timeout");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"gateway timeout","code":504,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server could not process the request in a timely manner.')) . ',"data":{}}}';
	}
}
	// We use this file to output a dummy data for the nodes [apiDomain/, or apiDomain/v1/]

	@$status = $_GET['status'];
	$available_statuses = array("200", "201", "400", "401", "402", "403", "404", "405", "408", "409", "410", "412", "417", "422", "428", "500", "501", "502", "503", "504");
	if ( empty($status) || !in_array($status, $available_statuses) )
	{
		$status = 200;
	}
	
	@$file = 'internalSendOutput.php';
	@$last_modified_time = filemtime($file); 
	@$etag = md5($file . '?status=' . $status);

	header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
	header("Access-Control-Allow-Credentials: TRUE");
	header("Last-Modified: ".gmdate("D, d M Y H:i:s", $last_modified_time)." GMT"); 
	header("Etag: $etag");
	header("Content-type: application/json; charset=utf-8");
	header('Expires: '.gmdate('D, d M Y H:i:s \G\M\T', time() + (60 * 55))); // 55 min
	header("Pragma: cache");
	header("Cache-Control: public, max-age=" . (60 * 55));
	

	echo status_code($status);

?>