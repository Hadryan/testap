<?php

//
// Performance checker https://stackoverflow.com/a/2482007
function filter_white_albums($album_id){

	$white = array(
		'la1w6093lhqcb'   => 1,
		'ji4k38oq9hnua'   => 1,
		'0060255745568'   => 1,
		'0053479011725'   => 1,
		'0002894790663'   => 1,
		'j1kph6gxruy4b'   => 1,
		'g3vkk4zjp404a'   => 1,
		'0884463733176'   => 1,

		
		
		
		
		
		
		
		
		
		
		
		
		
		//''	  => 1,
		
	);

	if ( isset($white[$album_id]) )
	{
		return true;
		
	} else
	{
		return false;
	}
}

?>