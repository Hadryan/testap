<?php
define("APIVERSION",					"1.0");
define("MEDIAURI",						"f8fa8f8e70f843f991cdd3c83d3f3e88");
define("USERAGENT",						user_aget());
define("MD5_ID_MASTERKEY",				"zZf:a@5AqSd*T~_5^0|OrcQ?fF0=>ge&");
define("BUCKET_CONVERTIBLE",			"raw.diginava.com");
define("BUCKET_STREAMING",				"stream3ynnzgpuzaludtrgpc5wzmhzjcsoua06mkp03ktd7s3s4269cv7s5atj");
date_default_timezone_set("UTC");

require dirname(__FILE__) . '/library/vendor/autoload.php';
use FastBill\ParallelProcessDispatcher\Process;
use FastBill\ParallelProcessDispatcher\Dispatcher;

//
function export_audio_preview($id, $memory_usage = '128M'){ // @TODO: Change time cache & bucket name
	
	$quality_d_name = 'd'; // Based on our Lambda transcoding schema in aws
	$quality_d_value = '128k'; // Based on our Lambda transcoding schema in aws
	
	$decrypted_id = remove_non_utf8(md5_decrypt($id, MD5_ID_MASTERKEY));
	$constructed_id = explode(':', $decrypted_id);
	$original_id = $constructed_id[1];

	// Check to see if already downloaded the source in the temp directory: useful for status=206 requests
	// https://stackoverflow.com/a/20866339
	if ( false !== stream_resolve_include_path(MEDIAURI . '/' . $id . $quality_d_name . '.m4a') )
	{
		// Streaming the audio
		$stream = new AudioStreamer(MEDIAURI . '/' . $id . $quality_d_name . '.m4a');
		$stream->start();
		
		return null;
	
	} elseif ( (false !== stream_resolve_include_path(MEDIAURI . '/' . $id)) && (true !== stream_resolve_include_path(MEDIAURI . '/' . $id . $quality_d_name . '.m4a')) ) { // mp3 file exists but the result m4a doesn't available
		
		$original_file = MEDIAURI . '/' . $id;
		
		exec('ffprobe "' . $original_file . '" -show_format 2>&1 | sed -n \'s/\(duration=\|size=\)//p\'', $file_array, $return_var);
		$file_duration = $file_array[0];
		$file_size = $file_array[1];
		
		ini_set('memory_limit', $memory_usage);
		
		$segment_size = 1000000;
		$segment_number = round($file_size / $segment_size) + 1;

		$control_time = round(microtime(true) * 1000);
		$no_output_wait = ' >/dev/null 2>/dev/null &';
		
		$dispatcher = new Dispatcher(1);    // will make sure only one of those will actually run at the same time
		for($i = 1; $i <= $segment_number; $i++) {
			${"process" . $i} = new Process('ffmpeg -n -i ' . $original_file . ' -ss ' . (($i - 1) * ($file_duration / $segment_number)) . ' -to ' . ($i * ($file_duration / $segment_number)) . ' -c:a pcm_s16le ' . MEDIAURI . '/' . $id . $i . '.mov');
			$dispatcher->addProcess(${"process" . $i}, true);
			$j = $i + 55000; // 55000 is a safe number we know that the process will never reach it!
			${"process" . $j} = new Process('echo file \'' . $id . $i . '.mov\'' . ' outpoint \'' . ($file_duration / $segment_number) . '\' >> ' . MEDIAURI . '/' . $id . $control_time . '.list');
			$dispatcher->addProcess(${"process" . $j}, true);
		}
		$processEnd = new Process('ffmpeg -f concat -i ' . MEDIAURI . '/' . $id . $control_time . '.list' . ' -c:v copy -strict -2 -movflags faststart ' . MEDIAURI . '/' . $id . $quality_d_name . '.m4a');
		$dispatcher->addProcess($processEnd, true);
		
		$dispatcher->tick();
		$dispatcher->dispatch();  // this will run until all processes are finished.
		$processes = $dispatcher->getFinishedProcesses();
		
		ini_set('memory_limit', -1);
		
		// Uploading the Audio files
		// https://stackoverflow.com/a/52620939
		$expire = time() + (60 * 60 * 24); // expires in 1 day 
		$processUploadMp3 = new Process('aws s3 cp ' . $original_file . ' s3://' . BUCKET_CONVERTIBLE . '/' . $id . '.mp3' . '  --expires ' . gmdate('Y-m-d\TH:i:s\Z', $expire) . $no_output_wait);
		$dispatcher->addProcess($processUploadMp3, true);
		$processUpload__d = new Process('aws s3 cp ' . MEDIAURI . '/' . $id . $quality_d_name . '.m4a' . ' s3://' . BUCKET_STREAMING . '/online/f8fa8f8e70f843f993cdd3c83d3f3e88/' . $id . $quality_d_name . '.m4a' . '  --acl public-read --cache-control public,max-age=604800,immutable --content-type audio/mp4 --storage-class INTELLIGENT_TIERING' . $no_output_wait);
		$dispatcher->addProcess($processUpload__d, true);
		$processUpload_tag = new Process('aws s3api put-object-tagging --bucket ' . BUCKET_STREAMING . ' --key \'' . 'online/f8fa8f8e70f843f993cdd3c83d3f3e88/' . $id . $quality_d_name . '.m4a\'' . ' --tagging \'TagSet=[{Key=quality,Value=' . $quality_d_value . '}]\'' . $no_output_wait);
		$dispatcher->addProcess($processUpload_tag, true);
		
		$dispatcher->tick();
		$dispatcher->dispatch();  // this will run until all processes are finished.
		$processes = $dispatcher->getFinishedProcesses();
		
		// Streaming the audio
		$stream = new AudioStreamer(MEDIAURI . '/' . $id . $quality_d_name . '.m4a');
		$stream->start();
		
		return null;
		
	} else {
		
		$sample_url = catch_orininal_sample($original_id);
		if ( !empty($sample_url) )
		{		
			$headers['Referer'] = 'https://play.qobuz.com/';
			$headers['Range'] = 'bytes=0-';
			$headers['Host'] = parse_url($sample_url, PHP_URL_HOST);
			$buffer = request($sample_url, 'GET', null, $headers);
			
			// Creating temporary directory
			$destination = $_SERVER['DOCUMENT_ROOT'] . '/' . MEDIAURI;
			if (!is_dir($destination)) {
				$make_directory = createPath($destination);
			}
			file_put_contents($destination . '/' . $id, $buffer);
			$original_file = MEDIAURI . '/' . $id;
			
			exec('ffprobe "' . $original_file . '" -show_format 2>&1 | sed -n \'s/\(duration=\|size=\)//p\'', $file_array, $return_var);
			$file_duration = $file_array[0];
			$file_size = $file_array[1];
			
			ini_set('memory_limit', $memory_usage);
			
			$segment_size = 1000000;
			$segment_number = round($file_size / $segment_size) + 1;
	
			$control_time = round(microtime(true) * 1000);
			$no_output_wait = ' >/dev/null 2>/dev/null &';
			
			$dispatcher = new Dispatcher(1);    // will make sure only one of those will actually run at the same time
			for($i = 1; $i <= $segment_number; $i++) {
				${"process" . $i} = new Process('ffmpeg -n -i ' . $original_file . ' -ss ' . (($i - 1) * ($file_duration / $segment_number)) . ' -to ' . ($i * ($file_duration / $segment_number)) . ' -c:a pcm_s16le ' . MEDIAURI . '/' . $id . $i . '.mov');
				$dispatcher->addProcess(${"process" . $i}, true);
				$j = $i + 55000; // 55000 is a safe number we know that the process will never reach it!
				${"process" . $j} = new Process('echo file \'' . $id . $i . '.mov\'' . ' outpoint \'' . ($file_duration / $segment_number) . '\' >> ' . MEDIAURI . '/' . $id . $control_time . '.list');
				$dispatcher->addProcess(${"process" . $j}, true);
			}
			$processEnd = new Process('ffmpeg -f concat -i ' . MEDIAURI . '/' . $id . $control_time . '.list' . ' -c:v copy -strict -2 -movflags faststart ' . MEDIAURI . '/' . $id . $quality_d_name . '.m4a');
			$dispatcher->addProcess($processEnd, true);
			
			$dispatcher->tick();
			$dispatcher->dispatch();  // this will run until all processes are finished.
			$processes = $dispatcher->getFinishedProcesses();
			
			ini_set('memory_limit', -1);
			
			// Uploading the Audio files
			// https://stackoverflow.com/a/52620939
			$expire = time() + (60 * 60 * 24); // expires in 1 day 
			$processUploadMp3 = new Process('aws s3 cp ' . $original_file . ' s3://' . BUCKET_CONVERTIBLE . '/' . $id . '.mp3' . '  --expires ' . gmdate('Y-m-d\TH:i:s\Z', $expire) . $no_output_wait);
			$dispatcher->addProcess($processUploadMp3, true);
			$processUpload__d = new Process('aws s3 cp ' . MEDIAURI . '/' . $id . $quality_d_name . '.m4a' . ' s3://' . BUCKET_STREAMING . '/online/f8fa8f8e70f843f993cdd3c83d3f3e88/' . $id . $quality_d_name . '.m4a' . '  --acl public-read --cache-control public,max-age=604800,immutable --content-type audio/mp4 --storage-class INTELLIGENT_TIERING' . $no_output_wait);
			$dispatcher->addProcess($processUpload__d, true);
			$processUpload_tag = new Process('aws s3api put-object-tagging --bucket ' . BUCKET_STREAMING . ' --key \'' . 'online/f8fa8f8e70f843f993cdd3c83d3f3e88/' . $id . $quality_d_name . '.m4a\'' . ' --tagging \'TagSet=[{Key=quality,Value=' . $quality_d_value . '}]\'' . $no_output_wait);
			$dispatcher->addProcess($processUpload_tag, true);
			
			$dispatcher->tick();
			$dispatcher->dispatch();  // this will run until all processes are finished.
			$processes = $dispatcher->getFinishedProcesses();
			
			// Streaming the audio
			$stream = new AudioStreamer(MEDIAURI . '/' . $id . $quality_d_name . '.m4a');
			$stream->start();
			
			return null;
			
		} else { // media sample_url is not available!
			
			header("Content-type: application/json; charset=utf-8");
			echo status_code(404);
			return false;
		}
		
	}
}

//
class AudioStreamer {
	// https://stackoverflow.com/a/39897793
    
    private $path = "";
    private $stream = "";
    private $buffer = 102400;
    private $start  = -1;
    private $end    = -1;
    private $size   = 0;
    
    function __construct($filePath) 
    {
        $this->path = $filePath;
    }
    
    /**
     * Open stream
     */
    private function open()
    {
        if (!($this->stream = fopen($this->path, 'rb'))) {
            die('Could not open stream for reading');
        }
    
    }
    
    /**
     * Set proper header to serve the video content
     */
    private function setHeader()
    {
        ob_get_clean();
        header("Content-Type: audio/m4a");
        header("Cache-Control: max-age=1814400, public");
        header("Expires: ".gmdate('D, d M Y H:i:s', time()+1814400) . ' GMT');
        header("Last-Modified: ".gmdate('D, d M Y H:i:s', @filemtime($this->path)) . ' GMT' );
        $this->start = 0;
        $this->size  = filesize($this->path);
        $this->end   = $this->size - 1;
        header("Accept-Ranges: 0-".$this->end);
    
        if (isset($_SERVER['HTTP_RANGE'])) {
    
            $c_start = $this->start;
            $c_end = $this->end;
    
            list(, $range) = explode('=', $_SERVER['HTTP_RANGE'], 2);
            if (strpos($range, ',') !== false) {
                header('HTTP/1.1 416 Requested Range Not Satisfiable');
                header("Content-Range: bytes $this->start-$this->end/$this->size");
                exit;
            }
            if ($range == '-') {
                $c_start = $this->size - substr($range, 1);
            }else{
                $range = explode('-', $range);
                $c_start = $range[0];
    
                $c_end = (isset($range[1]) && is_numeric($range[1])) ? $range[1] : $c_end;
            }
            $c_end = ($c_end > $this->end) ? $this->end : $c_end;
            if ($c_start > $c_end || $c_start > $this->size - 1 || $c_end >= $this->size) {
                header('HTTP/1.1 416 Requested Range Not Satisfiable');
                header("Content-Range: bytes $this->start-$this->end/$this->size");
                exit;
            }
            $this->start = $c_start;
            $this->end = $c_end;
            $length = $this->end - $this->start + 1;
            fseek($this->stream, $this->start);
            header('HTTP/1.1 206 Partial Content');
            header("Content-Length: ".$length);
            header("Content-Range: bytes $this->start-$this->end/".$this->size);
        }
        else
        {
            header("Content-Length: ".$this->size);
        }  
    
    }
    
    /**
     * close curretly opened stream
     */
    private function end()
    {
        fclose($this->stream);
        exit;
    }
    
    /**
     * perform the streaming of calculated range
     */
    private function stream()
    {
        $i = $this->start;
        set_time_limit(0);
        while(!feof($this->stream) && $i <= $this->end) {
            $bytesToRead = $this->buffer;
            if(($i+$bytesToRead) > $this->end) {
                $bytesToRead = $this->end - $i + 1;
            }
            $data = fread($this->stream, $bytesToRead);
            echo $data;
            flush();
            $i += $bytesToRead;
        }
    }
    
    /**
     * Start streaming video content
     */
    function start()
    {
        $this->open();
        $this->setHeader();
        $this->stream();
        $this->end();
    }
}

//
function catch_orininal_sample($track){
	
$track_stream = GetStream2($track);
	
if ( !empty($track_stream) )
{
	$result = $track_stream;
} else {
	$result = '';
}

return $result;
}

//
function GetStream2($track_id) {

$query = 'http://i-serp.com/fetchSample.php?id=' . $track_id;
@$raw_data = stream_open($query, 'http://i-serp.com/', 'i-serp.com', 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8');
@$data = json_decode($raw_data, true);
			
	if ( @$data["status"] == "error" || empty($data) || ( isset($data["restrictions"][1]["code"]) && $data["restrictions"][1]["code"] == "SampleRestrictedByRightHolders") ) 
	{
		$app_id          = "579169010";
		$app_secret      = "e28e9f3d71d274a605693111477d4fe2";
				
		$object          = 'track';
		$method          = 'getFileUrl';
		$parameters      = array('track_id' => $track_id, 'format_id' => 5);
		$request_ts      = time();
		$request_sig     = md5($object.$method.explodeForSignature($parameters).$request_ts.$app_secret);
				
		$query = sprintf('https://www.qobuz.com/api.json/0.2/%s/%s?%s', $object, $method, http_build_query(array_merge( $parameters, 
		array(
			'app_id'          => $app_id,
			'request_ts'      => $request_ts,
			'request_sig'     => $request_sig,
		)
		)));
				
		@$raw_data = stream_open($query, 'https://www.qobuz.com/', 'www.qobuz.com', 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8');
		@$data = json_decode($raw_data, true);
	}
	
if ( isset($data['restrictions']) && (empty($data["url"]) || is_null($data["url"])) || isset($data['status']) )
{
	echo status_code(404);
	return false;
}
return $data["url"];
}

//
function explodeForSignature($parameters) {
ksort($parameters);
$ret = '';
foreach ($parameters as $key => $value) {
	if (is_array($value)) {
		asort($value);
		$ret .= $key.implode('', array_values($value));
	} else {
		$ret .= $key.$value;
	}
}
return $ret;
}

//
function stream_open($url, $refer = 'http://www.google.com/', $host = 'google.com', $accept = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', $agent = USERAGENT, $https = false, $connection_alive = false ){
	
$options = array(
		
	CURLOPT_CUSTOMREQUEST  =>"GET",        //set request type post or get
	CURLOPT_POST           =>false,        //set to GET
		
	CURLOPT_RETURNTRANSFER => true,     // return web page
	CURLOPT_HEADER         => false,    // don't return headers
	CURLOPT_FOLLOWLOCATION => true,     // follow redirects
	CURLOPT_ENCODING       => "",       // handle all encodings
	CURLOPT_AUTOREFERER    => true,     // set referer on redirect
	CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
	CURLOPT_TIMEOUT        => 120,      // timeout on response
	CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
);
		
	$ch      = curl_init( $url );
		
	$cookie_string = "";
	$cookie_string .= "i18next=fr-FR; ";
		
		
	$headers = array();
	$headers[] = 'User-Agent: ' . $agent;
	$headers[] = 'Accept-Encoding: gzip, deflate';
	$headers[] = 'Accept-Language: fr-FR,fr;q=0.8,en-US;q=0.6,en;q=0.4';
	$headers[] = 'Host: ' . $host;
	$headers[] = 'Referer: '  . $refer;
	if ( $connection_alive == 1 )
	{
		$headers[] = 'Connection : keep-alive';
	}
	$headers[] = $accept;
	
		
	curl_setopt($ch, CURLOPT_URL, $url);  
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		if ( $https == 1 )
		{
			curl_setopt ($ch, CURLOPT_CAINFO, dirname(__FILE__)."/cacert.pem");
		}
			
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_ENCODING, '');
	curl_setopt($ch, CURLOPT_TIMEOUT, 55);
	curl_setopt($ch, CURLOPT_COOKIE, $cookie_string);
		
	curl_setopt_array( $ch, $options );
	$content = curl_exec( $ch );
	$err     = curl_errno( $ch );
	$errmsg  = curl_error( $ch );
	$header  = curl_getinfo( $ch );
	curl_close( $ch );
		
	$header['errno']   = $err;
	$header['errmsg']  = $errmsg;
	$header['content'] = $content;
return $header['content'];
}

//
function user_aget() {
	
	$random = array(
		1 => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
		2 => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36',
		3 => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
		4 => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2226.0 Safari/537.36',
		5 => 'Mozilla/5.0 (Windows NT 6.4; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36',
		6 => 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36',
		7 => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36',
		8 => 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36',
		9 => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.67 Safari/537.36',
			
		10 => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.2 (KHTML, like Gecko) ChromePlus/4.0.222.3 Chrome/4.0.222.3 Safari/532.2',
		11 => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.28.3 (KHTML, like Gecko) Version/3.2.3 ChromePlus/4.0.222.3 Chrome/4.0.222.3 Safari/525.28.3',
			
		12 => 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1',
		13 => 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0',
			
		14 => 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko',
		15 => 'Mozilla/5.0 (compatible, MSIE 11, Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko',
		16 => 'Mozilla/5.0 (compatible; MSIE 10.6; Windows NT 6.1; Trident/5.0; InfoPath.2; SLCC1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 2.0.50727) 3gpp-gba UNTRUSTED/1.0',
			
		17 => 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
		18 => 'Mozilla/5.0 (Linux; U; Android 4.0.3; de-ch; HTC Sensation Build/IML74K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
		19 => 'Mozilla/5.0 (Linux; U; Android 2.3.5; zh-cn; HTC_IncredibleS_S710e Build/GRJ90) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
		20 => 'Mozilla/5.0 (Linux; U; Android 2.3.4; fr-fr; HTC Desire Build/GRJ22) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
		21 => 'Mozilla/5.0 (Linux; U; Android 2.3.3; zh-tw; HTC_Pyramid Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari',
		22 => 'Mozilla/5.0 (Linux; U; Android 2.3.3; de-de; HTC Desire Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
		23 => 'Mozilla/5.0 (Linux; U; Android 2.2.1; en-gb; HTC_DesireZ_A7272 Build/FRG83D) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
		24 => 'Mozilla/5.0 (Linux; U; Android 2.2.1; en-ca; LG-P505R Build/FRG83) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
		25 => 'Mozilla/5.0 (Linux; U; Android 2.3.4; en-us; T-Mobile myTouch 3G Slide Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
		26 => 'Mozilla/5.0 (Linux; U; Android 4.0.3; en-us; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
		27 => 'Mozilla/5.0 (Linux; U; Android 2.3.3; en-us; LG-LU3000 Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1',
			
		28 => 'Mozilla/5.0 (compatible; MSIE 9.0; Windows Phone OS 7.5; Trident/5.0; IEMobile/9.0)',
			
		29 => 'Opera/12.02 (Android 4.1; Linux; Opera Mobi/ADR-1111101157; U; en-US) Presto/2.9.201 Version/12.02',
		30 => 'Opera/9.80 (S60; SymbOS; Opera Mobi/SYB-1107071606; U; en) Presto/2.8.149 Version/11.10',
		31 => 'Opera/9.80 (Android 2.3.3; Linux; Opera Mobi/ADR-1111101157; U; en-US) Presto/2.9.201 Version/11.50',
			
		// Repeating the chrome browser ! (favorite browser)
		32 => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
		33 => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36',
		34 => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
			
	);
	
	$selected = strtr(rand(1,sizeof($random)), $random);
	
return $selected;
}

//
function request($url, $method, $data = null, array &$headers = []) {
	// https://stackoverflow.com/a/38206024
	/*
	* Performs memory-safe HTTP request.
	*
	* @param string $url       Request URL, e.g. "https://example.com:23986/api/upload".
	* @param string $method    Request method, e.g. "GET", "POST", "PATCH", etc.
	* @param mixed $data       [optional] Data to pass with the request.
	* @param array $headers    [optional] Additional headers.
	*
	* @return string           Response body.
	*
	* @throws Exception
	*/

	static $schemes = [
		'https' => ['', 80],
		'http'  => ['', 80],
	];
	
	$u = parse_url($url);
	if (!isset($u['host']) || !isset($u['scheme']) || !isset($schemes[$u['scheme']])) {
		throw new Exception('URL parameter must be a valid URL.');
	}
	
	$scheme = $schemes[$u['scheme']];
	if (isset($u['port'])) {
		$scheme[1] = $u['port'];
	}
	
	$fp = @fsockopen($scheme[0] . $u['host'], $scheme[1], $errno, $errstr);
	if ($fp === false) {
		throw new Exception($errstr, $errno);
	}
	
	$uri = isset($u['path']) ? $u['path'] : '/';
	if (isset($u['query'])) {
		$uri .= '?' . $u['query'];
	}
	
	if (is_array($data)) {
		$data = http_build_query($data);
		$headers['Content-Length'] = strlen($data);
	} elseif ($data instanceof SplFileInfo) {
		$headers['Content-Length'] = $data->getSize();
	}
	
	$headers['Connection'] = 'close';
	
	fwrite($fp, sprintf("%s %s HTTP/1.1\r\n", $method, $uri));
	foreach ($headers as $header => $value) {
		fwrite($fp, $header . ': ' . $value . "\r\n");
	}
	fwrite($fp, "\r\n");
	
	if ($data instanceof SplFileInfo) {
		$fh = fopen($data->getPathname(), 'rb');
		while ($chunk = fread($fh, 4096)) {
			fwrite($fp, $chunk);
		}
		fclose($fh);
	} else {
		fwrite($fp, $data);
	}
	
	$response = '';
	while (!feof($fp)) {
		$response .= fread($fp, 1024);
	}
	fclose($fp);
	
	if (false === $pos = strpos($response, "\r\n\r\n")) {
		throw new Exception('Bad server response body.');
	}
	
	$headers = explode("\r\n", substr($response, 0, $pos));
	if (!isset($headers[0]) || strpos($headers[0], 'HTTP/1.1 ')) {
		throw new Exception('Bad server response headers.');
	}
	
	return substr($response, $pos + 4);
}

//
function octal_2_encrypt($string, $base = 9){

	return base_convert($string, 10, $base);
}

//
function encrypt_2_octal($string, $base = 9){

	return base_convert($string, $base, 10);
}

//
function make_directory($dirpath, $mode=0777) {
	return is_dir($dirpath) || mkdir($dirpath, $mode, true);
}

//
function createPath($path) {
	if (is_dir($path)) return true;
	$prev_path = substr($path, 0, strrpos($path, '/', -2) + 1 );
	$return = createPath($prev_path);
	
	return ($return && is_writable($prev_path)) ? mkdir($path) : false;
}

//
function createUploadDirectories($upload_path=null, $mode=0777){
    if($upload_path==null) return false;
    $upload_directories = explode('/',$upload_path);
    $createDirectory = array();
    foreach ($upload_directories as $upload_directory){
        $createDirectory[] = $upload_directory;
        $createDirectoryPath = implode('/',$createDirectory);
        if(!is_dir($createDirectoryPath)){
            $old = umask(0); 
            mkdir($createDirectoryPath, $mode);// Create the folde if not exist and give permission
            umask($old); 
        }
    }
    return true;
}

//
function md5_encrypt($plainText, $key) {
	// Based on Nanhe Kumar answer : https://stackoverflow.com/a/52253745/4013321
	$secretKey = hextobin(md5($key));
	$initVector = pack("C*", 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f);
	$openMode = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', 'cbc', '');
	$blockSize = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, 'cbc');
	$plainPad = pkcs5_pad($plainText, $blockSize);
	if (mcrypt_generic_init($openMode, $secretKey, $initVector) != -1) {
		$encryptedText = mcrypt_generic($openMode, $plainPad);
		mcrypt_generic_deinit($openMode);
	}
	return bin2hex($encryptedText);
}

//
function md5_decrypt($encryptedText, $key) {
		$secretKey = hextobin(md5($key));
		$initVector = pack("C*", 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f);
		$encryptedText = hextobin($encryptedText);
		$openMode = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', 'cbc', '');
		mcrypt_generic_init($openMode, $secretKey, $initVector);
		$decryptedText = mdecrypt_generic($openMode, $encryptedText);
		$decryptedText = rtrim($decryptedText, "\0");
		mcrypt_generic_deinit($openMode);
	return $decryptedText;
}

//
function pkcs5_pad($plainText, $blockSize){
	//*********** Padding Function *********************
	$pad = $blockSize - (strlen($plainText) % $blockSize);
	return $plainText . str_repeat(chr($pad), $pad);
}

//
function hextobin($hexString) {
	//********** Hexadecimal to Binary function for php 4.0 version ********
	$length = strlen($hexString);
	$binString = "";
	$count = 0;
	while ($count < $length) {
		$subString = substr($hexString, $count, 2);
		$packedString = pack("H*", $subString);
		if ($count == 0) {
			$binString = $packedString;
		} else {
			$binString .= $packedString;
		}

		$count += 2;
	}
	return $binString;
}

//
function map_service_to_endpoint($service_id) {
	
	$services_array = array(
		'1'			  =>		QOBUZSERVICE . 'Album',
		'2'			  =>		QOBUZSERVICE . 'Artist',
		'3'			  =>		QOBUZSERVICE . 'Label',
		'4'			  =>		QOBUZSERVICE . 'Genre',
		'5'			  =>		QOBUZSERVICE . 'Track',
		'6'			  =>		QOBUZSERVICE . 'Award',
	);
	
	return strtr($service_id, $services_array);
}

//
function map_endpoint_to_service($endpoint) {
	
	$endpoints_array = array(
		QOBUZSERVICE . 'Album'				=>		'1',
		QOBUZSERVICE . 'Artist'				=>		'2',
		QOBUZSERVICE . 'Label'				=>		'3',
		QOBUZSERVICE . 'Genre'				=>		'4',
		QOBUZSERVICE . 'Track'				=>		'5',
		QOBUZSERVICE . 'Award'				=>		'6',
	);
	
	return strtr($endpoint, $endpoints_array);
}

//
function construct_the_id($service_id, $extrenal_id) {
	
	$pattern_two_array = array(
		QOBUZSERVICE . 'Album',
		QOBUZSERVICE . 'Artist',
		QOBUZSERVICE . 'Label',
		QOBUZSERVICE . 'Genre',
		QOBUZSERVICE . 'Track',
		QOBUZSERVICE . 'Award',
	);

	if ( in_array($service_id, $pattern_two_array) )
	{
		$id = md5_encrypt(map_endpoint_to_service($service_id) . ':' . $extrenal_id, MD5_ID_MASTERKEY);
		
	} elseif ( $service_id == QOBUZSERVICE . 'service_three_???' )
	{
		$id = md5_encrypt(map_endpoint_to_service($service_id) . ':' . $extrenal_id, MD5_ID_MASTERKEY);
		
	}
		
	return $id;
}

//
function remove_non_utf8($string){
	// https://stackoverflow.com/a/1176923/4013321
	return preg_replace('/[\x00-\x1F\x7F\xA0]/u', '', $string);
}

//
function status_code($status = 200, $message = ''){
	if ( $status == '200' )
	{
		http_response_code(200);
		header("Status: 200 OK");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"ok","code":200,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the api works perfectly.')) . ',"data":{}}}';
	} elseif ( $status == '201' )
	{
		http_response_code(201);
		header("Status: 201 Created");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"created","code":201,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the request has been fulfilled successfully.')) . ',"data":{}}}';
	} elseif ( $status == '400' )
	{
		http_response_code(400);
		header("Status: 400 Bad Request");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"bad request","code":400,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('there was a problem with your request.')) . ',"data":{}}}';
	} elseif ( $status == '401' )
	{
		http_response_code(401);
		header("Status: 401 Unauthorized");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"unauthorized","code":401,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('access is denied due to invalid credentials.')) . ',"data":{}}}';
	} elseif ( $status == '402' )
	{
		http_response_code(402);
		header("Status: 402 Request Failed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"request failed","code":402,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('parameters were valid but request failed.')) . ',"data":{}}}';
	} elseif ( $status == '403' )
	{
		http_response_code(403);
		header("Status: 403 Forbidden");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"forbidden","code":403,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('no permission to access the resource.')) . ',"data":{}}}';
	} elseif ( $status == '404' )
	{
		http_response_code(404);
		header("Status: 404 Not Found");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"not found","code":404,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('no result is matched for given arguments.')) . ',"data":{}}}';
	} elseif ( $status == '412' )
	{
		http_response_code(412);
		header("Status: 412 Precondition Failed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"precondition failed","code":412,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server does not meet one of the preconditions.')) . ',"data":{}}}';
	} elseif ( $status == '417' )
	{
		http_response_code(417);
		header("Status: 417 Expectation Failed");
		header("Content-type: application/json; charset=utf-8");
		return '{"response":{"version":"' . APIVERSION . '","status":"expectation failed","code":417,"message":' . ($message != '' ? json_encode($message, JSON_HEX_QUOT) : json_encode('the server cannot meet the requirements.')) . ',"data":{}}}';
	}
}

?>
