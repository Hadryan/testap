require('dotenv').config()
const rabbitMQ = require('amqplib/callback_api')
const upserting = require('../upsertHandler')
const fetch = require('node-fetch')


rabbitMQ.connect('amqp://guest:guest@localhost', function(error, connection) {
  connection.createChannel(function(error, channel) {
    const queue = 'backgroundUpsert'
    channel.assertQueue(queue, { durable: true })
    channel.consume(queue, async function(msg) {
      let message = JSON.parse(msg.content)
      // This is the part where the worker calls a function to process the queue task
      await processUpsertRequest(message)
      channel.ack(msg)
    }, { noAck: false })
  })
})

function processUpsertRequest (message, response) {
//    console.log(message)
    fetchAlbumRequest(message)
//        .then(results => anotherFunction(results, message))

}

function fetchAlbumRequest (message) {
    const url = upserting.upsertAlbum(message)
    return fetch(url)
        .then(response => response.text())
}



