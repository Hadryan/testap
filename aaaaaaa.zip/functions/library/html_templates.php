<?php
	
define("DEEPLINK_HOMEPAGE",				'diginava://homePage');
define("APP_FARSI_NAME",				'دیجی نوا');
define("DEEPLINK_BTTN_SUCCESS",			'پرداخت موفق');
define("DEEPLINK_MSG_SUCCESS",			'بازگشت به اپلیکیشن دیجی‌نوا');
define("DEEPLINK_BTTN_ERROR",			'پرداخت ناموفق');
define("DEEPLINK_MSG_ERROR",			'بازگشت به اپلیکیشن دیجی‌نوا');

//
function template_successful_gateway_payment($link, $button, $message) {
	$html = '
		<!DOCTYPE html>
		<html class="musicapp-preview">
		<head>
		  <meta charset="utf-8">
		  <meta content="True" name="HandheldFriendly">
		  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
		  <title>Diginava</title>
		  <link rel="stylesheet" href="../' . URLVERSION . '/assets/css/response.css">
		  <link rel="stylesheet" href="../' . URLVERSION . '/assets/css/animate.css">
		  <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
		</head>
		 <body device-style="ios" device-size="standard" theme-color="rose">
		  <div class="container">
			<section class="main-header-container">
			  <div class="main-grid">
				<div class="inner">
				  <div class="left">
					<a href="' . $link . '" class="button-demo-site"><button><span class="text">' . htmlspecialchars($button) . '</span><span class="text-hover">' . htmlspecialchars($message) . '</span></button></a>
				  </div>
				</div>
			  </div>
			</section>
		  </div>
		  <script type="text/javascript" src="../' . URLVERSION . '/assets/js/response.js"></script>
		</body></html>
	';

	return $html;
}

//
function template_error_gateway_payment($link, $button, $message) {
	$html = '
		<!DOCTYPE html>
		<html class="musicapp-preview">
		<head>
		  <meta charset="utf-8">
		  <meta content="True" name="HandheldFriendly">
		  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
		  <title>Diginava</title>
		  <link rel="stylesheet" href="../' . URLVERSION . '/assets/css/response.css">
		  <link rel="stylesheet" href="../' . URLVERSION . '/assets/css/animate.css">
		  <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
		</head>
		 <body device-style="ios" device-size="standard" theme-color="rose">
		  <div class="container">
			<section class="main-header-container">
			  <div class="main-grid">
				<div class="inner">
				  <div class="left">
					<a href="' . $link . '" class="button-demo-site"><button style="background-image: linear-gradient(176deg, #555, #434);"><span class="text">' . htmlspecialchars($button) . '</span><span class="text-hover">' . htmlspecialchars($message) . '</span></button></a>
				  </div>
				</div>
			  </div>
			</section>
		  </div>
		  <script type="text/javascript" src="../' . URLVERSION . '/assets/js/response.js"></script>
		</body></html>
	';

	return $html;
}

//
function sms_package_payments_confirmation($amount, $order_id){
    $text = 'اعتبار شما به مبلغ ' . $amount . ' ریال با شماره تراکنش ' . $order_id . ' با موفقیت افزایش یافت.
اپلیکیشن ' . APP_FARSI_NAME;

	return $text;	
}

?>