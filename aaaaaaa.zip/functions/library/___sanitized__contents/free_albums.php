<?php

//
// Performance checker https://stackoverflow.com/a/2482007
function is_free_album($album_id){

	$free = array(
		'0747313218271'   => 1,
		'x4bwqvi5pqohc'   => 1,
		'0002894815376'   => 1,
		'zthw4msu2rz8a'   => 1,
		'0730003870248'   => 1,
		'0730003870101'   => 1,
		'sd8lwv7us23fb'   => 1,
		'dljrvvh0dfjnb'   => 1,
		'pwjshpuc2p3hc'   => 1,
		'l0opkhodd8ufb'   => 1,
		'n3nbxc9s8yoib'   => 1,
		'xnke68o7g73ab'   => 1,
		'nykd59w40tlxb'   => 1,
		'zrc01idpzuzba'   => 1,
		'jn19k2ujrwqkc'   => 1,

		
		
		
		
		
		
		
		
		
		
		
		
		
		//''	  => 1,
		
	);

	if ( isset($free[$album_id]) )
	{
		return true;
		
	} else
	{
		return false;
	}
}

?>