<?php
//error_reporting(-1);
//ini_set('display_errors', 1);
@set_time_limit(144);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Credentials: TRUE");
header("Content-type: application/json; charset=utf-8");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 19 Jul 1999 09:09:09 GMT");

include dirname(__FILE__) . '/internalBackendLess_functions.php';

	$result = 'Error';
	$boolean = (bool) false;
	
	@$header_can_set = $_SERVER['HTTP_X_CAN_SET'];

	if ( isset($header_can_set) && !empty($header_can_set) )
	{
		$data_cookie_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/System_Parameters';
		$data_cookie_headers = array(
			"Content-Type: application/json",
			"Accept: application/json"
		);
		
		@$fresh_cookie = get_qobuz_cookie_login('https://www.qobuz.com/api.json/0.2/user/login');
		@$fresh_cookie_results_array = json_decode($fresh_cookie, true);
		
		if ( !empty($fresh_cookie_results_array) && empty($fresh_cookie_results_array['status']) )
		{
			if ( !empty($fresh_cookie_results_array['user']['id']) )
			{
				$data_cookie_data = array(
					'json_response' => json_encode($fresh_cookie_results_array),
					'service_type' => 'qobuz',
				);
				
				// Update the System_Parameters
				try {
					@$data_cookie_results = sendBackendlessRequest( $data_cookie_url, $data_cookie_headers, json_encode($data_cookie_data) );
					@$data_cookie_results_array = json_decode($data_cookie_results, true);
					
				} catch (Exception $ex){
					sendError('internalBackendLessQobuzFreshCookie', 'error', (string)$ex->getCode(), $ex->getMessage(), 'time: ' . time());
				}
				
				if ( !empty($data_cookie_results_array) )
				{
					$result = 'Splendid'; // the backendless response is not json !
					$boolean = (bool) true;
				}
				
			} else
			{
				sendError('fresh_cookie', 'error', 'urgent', 'something happened with the account!', 'time: ' . time());
			}
			
		} else // We still use the previous cookie, but we need to send the error log
		{
			sendError( 'System_Parameters', 'error', 'urgent', 'cookie generation had error', 'time: ' . time() );
		}
		
	}
	
	echo customResponse($boolean, $result);

?>