<?php
include dirname(__FILE__) . '/internalBackendLess_functions.php';


//
function set_favorites( $favorite_id, $favorite_name = '', $favorite_type, $image_id, $favorite_more, $app_id, $user_token, $session_id ) {

	if ( defined('AllowToAccessUsersFunctions') )
	{
		@$user_objectId = decrypt($user_token);
		@$session_response = remove_non_utf8(md5_decrypt($session_id, MD5_INTERNAL_RESOURCE));
		@$constructed_session_id = explode(':', $session_response);
		@$provided_user_id = $constructed_session_id[0];
		@$session_id_decrypted = $constructed_session_id[1];
		
		if ( $user_objectId == $provided_user_id )
		{
			$favorite_id_original = $favorite_id;
			$decrypted_id = remove_non_utf8(md5_decrypt($favorite_id, MD5_ID_MASTERKEY));
			$constructed_id = explode(':', $decrypted_id);
			$service_id = $constructed_id[0];
			$favorite_id = $constructed_id[1];
			
			$decrypted_album_id = remove_non_utf8(md5_decrypt($image_id, MD5_ID_MASTERKEY));
			$constructed_album_id = explode(':', $decrypted_album_id);
			$album_id = $constructed_album_id[1];
			
			$database_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users_Favorites';
			$database_headers = array(
				"Content-Type: application/json",
			);
			$data_set_favorites = array(
				'favorite_id'		=> $user_objectId . '_' . $favorite_id,
				'favorite_name' 	=> $favorite_name,
				'favorite_type' 	=> $favorite_type,
				'image_id'			=> $album_id,
				'service_id'		=> (int)$service_id, // The original service we get the information from
				'ownerId'			=> $user_objectId,
			);
			if ( !empty($favorite_more) )
			{
				$data_set_favorites['favorite_more'] = $favorite_more;
			}
			
			try {
				@$database_results = updateBackendlessRequest( $database_url, $database_headers, json_encode($data_set_favorites) );
				@$database_results_array = json_decode($database_results, true);
			
			} catch (Exception $ex){
				sendError( 'setUserFavorites', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , app_id: ' . @$app_id . ' and time: ' . time() );
			}		
			
			if ( !empty($database_results_array) )
			{
				if ( empty($database_results_array['code']) )
				{
					$created_owner_id = $database_results_array['ownerId'];
					$created_object_id = $database_results_array['objectId'];
					
					$relation_url = 'https://api.backendless.com/' . APPLICATION_ID . '/' . SECRET_KEY . '/data/Users/' . $created_owner_id . '/user_favorites';
					$relation_data = array(
						'objectId' 	 => $created_object_id
					);
					
					try {
						updateBackendlessRequest( $relation_url, $database_headers, json_encode($relation_data) );
					
					} catch (Exception $ex){
						sendError( 'setUserFavorites_relationUpdate', 'error', (string)$ex->getCode(), $ex->getMessage(), 'user_objectId: ' . @$user_objectId . ' , favorite_objectId: ' . @$created_object_id . ' , app_id: ' . @$app_id . ' and time: ' . time() );
					}
					
					return status_code(201);
					
				} else {
					echo status_code(412, 'this value is already set!');
					exit;
				}
			
			} else { // Nothing returned from the server
				echo status_code(404);
				exit;
			}
		
		} else { // Invalid login
			echo status_code(403);
			exit;
		}
		
	} else {
		die(status_code(401));
		
	}
}

//
function response_json(){
	$output = array(
		'response'		=> array(
			'version'		=> APIVERSION,
			'status'		=> 'success',
			'code'			=> 200,
			'message'		=> 'successful',
			'data'			=> json_decode('{}')
		)
	);
	
	return json_encode($output);
}

?>