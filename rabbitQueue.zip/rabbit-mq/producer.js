const rabbitMQ = require('amqplib/callback_api')

function sendToProcessQueue(msg) {
    rabbitMQ.connect('amqp://guest:guest@localhost', function(error, connection) {
      connection.createChannel(function(error, channel) {
        const queue = 'backgroundUpsert'
        channel.assertQueue(queue, { durable: true })
        channel.sendToQueue(queue, Buffer.from(JSON.stringify(msg)), {
            persistent: true,
            mandatory: true,
            //headers: { retrySum: 5 } // TODO 预留，重试时使用
        }, (err) => {
            if (err) {
                return console.error(`sendToQueue ${queue} error: ${err.toString()}`)
            }
            console.log(`sendToQueue ${queue} success: ${JSON.stringify(message)}`)
        })
      })
    })
}

module.exports = {
    sendToProcessQueue
}
